<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Updater {

    private $backup_dir;

    public function __construct() {
        $uploads = wp_upload_dir();
        $this->backup_dir = $uploads['basedir'] . '/sentinel-backups/';
    }

    /**
     * Respalda un plugin específico antes de actualizarlo
     */
    private function backup_plugin_folder($plugin_file) {
        $plugin_dir = WP_PLUGIN_DIR . '/' . dirname($plugin_file);
        
        if (!is_dir($plugin_dir)) {
            return false;
        }

        $backup_zip = $this->backup_dir . 'rollback_' . sanitize_title(dirname($plugin_file)) . '.zip';

        // Comprimir el plugin actual
        $zip = new ZipArchive();
        if ($zip->open($backup_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($plugin_dir),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                if (!$file->isDir()) {
                    $file_path = $file->getRealPath();
                    $relative_path = substr($file_path, strlen(WP_PLUGIN_DIR) + 1);
                    $zip->addFile($file_path, $relative_path);
                }
            }
            $zip->close();
            return $backup_zip;
        }

        return false;
    }

    /**
     * Ejecuta el ciclo de actualización aislada de un plugin específico
     */
    public function update_plugin($plugin_file) {
        // Cargar librerías de WordPress Upgrader
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        include_once ABSPATH . 'wp-admin/includes/file.php';
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        // Check if there is an update package available and get expected version
        $update_plugins = get_site_transient('update_plugins');
        $has_package = false;
        $expected_version = '';
        if (isset($update_plugins->response[$plugin_file])) {
            $update_info = $update_plugins->response[$plugin_file];
            $expected_version = isset($update_info->new_version) ? $update_info->new_version : '';
            if (!empty($update_info->package)) {
                $has_package = true;
            }
        }

        $premium_keywords = array('cmsmasters', 'elementor-pro', 'wp-rocket', 'revslider', 'js_composer', 'gravityforms');
        $is_known_premium = false;
        foreach ($premium_keywords as $kw) {
            if (false !== strpos(strtolower($plugin_file), $kw)) {
                $is_known_premium = true;
                break;
            }
        }

        // Return needs_manual => true for premium/unlicensed plugins before updating
        if ((isset($update_plugins->response[$plugin_file]) && !$has_package) || $is_known_premium) {
            return array(
                'success' => false,
                'needs_manual' => true,
                'message' => 'El plugin requiere actualización manual (premium o sin licencia activa).'
            );
        }

        // Obtener versión antes de actualizar
        $plugin_abs_path = WP_PLUGIN_DIR . '/' . $plugin_file;
        $version_before = '0.0.0';
        if (file_exists($plugin_abs_path)) {
            $plugin_data = get_plugin_data($plugin_abs_path);
            $version_before = isset($plugin_data['Version']) ? $plugin_data['Version'] : '0.0.0';
        }

        // 1. Respaldar antes de actualizar (Rollback Seguro)
        $backup_path = $this->backup_plugin_folder($plugin_file);
        if (!$backup_path) {
            return array('success' => false, 'message' => 'No se pudo realizar el backup de seguridad previo al update.');
        }

        // Comprobar privilegios y credenciales de sistema de archivos
        $url = 'plugins.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }

        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        // Crear una skin silenciosa para no emitir output visual
        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);

        // Desactivar el plugin temporalmente antes de actualizar
        deactivate_plugins($plugin_file);

        // Actualizar
        $result = $upgrader->upgrade($plugin_file);

        // Obtener versión después de actualizar
        $version_after = '0.0.0';
        if (file_exists($plugin_abs_path)) {
            $plugin_data = get_plugin_data($plugin_abs_path);
            $version_after = isset($plugin_data['Version']) ? $plugin_data['Version'] : '0.0.0';
        }

        // Identificar si falló el paquete o no cambió la versión (típico de premium de pago)
        $is_wp_error = is_wp_error($result);
        $error_code = $is_wp_error ? $result->get_error_code() : '';
        $error_msg = $is_wp_error ? $result->get_error_message() : '';

        // Pre/post version checks & failure detection
        $failed_upgrade = $is_wp_error || !$result || ($version_before === $version_after) || (!empty($expected_version) && $version_after !== $expected_version);

        if ($failed_upgrade) {
            // Intentar restaurar de inmediato si la actualización falló o hubo mismatch
            $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '.zip');
            // Reactivar el plugin anterior tras restaurarlo
            activate_plugin($plugin_file);

            $is_license_issue = ($error_code === 'no_package' || 
                                 strpos(strtolower($error_msg), 'no disponible') !== false || 
                                 strpos(strtolower($error_msg), 'package not available') !== false ||
                                 $version_before === $version_after);

            if ($is_license_issue || $is_known_premium || !$has_package) {
                return array(
                    'success' => false,
                    'needs_manual' => true,
                    'message' => 'El plugin requiere actualización manual (posiblemente de pago o sin licencia activa).'
                );
            }

            return array(
                'success' => false,
                'message' => $is_wp_error ? $error_msg : 'La actualización ha fallado o la versión no ha cambiado/mismatch. Rollback disparado automáticamente.'
            );
        }

        // Reactivar plugin
        $activation_result = activate_plugin($plugin_file);
        
        // Comprobar si el plugin se activó correctamente
        if (is_wp_error($activation_result) || !is_plugin_active($plugin_file)) {
            // El plugin falló al reactivarse (posible error fatal o incompatibilidad de código)
            $activation_err = is_wp_error($activation_result) ? $activation_result->get_error_message() : 'El plugin no quedó activo tras la actualización.';
            
            // Disparar Rollback de emergencia
            $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '.zip');
            activate_plugin($plugin_file);
            
            return array(
                'success' => false,
                'message' => 'Fallo de activación tras actualización: ' . $activation_err . ' Rollback automático ejecutado exitosamente.'
            );
        }

        // Test de salud rápido tras la actualización mediante loopback interno
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 10,
            'sslverify' => false,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        if (!is_wp_error($test_response)) {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                // El sitio arrojó pantalla blanca o error fatal con el nuevo plugin activo
                $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '.zip');
                activate_plugin($plugin_file);
                return array(
                    'success' => false,
                    'message' => 'El plugin provocó un error fatal en el sitio (HTTP ' . $test_code . '). Rollback automático ejecutado exitosamente.'
                );
            }
        }

        return array(
            'success' => true,
            'message' => 'Plugin actualizado, verificado y reactivado con éxito.',
            'backup_rollback' => basename($backup_path)
        );
    }

    /**
     * Realiza la sobreescritura y el deploy de rescate ante desastres
     */
    public function restore_backup($backup_name) {
        $backup_path = $this->backup_dir . sanitize_file_name($backup_name);

        if (!file_exists($backup_path)) {
            return array('success' => false, 'message' => 'Fichero de respaldo no encontrado.');
        }

        // Determinar tipo de respaldo
        $extension = pathinfo($backup_path, PATHINFO_EXTENSION);

        if ($extension === 'zip') {
            // Restaurar plugin o archivos
            $zip = new ZipArchive();
            if ($zip->open($backup_path) === true) {
                // Extraer de vuelta a la carpeta raíz de plugins (conservando la estructura del zip)
                $zip->extractTo(WP_PLUGIN_DIR);
                $zip->close();
                return array('success' => true, 'message' => 'Archivos restaurados con éxito.');
            }
        } elseif ($extension === 'sql') {
            // Restaurar base de datos
            global $wpdb;
            $sql = file_get_contents($backup_path);
            
            // Separar consultas SQL de forma rústica y segura para ejecutar una por una
            $queries = preg_split("/;[ \t]*\n/", $sql);
            
            foreach ($queries as $query) {
                $query = trim($query);
                if (!empty($query)) {
                    $wpdb->query($query);
                }
            }
            return array('success' => true, 'message' => 'Base de datos importada correctamente.');
        }

        return array('success' => false, 'message' => 'Formato de restauración no compatible.');
    }

    /**
     * Motor de Auto-Actualización seguro del propio Sentinel.
     * Descarga el ZIP, hace swap atómico, valida con un loopback HTTP request y hace rollback si falla.
     */
    public function self_update_plugin($zip_url) {
        // Inicializar sistema de archivos de WP si no se ha hecho
        $url = 'plugins.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }
        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        // Definir rutas
        $plugin_slug = 'sentinel-plugin';
        $plugin_dir = WP_PLUGIN_DIR . '/' . $plugin_slug;
        $plugin_old_dir = WP_PLUGIN_DIR . '/' . $plugin_slug . '_old';
        $temp_zip = $this->backup_dir . 'sentinel-update-temp.zip';
        $temp_extract_dir = $this->backup_dir . 'sentinel-update-extract';

        // 1. Descargar paquete ZIP
        $response = wp_remote_get($zip_url, array(
            'timeout' => 45,
            'sslverify' => false,
            'user-agent' => 'Sentinel/1.2.0 Control Center Client'
        ));

        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Error al descargar el ZIP de actualización: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return array('success' => false, 'message' => 'El servidor del Panel Central retornó HTTP ' . $code);
        }

        $zip_body = wp_remote_retrieve_body($response);
        if (empty($zip_body)) {
            return array('success' => false, 'message' => 'Cuerpo del archivo ZIP vacío.');
        }

        // Asegurar que el directorio de backups existe
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        // Guardar ZIP temporal
        if (false === file_put_contents($temp_zip, $zip_body)) {
            return array('success' => false, 'message' => 'No se pudo escribir el archivo ZIP temporal en disco.');
        }

        // 2. Extraer ZIP en carpeta temporal
        if (file_exists($temp_extract_dir)) {
            $this->recursive_rmdir($temp_extract_dir);
        }
        wp_mkdir_p($temp_extract_dir);

        $zip = new ZipArchive();
        if ($zip->open($temp_zip) !== true) {
            @unlink($temp_zip);
            return array('success' => false, 'message' => 'El archivo ZIP de actualización está corrupto o es inválido.');
        }

        $zip->extractTo($temp_extract_dir);
        $zip->close();
        @unlink($temp_zip);

        // Buscar la carpeta del plugin dentro del ZIP extraído (podría estar anidada o ser directa)
        $extracted_items = scandir($temp_extract_dir);
        $extracted_slug = '';
        foreach ($extracted_items as $item) {
            if ($item === '.' || $item === '..') continue;
            if (is_dir($temp_extract_dir . '/' . $item)) {
                $extracted_slug = $item;
                break;
            }
        }

        if (empty($extracted_slug)) {
            $this->recursive_rmdir($temp_extract_dir);
            return array('success' => false, 'message' => 'No se encontró un directorio de plugin válido dentro del ZIP.');
        }

        $new_plugin_source = $temp_extract_dir . '/' . $extracted_slug;

        // 3. Intercambio Atómico de Directorios
        if (file_exists($plugin_old_dir)) {
            $this->recursive_rmdir($plugin_old_dir);
        }

        // Mover el actual a sentinel-plugin_old
        if (file_exists($plugin_dir)) {
            if (!rename($plugin_dir, $plugin_old_dir)) {
                $this->recursive_rmdir($temp_extract_dir);
                return array('success' => false, 'message' => 'Fallo al renombrar la versión activa a la carpeta temporal _old.');
            }
        }

        // Mover el nuevo a sentinel-plugin
        if (!rename($new_plugin_source, $plugin_dir)) {
            // Restaurar de emergencia
            if (file_exists($plugin_old_dir)) {
                rename($plugin_old_dir, $plugin_dir);
            }
            $this->recursive_rmdir($temp_extract_dir);
            return array('success' => false, 'message' => 'Fallo al instalar la nueva versión en la ruta activa.');
        }

        // Limpiar directorio temporal de extracción
        $this->recursive_rmdir($temp_extract_dir);

        // Limpiar caché de plugins de WordPress
        if (function_exists('wp_clean_plugins_cache')) {
            wp_clean_plugins_cache(true);
        }

        // 4. Petición HTTP Loopback interna al sitio para verificar que no haya Pantalla Blanca (WSOD)
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 15,
            'sslverify' => false,
            'redirection' => 5,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        $rollback_needed = false;
        $reason = '';

        if (is_wp_error($test_response)) {
            $rollback_needed = true;
            $reason = 'Loopback HTTP fallido: ' . $test_response->get_error_message();
        } else {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                $rollback_needed = true;
                $reason = 'El sitio arrojó un error interno de servidor (HTTP ' . $test_code . '). WSOD prevenida.';
            }
        }

        // 5. Rollback en caso de fallos
        if ($rollback_needed) {
            // Eliminar la carpeta fallida
            if (file_exists($plugin_dir)) {
                $this->recursive_rmdir($plugin_dir);
            }
            // Restaurar versión _old de regreso a activa
            if (file_exists($plugin_old_dir)) {
                rename($plugin_old_dir, $plugin_dir);
            }
            
            if (function_exists('wp_clean_plugins_cache')) {
                wp_clean_plugins_cache(true);
            }
            
            return array('success' => false, 'message' => 'Rollback automático ejecutado exitosamente. Razón: ' . $reason);
        }

        // 6. Limpieza final de la versión antigua si todo fue exitoso
        if (file_exists($plugin_old_dir)) {
            $this->recursive_rmdir($plugin_old_dir);
        }

        return array(
            'success' => true,
            'message' => 'Plugin Sentinel auto-actualizado exitosamente con verificación de loopback.'
        );
    }

    /**
     * Helper recursivo para borrar carpetas no vacías
     */
    private function recursive_rmdir($dir) {
        if (!is_dir($dir)) {
            return;
        }
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->recursive_rmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }
}
