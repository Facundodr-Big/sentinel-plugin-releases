<?php
/*
Plugin Name: Sentinel Recovery Early Interceptor
Description: Intercepts emergency recovery requests early in the WordPress lifecycle to bypass plugin/theme fatal errors and Mod_Security blocks.
Version: 1.0
Author: Sentinel
*/

if (!defined('ABSPATH')) {
    exit;
}

// Escuchar peticiones de recuperación
if (isset($_POST['sentinel_emergency_action']) && $_POST['sentinel_emergency_action'] === '1') {
    $controlcenter_dir = WP_CONTENT_DIR . '/controlcenter';
    $recovery_script = $controlcenter_dir . '/recovery/recovery.php';
    
    if (file_exists($recovery_script)) {
        // Cargar el script de recuperación de forma autónoma
        require_once $recovery_script;
        exit;
    }
}
