<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_API_Handler {

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Registrar rutas REST nativas (WP 4.7+)
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // Fallback de Admin AJAX para WordPress antiguos
        add_action('wp_ajax_nopriv_sentinel_fallback', array($this, 'handle_ajax_fallback'));
        add_action('wp_ajax_sentinel_fallback', array($this, 'handle_ajax_fallback'));
    }

    /**
     * Valida la clave de seguridad enviada en la petición
     */
    public function validate_key() {
        $client_key = '';

        // 1. Validar por Header de Autorización Bearer
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
            if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
                $client_key = trim($matches[1]);
            }
        } elseif (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['Authorization'])) {
                if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                    $client_key = trim($matches[1]);
                }
            }
        }

        // 2. Validar por Header Personalizado X-Sentinel-API-Key (Sin sanitizar para evitar dañar claves especiales)
        if (empty($client_key) && isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
            $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
        }

        // 3. Validar por Query Parameter (Fallback)
        if (empty($client_key) && isset($_REQUEST['sentinel_key'])) {
            $client_key = trim($_REQUEST['sentinel_key']);
        }

        return !empty($client_key) && hash_equals(SENTINEL_API_KEY, $client_key);
    }

    /**
     * Comprobación de permiso de la REST API
     */
    public function check_rest_permission() {
        if (!$this->validate_key()) {
            return new WP_Error('sentinel_forbidden', 'Acceso denegado: API Key inválida.', array('status' => 401));
        }
        return true;
    }

    /**
     * Registra las rutas de la REST API nativa
     */
    public function register_rest_routes() {
        register_rest_route('sentinel/v1', '/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db/check', array(
            'methods'  => 'GET',
            'callback' => array($this, 'check_backup_db_support'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db/mysqldump', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_mysqldump'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db/chunk/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_start'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db/chunk/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_step'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/db/chunk/finish', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_finish'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/incremental', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_incremental'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/files/exclusions', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_file_exclusions'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/files/exclusions', array(
            'methods'  => 'POST',
            'callback' => array($this, 'update_file_exclusions'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/update/plugin', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_plugin'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/restore', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_restore'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/download', array(
            'methods'  => 'GET',
            'callback' => array($this, 'download_backup'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/backup/delete', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_backup'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));

        register_rest_route('sentinel/v1', '/update/self', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_self_update'),
            'permission_callback' => array($this, 'check_rest_permission'),
        ));
    }

    /**
     * Manejador de Admin AJAX para compatibilidad
     */
    public function handle_ajax_fallback() {
        if (!$this->validate_key()) {
            wp_send_json_error(array('message' => 'Acceso denegado: API Key inválida.'), 401);
        }

        $endpoint = isset($_REQUEST['endpoint']) ? sanitize_text_field($_REQUEST['endpoint']) : '';

        switch ($endpoint) {
            case 'status':
                $response = $this->get_status();
                wp_send_json_success($response);
                break;
            case 'backup_db':
                $response = $this->trigger_backup_db();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            case 'backup_incremental':
                $response = $this->trigger_backup_incremental();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            case 'update_plugin':
                $response = $this->trigger_update_plugin();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            case 'restore':
                $response = $this->trigger_restore();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            case 'delete_backup':
                $response = $this->delete_backup();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            case 'update_self':
                $response = $this->trigger_self_update();
                if (is_array($response) && isset($response['success']) && !$response['success']) {
                    wp_send_json_error($response);
                } else {
                    wp_send_json_success($response);
                }
                break;
            default:
                wp_send_json_error(array('message' => 'Endpoint no encontrado.'), 404);
        }
    }

    /**
     * Retorna el estado y telemetría del servidor
     */
    public function get_status($request = null) {
        global $wp_version;

        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins', array());
        $updates = get_site_transient('update_plugins');

        $plugin_list = array();
        foreach ($plugins as $file => $data) {
            $is_active = in_array($file, $active_plugins);
            $has_update = false;
            $new_version = '';

            if (is_object($updates) && isset($updates->response) && is_array($updates->response) && isset($updates->response[$file])) {
                $has_update = true;
                $new_version = $updates->response[$file]->new_version;
            }

            $plugin_list[] = array(
                'file'         => $file,
                'name'         => $data['Name'],
                'version'      => $data['Version'],
                'active'       => $is_active,
                'has_update'   => $has_update,
                'new_version'  => $new_version
            );
        }

        $free_disk = function_exists('disk_free_space') ? @disk_free_space(ABSPATH) : 0;
        $total_disk = function_exists('disk_total_space') ? @disk_total_space(ABSPATH) : 0;
        $free_disk = ($free_disk !== false) ? (int)$free_disk : 0;
        $total_disk = ($total_disk !== false) ? (int)$total_disk : 0;

        // DB Size
        global $wpdb;
        $db_size = $wpdb->get_var("SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()");
        $db_size = $db_size ? (int)$db_size : 0;

        // Uploads Size
        $uploads_dir = wp_upload_dir();
        $uploads_path = $uploads_dir['basedir'];
        $uploads_size = $this->get_dir_size($uploads_path);

        // Large backup files scan in the whole WordPress directory (files > 15MB) - only run on manual sync
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $scan_large = isset($params['scan_large']) && $params['scan_large'] === 'true';
        $large_files = array();
        if ($scan_large) {
            try {
                // Intentar extender el tiempo de ejecución para hostings limitados
                @set_time_limit(60);
                $large_files = $this->scan_large_files(ABSPATH, 15728640);
            } catch (\Throwable $scan_error) {
                // Si falla por falta de recursos, devolver vacío sin tumbar el endpoint
                $large_files = array();
                error_log('Sentinel: Scan de archivos grandes falló: ' . $scan_error->getMessage());
            }
        }

        return array(
            'status'            => 'online',
            'sentinel_version'  => SENTINEL_VERSION,
            'wp_version'        => $wp_version,
            'php_version'       => PHP_VERSION,
            'woo_active'        => class_exists('WooCommerce'),
            'disk_space'        => array(
                'free_bytes'    => $free_disk,
                'total_bytes'   => $total_disk,
                'free_percent'  => $total_disk > 0 ? round(($free_disk / $total_disk) * 100, 2) : 0
            ),
            'db_size_bytes'     => $db_size,
            'uploads_size_bytes'=> $uploads_size,
            'large_files'       => $large_files,
            'memory_limit'      => ini_get('memory_limit'),
            'max_execution_time'=> ini_get('max_execution_time'),
            'plugins'           => $plugin_list
        );
    }

    /**
     * Calcula el tamaño total de una carpeta de forma recursiva
     */
    private function get_dir_size($path) {
        $size = 0;
        $path = rtrim($path, '/\\') . '/';
        if (is_dir($path)) {
            $files = @scandir($path);
            if ($files !== false) {
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..') {
                        $full_path = $path . $file;
                        if (is_dir($full_path)) {
                            $size += $this->get_dir_size($full_path);
                        } else {
                            if (file_exists($full_path)) {
                                $size += @filesize($full_path);
                            }
                        }
                    }
                }
            }
        }
        return $size;
    }

    /**
     * Escanea la ruta buscando archivos pesados (>15MB) de extensiones de backup
     */
    private function scan_large_files($path, $min_size) {
        $large_files = array();
        if (!is_dir($path)) {
            return $large_files;
        }
        $start_time = time();
        $max_duration = 45; // Límite extendido para sitios grandes (>2GB)
        $memory_limit_bytes = $this->get_memory_limit_bytes();

        try {
            $flags = RecursiveDirectoryIterator::SKIP_DOTS;
            if (defined('FilesystemIterator::UNFOLLOW_SYMLINKS')) {
                $flags |= FilesystemIterator::UNFOLLOW_SYMLINKS;
            }
            $directory = new RecursiveDirectoryIterator($path, $flags);
            $iterator = new RecursiveIteratorIterator($directory, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

            foreach ($iterator as $item) {
                // Chequear límite de tiempo en cada ciclo para salir si se demora
                if ((time() - $start_time) > $max_duration) {
                    break;
                }
                
                // Abortar si se consume más del 80% de la memoria disponible
                if ($memory_limit_bytes > 0 && memory_get_usage(true) > ($memory_limit_bytes * 0.8)) {
                    break;
                }
                
                try {
                    if ($item->isFile()) {
                        $file_size = @$item->getSize();
                        if ($file_size >= $min_size) {
                            $ext = strtolower(pathinfo($item->getFilename(), PATHINFO_EXTENSION));
                            if (in_array($ext, array('zip', 'tar', 'gz', 'sql', 'log', 'bak', 'rar'))) {
                                $large_files[] = array(
                                    'path' => str_replace(wp_normalize_path(ABSPATH), '', wp_normalize_path($item->getPathname())),
                                    'size' => $file_size,
                                    'formatted_size' => size_format($file_size)
                                );
                            }
                        }
                    }
                } catch (\Throwable $inner_ex) {
                    // Ignorar fallos de permisos en archivos individuales
                }
            }
        } catch (\Throwable $e) {
            // Ignorar errores generales (permisos, symlinks rotos, etc.)
        }
        return $large_files;
    }

    /**
     * Convierte el memory_limit de PHP a bytes para control de uso de memoria
     */
    private function get_memory_limit_bytes() {
        $limit = ini_get('memory_limit');
        if ($limit === '-1') {
            return 0; // Sin límite
        }
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit) - 1]);
        $value = intval($limit);
        switch ($last) {
            case 'g': $value *= 1024;
            case 'm': $value *= 1024;
            case 'k': $value *= 1024;
        }
        return $value;
    }

    /**
     * Inicia el volcado de base de datos
     */
    public function trigger_backup_db($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup();
    }

    /**
     * Inicia el backup de archivos
     */
    public function trigger_backup_incremental($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }

        // Obtener parámetros
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 500;

        // Obtener tipo de backup solicitado (auto, full, incremental)
        $type = 'auto';
        if (isset($params['type'])) {
            $type = sanitize_text_field($params['type']);
        }
        
        $excluded_files = array();
        if (is_a($request, 'WP_REST_Request')) {
            $body = $request->get_json_params();
            if (isset($body['excluded_files']) && is_array($body['excluded_files'])) {
                $excluded_files = array_map('sanitize_text_field', $body['excluded_files']);
            }
            if (isset($body['type'])) {
                $type = sanitize_text_field($body['type']);
            }
        } elseif (isset($_REQUEST['excluded_files'])) {
            $raw = $_REQUEST['excluded_files'];
            if (is_string($raw)) {
                $decoded = json_decode(stripslashes($raw), true);
                if (is_array($decoded)) {
                    $excluded_files = array_map('sanitize_text_field', $decoded);
                }
            } elseif (is_array($raw)) {
                $excluded_files = array_map('sanitize_text_field', $raw);
            }
        }
        if (isset($_REQUEST['type'])) {
            $type = sanitize_text_field($_REQUEST['type']);
        }
        
        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->run_backup($offset, $limit, $type, $excluded_files);
    }

    /**
     * Inicia la actualización de un plugin
     */
    public function trigger_update_plugin($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $plugin_file = isset($params['plugin_file']) ? sanitize_text_field($params['plugin_file']) : '';

        if (empty($plugin_file)) {
            return array('success' => false, 'message' => 'Especifica un archivo de plugin.');
        }

        $updater = new Sentinel_Updater();
        return $updater->update_plugin($plugin_file);
    }

    /**
     * Inicia la restauración del sitio
     */
    public function trigger_restore($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $backup_name = isset($params['backup_name']) ? sanitize_text_field($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Especifica el nombre del backup para restaurar.');
        }

        $updater = new Sentinel_Updater();
        return $updater->restore_backup($backup_name);
    }

    /**
     * Descarga de forma segura un archivo de backup
     */
    public function download_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $file = isset($params['file']) ? sanitize_file_name($params['file']) : '';

        if (empty($file)) {
            return new WP_Error('sentinel_bad_request', 'Especifica un nombre de archivo.', array('status' => 400));
        }

        $uploads = wp_upload_dir();
        $backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        $file_path = $backup_dir . $file;

        if (!file_exists($file_path) || !is_readable($file_path)) {
            return new WP_Error('sentinel_not_found', 'El archivo no existe o no se puede leer.', array('status' => 404));
        }

        $file_size = filesize($file_path);
        $fp = @fopen($file_path, 'rb');
        if (!$fp) {
            return new WP_Error('sentinel_server_error', 'No se pudo abrir el archivo para lectura.', array('status' => 500));
        }

        // Limpiar buffers previos de salida
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Parámetros de descarga parcial (HTTP Range)
        $start = 0;
        $end = $file_size - 1;

        if (isset($_SERVER['HTTP_RANGE'])) {
            if (preg_match('/bytes=\s*(\d+)-(\d*)/i', $_SERVER['HTTP_RANGE'], $matches)) {
                $start = intval($matches[1]);
                if (!empty($matches[2])) {
                    $end = intval($matches[2]);
                }
            }
        }

        if ($start > 0 || $end < ($file_size - 1)) {
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes $start-$end/$file_size");
        } else {
            header('HTTP/1.1 200 OK');
        }

        // Cabeceras estándares de descarga
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Accept-Ranges: bytes');
        
        // Calcular hash del archivo completo para verificación de integridad
        $hash_file = md5_file($file_path);
        header('X-Sentinel-File-Hash: ' . $hash_file);

        $content_length = $end - $start + 1;
        header('Content-Length: ' . $content_length);

        // Mover puntero al byte de inicio solicitado
        fseek($fp, $start);

        $chunk_size = 8192; // 8 KB chunks
        $bytes_sent = 0;

        while (!feof($fp) && $bytes_sent < $content_length && (connection_status() == 0)) {
            $to_read = min($chunk_size, $content_length - $bytes_sent);
            $buffer = fread($fp, $to_read);
            echo $buffer;
            flush();
            
            $bytes_sent += strlen($buffer);
        }

        fclose($fp);
        exit;
    }

    /**
     * Elimina un archivo de copia de seguridad del hosting
     */
    public function delete_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $file = isset($params['file']) ? sanitize_file_name($params['file']) : '';

        if (empty($file)) {
            return array('success' => false, 'message' => 'Especifica un nombre de archivo.');
        }

        $uploads = wp_upload_dir();
        $backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        $file_path = $backup_dir . $file;

        // Validar que el archivo exista y esté confinado a la carpeta de backups
        if (file_exists($file_path) && is_file($file_path)) {
            if (unlink($file_path)) {
                return array('success' => true, 'message' => 'Copia de seguridad remota eliminada del hosting.');
            }
            return array('success' => false, 'message' => 'No se pudo eliminar el archivo físico del hosting.');
        }

        return array('success' => false, 'message' => 'El archivo no existe en el hosting remoto.');
    }

    /**
     * Dispara la auto-actualización del plugin Sentinel
     */
    public function trigger_self_update($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $zip_url = isset($params['zip_url']) ? esc_url_raw($params['zip_url']) : '';

        if (empty($zip_url)) {
            return array('success' => false, 'message' => 'Especifica la URL del paquete zip de actualización.');
        }

        require_once plugin_dir_path(__FILE__) . 'class-updater.php';
        $updater = new Sentinel_Updater();
        
        if (method_exists($updater, 'self_update_plugin')) {
            return $updater->self_update_plugin($zip_url);
        }

        return array('success' => false, 'message' => 'El actualizador no soporta auto-actualización en esta versión.');
    }

    public function check_backup_db_support($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->check_environment_support();
    }

    public function trigger_backup_db_mysqldump($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup_mysqldump();
    }

    public function trigger_backup_db_chunk_start($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->start_chunk_backup();
    }

    public function trigger_backup_db_chunk_step($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $table = isset($params['table']) ? sanitize_text_field($params['table']) : '';
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 1000;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';
        $write_structure = isset($params['write_structure']) ? (bool)$params['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure);
    }

    public function trigger_backup_db_chunk_finish($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetro "backup_name" requerido.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->finish_chunk_backup($backup_name);
    }

    public function get_file_exclusions($request = null) {
        $exclusions = get_option('sentinel_excluded_files', array());
        if (!is_array($exclusions)) {
            $exclusions = array();
        }
        return array('success' => true, 'exclusions' => $exclusions);
    }

    public function update_file_exclusions($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        
        $exclusions = array();
        if (isset($params['exclusions'])) {
            $raw_exclusions = $params['exclusions'];
            if (is_array($raw_exclusions)) {
                $exclusions = array_map('sanitize_text_field', $raw_exclusions);
            } elseif (is_string($raw_exclusions)) {
                $decoded = json_decode(stripslashes($raw_exclusions), true);
                if (is_array($decoded)) {
                    $exclusions = array_map('sanitize_text_field', $decoded);
                }
            }
        }
        
        update_option('sentinel_excluded_files', $exclusions);
        return array('success' => true, 'message' => 'Exclusiones guardadas correctamente.', 'exclusions' => $exclusions);
    }
}
