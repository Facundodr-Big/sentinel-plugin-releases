<?php
/**
 * Plugin Name: Sentinel
 * Plugin URI: https://github.com/bigredes/sentinel
 * Description: Ecosistema pasivo inteligente para mantenimiento preventivo, copias de seguridad paginadas por lotes y actualizaciones seguras tolerantes a fallos.
 * Version: 1.2.3
 * Author: Sentinel
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// Versión y Rutas
define('SENTINEL_VERSION', '1.2.3');
define('SENTINEL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SENTINEL_PLUGIN_URL', plugin_dir_url(__FILE__));

// Carga de clases requeridas (compatibilidad hacia atrás)
require_once SENTINEL_PLUGIN_DIR . 'includes/class-api-handler.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-backup-files.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-backup-db.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-updater.php';

// Resolver la API Key: 1. Constante en wp-config.php, 2. Opción en BD, 3. Valor por defecto
if (!defined('SENTINEL_API_KEY')) {
    $db_key = get_option('sentinel_api_key');
    if ($db_key) {
        define('SENTINEL_API_KEY', $db_key);
    } else {
        define('SENTINEL_API_KEY', 'sentinel_secret_key_default_64_chars_long');
    }
}

class Sentinel {
    
    private static $instance = null;

    /**
     * Obtener instancia Singleton compatible con versiones antiguas de PHP
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Registrar gancho de activación
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Inicializar manejadores
        add_action('plugins_loaded', array($this, 'init_components'));

        // Agregar menú de administración en WordPress
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }

    // Impedir clonación
    private function __clone() {}

    // Impedir deserialización
    private function __wakeup() {}

    /**
     * Se ejecuta al activar el plugin
     */
    public function activate() {
        // Generar una clave aleatoria segura de 64 caracteres con especiales si no existe
        $existing_key = get_option('sentinel_api_key');
        if (!$existing_key) {
            // Longitud 64, con caracteres especiales
            $new_key = wp_generate_password(64, true, true);
            update_option('sentinel_api_key', $new_key);
        }
    }

    /**
     * Registra el menú de administración
     */
    public function add_admin_menu() {
        add_menu_page(
            'Sentinel Dashboard',
            'Sentinel',
            'manage_options',
            'sentinel',
            array($this, 'render_admin_page'),
            'dashicons-shield-alt',
            100
        );
    }

    /**
     * Renderiza la página del panel de control de Sentinel con diseño nativo WordPress 7+ Claro
     */
    public function render_admin_page() {
        $api_key = defined('SENTINEL_API_KEY') ? SENTINEL_API_KEY : get_option('sentinel_api_key');
        $site_url = get_rest_url(null, '/sentinel/v1');
        if (!$site_url) {
            $site_url = site_url('/wp-json/sentinel/v1');
        }

        $uploads = wp_upload_dir();
        $backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        $backups = array();
        if (is_dir($backup_dir)) {
            $files = scandir($backup_dir);
            if (is_array($files)) {
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..' || $file === '.htaccess' || $file === 'index.html') {
                        continue;
                    }
                    $filepath = $backup_dir . $file;
                    if (is_file($filepath)) {
                        $backups[] = array(
                            'name' => $file,
                            'size' => size_format(filesize($filepath)),
                            'date' => date('Y-m-d H:i:s', filemtime($filepath))
                        );
                    }
                }
            }
        }
        ?>
        <div class="wrap sentinel-wrap" style="max-width: 850px; margin: 30px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">
            
            <!-- Estilos WordPress 7+ Light Integrados -->
            <style>
                .sentinel-card {
                    background: #ffffff;
                    color: #2c3338;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 1px 15px rgba(0, 0, 0, 0.05);
                    border: 1px solid #c3c4c7;
                    margin-bottom: 20px;
                }
                .sentinel-header {
                    display: flex;
                    align-items: center;
                    gap: 15px;
                    border-bottom: 1px solid #dcdcde;
                    padding-bottom: 20px;
                    margin-bottom: 25px;
                }
                .sentinel-header h1 {
                    color: #1d2327;
                    font-size: 28px;
                    font-weight: 700;
                    margin: 0;
                    line-height: 1.2;
                }
                .sentinel-badge {
                    background: #00a32a;
                    color: #ffffff;
                    padding: 4px 10px;
                    border-radius: 20px;
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    display: inline-block;
                    margin-top: 5px;
                }
                .sentinel-section {
                    margin-bottom: 20px;
                }
                .sentinel-label {
                    font-size: 13px;
                    color: #50575e;
                    margin-bottom: 6px;
                    font-weight: 600;
                }
                .sentinel-value-box {
                    background: #f0f6fc;
                    border: 1px solid #c3c4c7;
                    padding: 12px 15px;
                    border-radius: 6px;
                    font-family: 'Courier New', Courier, monospace;
                    font-size: 14px;
                    color: #0c3d52;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .sentinel-btn-copy {
                    background: #2271b1;
                    color: #ffffff;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 12px;
                    font-weight: 600;
                    transition: all 0.2s ease;
                }
                .sentinel-btn-copy:hover {
                    background: #135e96;
                }
                .sentinel-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 15px;
                    font-size: 13px;
                }
                .sentinel-table th, .sentinel-table td {
                    padding: 10px;
                    text-align: left;
                    border-bottom: 1px solid #dcdcde;
                }
                .sentinel-table th {
                    background: #f6f7f7;
                    font-weight: 600;
                    color: #1d2327;
                }
            </style>

            <div class="sentinel-card">
                <div class="sentinel-header">
                    <span class="dashicons dashicons-shield-alt" style="font-size: 32px; width: 32px; height: 32px; color: #2271b1;"></span>
                    <div>
                        <h1>Ecosistema Sentinel</h1>
                        <span class="sentinel-badge">Activo</span>
                    </div>
                </div>

                <div class="sentinel-section">
                    <p style="color: #50575e; font-size: 14px; line-height: 1.6;">
                        Sentinel ha autoconfigurado el canal seguro de comunicación con el orquestador externo. Copia las siguientes credenciales para agregarlas en el panel de control de tu orquestador <strong>Sentinel</strong>.
                    </p>
                </div>

                <div class="sentinel-section">
                    <div class="sentinel-label">API Key de Seguridad</div>
                    <div class="sentinel-value-box">
                        <span id="sentinel-api-key"><?php echo esc_html($api_key); ?></span>
                        <button class="sentinel-btn-copy" onclick="copySentinel('sentinel-api-key', this)">Copiar Clave</button>
                    </div>
                </div>

                <div class="sentinel-section">
                    <div class="sentinel-label">Endpoint de Conexión de Sentinel</div>
                    <div class="sentinel-value-box">
                        <span id="sentinel-endpoint"><?php echo esc_url($site_url); ?></span>
                        <button class="sentinel-btn-copy" onclick="copySentinel('sentinel-endpoint', this)">Copiar URL</button>
                    </div>
                </div>
            </div>

            <!-- Sección de Copias de Seguridad Almacenadas en el Hosting -->
            <div class="sentinel-card">
                <h2 style="font-size: 18px; font-weight: 600; margin-top: 0; margin-bottom: 15px; color: #1d2327; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-backup" style="color: #2271b1;"></span>
                    Copias de Seguridad en Hosting
                </h2>
                <p style="color: #50575e; font-size: 13px;">
                    A continuación se listan las copias de seguridad de Base de Datos y de Archivos que se encuentran almacenadas actualmente de forma temporal en este servidor (hosting). Sentinel las limpiará automáticamente una vez que hayan sido descargadas de forma segura y exitosa al disco local del panel central.
                </p>

                <?php if (!empty($backups)): ?>
                    <table class="sentinel-table">
                        <thead>
                            <tr>
                                <th>Nombre del Archivo</th>
                                <th>Tamaño</th>
                                <th>Fecha de Creación</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($backups as $bk): ?>
                                <tr>
                                    <td style="font-family: monospace; font-weight: 600;"><?php echo esc_html($bk['name']); ?></td>
                                    <td><?php echo esc_html($bk['size']); ?></td>
                                    <td><?php echo esc_html($bk['date']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div style="background: #f0f6fc; border-left: 4px solid #72aee6; padding: 15px; margin-top: 15px; font-size: 13px; color: #0c3d52; border-radius: 0 4px 4px 0;">
                        No hay copias de seguridad activas en este servidor de hosting. Todas las copias anteriores han sido sincronizadas y descargadas correctamente.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <script>
            async function copySentinel(elementId, btn) {
                const text = document.getElementById(elementId).innerText;
                try {
                    await navigator.clipboard.writeText(text);
                    const originalText = btn.innerText;
                    btn.innerText = "¡Copiado!";
                    btn.style.background = "#00a32a";
                    setTimeout(() => {
                        btn.innerText = originalText;
                        btn.style.background = "#2271b1";
                    }, 2000);
                } catch (e) {
                    console.error("Error al copiar al portapapeles:", e);
                }
            }
        </script>
        <?php
    }

    /**
     * Inicializa los submódulos de la aplicación
     */
    public function init_components() {
        // Inicializa el manejador de la API REST / AJAX
        if (class_exists('Sentinel_API_Handler')) {
            Sentinel_API_Handler::get_instance();
        }
    }
}

// Iniciar Sentinel
Sentinel::get_instance();
