<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Mysqldump {

    private $db_host;
    private $db_name;
    private $db_user;
    private $db_pass;
    private $backup_path;
    private $task_id;
    private $pdo;

    public function __construct($backup_path, $task_id = '') {
        $this->db_host = DB_HOST;
        $this->db_name = DB_NAME;
        $this->db_user = DB_USER;
        $this->db_pass = DB_PASSWORD;
        $this->backup_path = $backup_path;
        $this->task_id = $task_id;
    }

    private function connect() {
        if ($this->pdo) {
            return true;
        }

        try {
            $host_parts = explode(':', $this->db_host);
            $host = $host_parts[0];
            $port = isset($host_parts[1]) ? $host_parts[1] : '';
            
            $dsn = "mysql:host=$host;";
            if (!empty($port)) {
                $dsn .= "port=$port;";
            }
            $dsn .= "dbname=" . $this->db_name . ";charset=utf8mb4";
            
            $options = array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            );
            
            $this->pdo = new PDO($dsn, $this->db_user, $this->db_pass, $options);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    private function update_task_progress($current_table, $progress) {
        if (empty($this->task_id)) return;
        $task = get_option('sentinel_active_backup_task');
        if (is_array($task)) {
            $task['progress'] = $progress;
            $task['current_table'] = $current_table;
            $task['last_activity'] = time();
            update_option('sentinel_active_backup_task', $task);
        }
    }

    public function dump() {
        @set_time_limit(0);
        $fp = @fopen($this->backup_path, 'w');
        if (!$fp) {
            return array('success' => false, 'message' => 'No se pudo abrir el archivo de respaldo para escritura.');
        }

        // Ecribir cabeceras iniciales
        fwrite($fp, "-- Sentinel PDO Dump v1.0\n");
        fwrite($fp, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($fp, "-- Base de datos: " . $this->db_name . "\n\n");
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fp, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n");
        fwrite($fp, "SET time_zone = \"+00:00\";\n\n");

        $use_pdo = $this->connect();
        
        try {
            if ($use_pdo) {
                $tables_query = $this->pdo->query("SHOW TABLES");
                $tables = $tables_query->fetchAll(PDO::FETCH_COLUMN);
            } else {
                global $wpdb;
                $tables = $wpdb->get_col("SHOW TABLES");
            }

            // Exclusiones estándar inteligentes
            $exclude_patterns = array('wsal_metadata', 'wsal_occurrences', 'actionscheduler_actions', 'actionscheduler_logs', 'yoast_seo_links');
            $filtered_tables = array();
            foreach ($tables as $t) {
                $exclude = false;
                foreach ($exclude_patterns as $p) {
                    if (strpos($t, $p) !== false) {
                        $exclude = true;
                        break;
                    }
                }
                if (!$exclude) {
                    $filtered_tables[] = $t;
                }
            }
            $tables = $filtered_tables;
            $total_tables = count($tables);

            foreach ($tables as $idx => $table) {
                $progress = intval((($idx) / $total_tables) * 100);
                $this->update_task_progress($table, $progress);

                // 1. Estructura de la Tabla
                fwrite($fp, "\n-- Estructura de tabla para `$table`\n");
                fwrite($fp, "DROP TABLE IF EXISTS `$table`;\n");
                
                if ($use_pdo) {
                    $create_res = $this->pdo->query("SHOW CREATE TABLE `$table`")->fetch();
                    $create_sql = $create_res['Create Table'] . ";\n\n";
                } else {
                    global $wpdb;
                    $create_res = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
                    $create_sql = $create_res[1] . ";\n\n";
                }
                fwrite($fp, $create_sql);

                // 2. Datos de la Tabla
                fwrite($fp, "-- Volcado de datos para `$table`\n");
                
                // Obtener llave primaria
                $primary_key = false;
                if ($use_pdo) {
                    $keys = $this->pdo->query("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'")->fetchAll();
                    if (!empty($keys)) {
                        $primary_key = $keys[0]['Column_name'];
                    }
                } else {
                    global $wpdb;
                    $keys = $wpdb->get_results("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
                    if (!empty($keys)) {
                        $primary_key = $keys[0]->Column_name;
                    }
                }

                $offset = 0;
                $limit = 1000;
                $has_rows = true;

                while ($has_rows) {
                    if ($use_pdo) {
                        if ($primary_key) {
                            $stmt = $this->pdo->prepare("SELECT * FROM `$table` WHERE `$primary_key` > :offset ORDER BY `$primary_key` ASC LIMIT :limit");
                            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
                            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
                            $stmt->execute();
                            $rows = $stmt->fetchAll();
                        } else {
                            $stmt = $this->pdo->prepare("SELECT * FROM `$table` LIMIT :offset, :limit");
                            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
                            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
                            $stmt->execute();
                            $rows = $stmt->fetchAll();
                        }
                    } else {
                        global $wpdb;
                        if ($primary_key) {
                            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM `$table` WHERE `$primary_key` > %d ORDER BY `$primary_key` ASC LIMIT %d", $offset, $limit), ARRAY_A);
                        } else {
                            $rows = $wpdb->get_results("SELECT * FROM `$table` LIMIT $offset, $limit", ARRAY_A);
                        }
                    }

                    if (empty($rows)) {
                        $has_rows = false;
                        break;
                    }

                    foreach ($rows as $row) {
                        $keys_arr = array_map(function($k) { return "`$k`"; }, array_keys($row));
                        $vals_arr = array_map(function($v) use ($use_pdo) {
                            if (is_null($v)) {
                                return 'NULL';
                            }
                            if ($use_pdo) {
                                return $this->pdo->quote($v);
                            } else {
                                return "'" . esc_sql($v) . "'";
                            }
                        }, array_values($row));

                        $insert_sql = "INSERT INTO `$table` (" . implode(', ', $keys_arr) . ") VALUES (" . implode(', ', $vals_arr) . ");\n";
                        fwrite($fp, $insert_sql);

                        if ($primary_key) {
                            $offset = $row[$primary_key];
                        }
                    }

                    if (!$primary_key) {
                        $offset += $limit;
                    }
                }
            }

            // Ecribir cabeceras finales
            fwrite($fp, "\nSET FOREIGN_KEY_CHECKS=1;\n");
            fclose($fp);
            $this->update_task_progress('Finalizado', 100);
            return array('success' => true, 'backup_path' => $this->backup_path);

        } catch (Exception $e) {
            fclose($fp);
            @unlink($this->backup_path);
            return array('success' => false, 'message' => 'Error durante el volcado PDO: ' . $e->getMessage());
        }
    }
}
