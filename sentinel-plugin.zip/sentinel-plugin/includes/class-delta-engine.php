<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Delta_Engine {

    /**
     * The instance of the class.
     *
     * @var Sentinel_Delta_Engine|null
     */
    private static $instance = null;

    /**
     * The database handler instance (SQLite).
     *
     * @var Sentinel_SQLite_DB
     */
    private $db_handler;

    /**
     * Get the instance of the class.
     *
     * @return Sentinel_Delta_Engine
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {
        $this->db_handler = Sentinel_SQLite_DB::get_instance();
    }

    /**
     * Get changed chunks since a given timestamp.
     *
     * @param int $timestamp The timestamp to compare against.
     * @return array An associative array of tables with their respective chunks.
     */
    public function get_changed_chunks_since($timestamp) {
        $timestamp = absint($timestamp);

        $sql = "SELECT table_name, chunk_key, hash FROM db_chunks WHERE last_seen >= :timestamp";
        $params = array('timestamp' => $timestamp);

        $results = $this->db_handler->query_files($sql, $params);

        $grouped_results = array();
        if (is_array($results)) {
            foreach ($results as $row) {
                $table = $row['table_name'];
                if (!isset($grouped_results[$table])) {
                    $grouped_results[$table] = array();
                }
                $grouped_results[$table][] = array(
                    'chunk_key' => sanitize_text_field($row['chunk_key']),
                    'hash'      => sanitize_text_field($row['hash']),
                );
            }
        }

        return $grouped_results;
    }

    /**
     * Get a summary of changes in the database.
     *
     * @return array An associative array with the total number of chunks.
     */
    public function get_changes_summary() {
        $sql_total = "SELECT COUNT(*) as total_chunks FROM db_chunks";
        $total_chunks_res = $this->db_handler->query_files($sql_total);
        $total_chunks = !empty($total_chunks_res) ? (int)$total_chunks_res[0]['total_chunks'] : 0;

        $sql_updated = "SELECT COUNT(*) as updated_chunks FROM db_chunks WHERE last_seen IS NOT NULL";
        $updated_chunks_res = $this->db_handler->query_files($sql_updated);
        $updated_chunks = !empty($updated_chunks_res) ? (int)$updated_chunks_res[0]['updated_chunks'] : 0;

        return array(
            'total_chunks'   => $total_chunks,
            'updated_chunks' => $updated_chunks,
        );
    }

    /**
     * Prevent cloning of the instance.
     */
    private function __clone() {}

    /**
     * Prevent unserializing of the instance.
     */
    public function __wakeup() {}
}