<?php
if (!defined('ABSPATH')) {
    exit; // Evitar accesos directos
}

class Sentinel_Database_Recovery {

    /**
     * Instancia única de la clase.
     *
     * @var Sentinel_Database_Recovery
     */
    private static $instance;

    /**
     * Constructor privado para evitar instanciación externa.
     */
    private function __construct() {}

    /**
     * Evitar clonación de la instancia.
     */
    private function __clone() {}

    /**
     * Obtener la instancia única de la clase.
     *
     * @return Sentinel_Database_Recovery
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Restaurar un chunk de datos en una tabla específica.
     *
     * @param string $table_name Nombre de la tabla MySQL de destino.
     * @param string $chunk_data_json Datos del chunk en formato JSON.
     * @param int $chunk_key Rango o identificador del chunk.
     * @return bool|WP_Error
     */
    public function restore_table_chunk($table_name, $chunk_data_json, $chunk_key) {
        global $wpdb;

        // Validar el nombre de la tabla de forma segura consultando dinámicamente las existentes en la base de datos
        $safe_table_name = $wpdb->prefix . sanitize_text_field($table_name);
        $allowed_tables = $wpdb->get_col("SHOW TABLES LIKE '" . esc_sql($wpdb->prefix) . "%'");
        
        if (!in_array($safe_table_name, $allowed_tables)) {
            return new WP_Error('invalid_table', __('Invalid table name.', 'sentinel'));
        }

        // Decodificar el JSON de registros
        $chunk_data = json_decode($chunk_data_json, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($chunk_data)) {
            return new WP_Error('invalid_json', __('Invalid JSON data.', 'sentinel'));
        }

        // Construir consulta UPSERT dinámica adaptada a las columnas reales del chunk de datos
        $first_row = reset($chunk_data);
        $columns = array_keys($first_row);
        
        $escaped_columns = array_map(function($col) {
            return "`" . str_replace("`", "", $col) . "`";
        }, $columns);
        
        $insert_query = "INSERT INTO `$safe_table_name` (" . implode(', ', $escaped_columns) . ") VALUES ";
        
        $update_parts = array_map(function($col) {
            $escaped = str_replace("`", "", $col);
            return "`$escaped` = VALUES(`$escaped`)";
        }, $columns);
        
        $update_query = "ON DUPLICATE KEY UPDATE " . implode(', ', $update_parts);

        $values = array();
        foreach ($chunk_data as $row) {
            $row_values = array();
            foreach ($columns as $col) {
                $val = $row[$col];
                if (is_null($val)) {
                    $row_values[] = "NULL";
                } elseif (is_numeric($val)) {
                    $row_values[] = esc_sql($val);
                } else {
                    $row_values[] = "'" . esc_sql($val) . "'";
                }
            }
            $values[] = "(" . implode(', ', $row_values) . ")";
        }

        if (empty($values)) {
            return new WP_Error('no_data', __('No valid data to insert.', 'sentinel'));
        }

        $query = $insert_query . implode(', ', $values) . ' ' . $update_query;

        // Ejecutar consulta a través del gestor de base de datos de WordPress
        $result = $wpdb->query($query);
        if ($result === false) {
            return new WP_Error('db_error', $wpdb->last_error ?: __('Database error occurred.', 'sentinel'));
        }

        return true;
    }

    /**
     * Restaurar tablas basándose en la categoría.
     *
     * @param string $category Categoría de las tablas ('A', 'B', 'C', 'D', 'E').
     * @return bool|WP_Error
     */
    public function restore_tables_by_category($category) {
        global $wpdb;

        // Validar la categoría
        $allowed_categories = array('A', 'B', 'C', 'D', 'E');
        $safe_category = strtoupper(sanitize_text_field($category));

        if (!in_array($safe_category, $allowed_categories)) {
            return new WP_Error('invalid_category', __('Invalid category.', 'sentinel'));
        }

        // Obtener las tablas correspondientes a la categoría consultando la clasificación calculada en SQLite db_tables
        $sqlite = Sentinel_SQLite_DB::get_instance();
        $results = $sqlite->query_files("SELECT table_name FROM db_tables WHERE classification = :classification", array(
            'classification' => $safe_category
        ));

        if (empty($results) || !is_array($results)) {
            return true; // No hay tablas clasificadas en esta categoría para restaurar
        }

        // Restaurar e integrar cada tabla
        foreach ($results as $row) {
            $table = $row['table_name'];
            if (!$this->verify_table_integrity($table)) {
                return new WP_Error('table_error', sprintf(__('Error verifying table integrity for %s.', 'sentinel'), $table));
            }
        }

        return true;
    }

    /**
     * Verificar la integridad de una tabla.
     *
     * @param string $table_name Nombre de la tabla MySQL.
     * @return bool|WP_Error
     */
    public function verify_table_integrity($table_name) {
        global $wpdb;

        // Validar el nombre de la tabla
        $safe_table_name = $wpdb->prefix . sanitize_text_field($table_name);

        if (!$wpdb->get_var("SHOW TABLES LIKE '$safe_table_name'")) {
            return new WP_Error('table_not_exists', __('Table does not exist.', 'sentinel'));
        }

        // Contar filas actuales
        $row_count = $wpdb->get_var("SELECT COUNT(*) FROM `$safe_table_name`");

        if ($row_count === null) {
            return new WP_Error('db_error', __('Database error occurred.', 'sentinel'));
        }

        // Verificar esquema básico (ejemplo: verificar que la tabla tenga una columna 'id')
        $columns = $wpdb->get_col("SHOW COLUMNS FROM `$safe_table_name` LIKE 'id'");

        if (empty($columns)) {
            return new WP_Error('invalid_schema', __('Invalid table schema.', 'sentinel'));
        }

        return true;
    }
}