<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Backup_DB {

    private $backup_dir;
    private $db_dir;
    private $temp_dir;

    public function __construct() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $this->backup_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $this->backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $this->db_dir = $this->backup_dir . 'db/';
        $this->temp_dir = $this->backup_dir . 'temp/';
        $this->ensure_directory_secured();
    }

    private function ensure_directory_secured() {
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }
        if (!file_exists($this->db_dir)) {
            wp_mkdir_p($this->db_dir);
        }
        if (!file_exists($this->temp_dir)) {
            wp_mkdir_p($this->temp_dir);
        }

        // Asegurar protección en el directorio raíz y subcarpetas
        $dirs_to_secure = array($this->backup_dir, $this->db_dir, $this->temp_dir);
        foreach ($dirs_to_secure as $dir) {
            $htaccess = $dir . '.htaccess';
            if (!file_exists($htaccess)) {
                file_put_contents($htaccess, "deny from all\nOptions -Indexes");
            }

            $index_html = $dir . 'index.html';
            if (!file_exists($index_html)) {
                file_put_contents($index_html, '');
            }
        }
    }

    /**
     * Verifica la disponibilidad de comandos shell y mysqldump
     */
    public function check_environment_support() {
        $exec_enabled = false;
        $mysqldump_available = false;

        // 1. Verificar si exec() está habilitado y no deshabilitado en php.ini
        if (function_exists('exec')) {
            $disabled = explode(',', ini_get('disable_functions'));
            $disabled = array_map('trim', $disabled);
            if (!in_array('exec', $disabled)) {
                $exec_enabled = true;
            }
        }

        // 2. Si exec está habilitado, verificar si mysqldump está disponible
        if ($exec_enabled) {
            $output = array();
            $retval = -1;
            @exec('mysqldump --version', $output, $retval);
            if ($retval === 0) {
                $mysqldump_available = true;
            } else {
                // Intento alternativo buscando rutas comunes
                $common_paths = array('/usr/bin/mysqldump', '/usr/local/bin/mysqldump', '/usr/mysql/bin/mysqldump');
                foreach ($common_paths as $path) {
                    if (@is_executable($path)) {
                        $mysqldump_available = true;
                        break;
                    }
                }
            }
        }

        return array(
            'exec_enabled' => $exec_enabled,
            'mysqldump_available' => $mysqldump_available
        );
    }

    /**
     * Motor A: Volcado rápido en segundo plano usando mysqldump
     */
    public function run_backup_mysqldump() {
        @set_time_limit(0);
        if ($this->is_backup_locked()) {
            return array('success' => false, 'message' => 'Un proceso de respaldo de base de datos ya está en curso (Bloqueo activo).');
        }
        $this->lock_backup();

        $env = $this->check_environment_support();
        
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql.tmp';
        $backup_path = $this->db_dir . $backup_filename;

        $task_id = 'task_db_' . uniqid();
        $task_data = array(
            'id' => $task_id,
            'status' => 'running',
            'progress' => 0,
            'current_table' => 'Inicializando...',
            'method' => ($env['exec_enabled'] && $env['mysqldump_available']) ? 'mysqldump' : 'pdo',
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'start_time' => time(),
            'last_activity' => time()
        );
        update_option('sentinel_active_backup_task', $task_data);

        // Definir la ejecución real del backup
        $run_dump = function() use ($env, $backup_path, $backup_filename, $task_id, &$task_data) {
            $success = false;
            $method_used = 'pdo';
            
            if ($env['exec_enabled'] && $env['mysqldump_available']) {
                $method_used = 'mysqldump';
                // Separar host y puerto
                $host_parts = explode(':', DB_HOST);
                $host = $host_parts[0];
                $port = isset($host_parts[1]) ? $host_parts[1] : '';
                
                $port_flag = !empty($port) ? '--port=' . escapeshellarg($port) : '';
                
                $cmd = sprintf(
                    'mysqldump --host=%s %s --user=%s --password=%s --quick --single-transaction --no-autocommit %s > %s 2>&1',
                    escapeshellarg($host),
                    $port_flag,
                    escapeshellarg(DB_USER),
                    escapeshellarg(DB_PASSWORD),
                    escapeshellarg(DB_NAME),
                    escapeshellarg($backup_path)
                );
                $output = array();
                $retval = -1;
                @exec($cmd, $output, $retval);
                
                if ($retval === 0 && file_exists($backup_path) && filesize($backup_path) > 0) {
                    $success = true;
                } else {
                    // Si falla mysqldump por alguna razón, borrar el temporal para evitar basura
                    @unlink($backup_path);
                }
            }
            
            // Fallback a PDO si mysqldump no está disponible o falló
            if (!$success) {
                $method_used = 'pdo';
                require_once dirname(__FILE__) . '/class-sentinel-mysqldump.php';
                $dumper = new Sentinel_Mysqldump($backup_path, $task_id);
                $res = $dumper->dump();
                if ($res['success']) {
                    $success = true;
                }
            }
            
            if ($success) {
                // Renombrar de .sql.tmp a .sql antes de comprimir
                $final_sql_path = str_replace('.sql.tmp', '.sql', $backup_path);
                if (@rename($backup_path, $final_sql_path)) {
                    $backup_path = $final_sql_path;
                    $backup_filename = basename($final_sql_path);
                }
                
                // Comprimir y liberar bloqueo
                $this->unlock_backup();
                $zip_res = $this->compress_sql_to_zip($backup_path);
                
                if ($zip_res['success']) {
                    $task_data['status'] = 'completed';
                    $task_data['progress'] = 100;
                    $task_data['backup_name'] = $zip_res['zip_name'];
                    $task_data['method'] = $method_used;
                    update_option('sentinel_active_backup_task', $task_data);
                    return array('success' => true, 'zip' => true, 'res' => $zip_res);
                } else {
                    $task_data['status'] = 'completed';
                    $task_data['progress'] = 100;
                    $task_data['backup_name'] = $backup_filename;
                    $task_data['method'] = $method_used;
                    update_option('sentinel_active_backup_task', $task_data);
                    return array('success' => true, 'zip' => false, 'filename' => $backup_filename);
                }
            } else {
                $this->unlock_backup();
                $task_data['status'] = 'failed';
                $task_data['message'] = 'Fallo en la ejecución del volcado (mysqldump y PDO fallaron).';
                update_option('sentinel_active_backup_task', $task_data);
                return array('success' => false);
            }
        };

        if (function_exists('fastcgi_finish_request')) {
            // Retornar éxito inmediato al cliente HTTP y continuar en segundo plano
            if (ob_get_level()) {
                ob_end_clean();
            }
            ob_start();
            echo json_encode(array(
                'success' => true,
                'method' => $task_data['method'],
                'task_id' => $task_id,
                'backup_name' => $backup_filename,
                'message' => 'Respaldo de BD iniciado en segundo plano'
            ));
            $size = ob_get_length();
            header('Content-Type: application/json');
            header("Content-Length: $size");
            header('Connection: close');
            ob_end_flush();
            ob_flush();
            flush();
            fastcgi_finish_request();
            
            // Ejecutar la función en segundo plano
            $run_dump();
            exit;
        } else {
            // Ejecución síncrona
            $res = $run_dump();
            if ($res['success']) {
                $b_name = $res['zip'] ? $res['res']['zip_name'] : $res['filename'];
                $b_path = $res['zip'] ? $res['res']['zip_path'] : ($this->db_dir . $res['filename']);
                return array(
                    'success' => true,
                    'method' => $task_data['method'] . '_sync',
                    'backup_name' => $b_name,
                    'backup_path' => $b_path,
                    'size' => size_format(filesize($b_path))
                );
            }
            return array('success' => false, 'message' => 'Fallo en la ejecución del volcado de base de datos.');
        }
    }

    /**
     * Motor B (Inicializar): Prepara el entorno para el backup iterativo y devuelve las tablas
     */
    public function start_chunk_backup() {
        if ($this->is_backup_locked()) {
            return array('success' => false, 'message' => 'Un proceso de respaldo de base de datos ya está en curso (Bloqueo activo).');
        }
        $this->lock_backup();
        global $wpdb;

        $tables = $wpdb->get_col("SHOW TABLES");
        
        // Exclusiones inteligentes por defecto para evitar timeouts en hostings limitados
        $exclude_patterns = array(
            'wsal_metadata',
            'wsal_occurrences',
            'actionscheduler_actions',
            'actionscheduler_logs',
            'yoast_seo_links'
        );

        $filtered_tables = array();
        foreach ($tables as $table) {
            $exclude = false;
            foreach ($exclude_patterns as $pattern) {
                if (strpos($table, $pattern) !== false) {
                    $exclude = true;
                    break;
                }
            }
            if (!$exclude) {
                $filtered_tables[] = $table;
            }
        }
        $tables = $filtered_tables;
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql.tmp';
        $backup_path = $this->db_dir . $backup_filename;

        $handle = fopen($backup_path, 'w');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo crear el archivo de respaldo.');
        }

        // Escribir cabeceras iniciales
        fwrite($handle, "-- Sentinel DB Chunk Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Host: " . DB_HOST . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        fclose($handle);

        // Retornar lista de tablas para que el panel controle las llamadas iterativas
        return array(
            'success' => true,
            'method' => 'chunk',
            'tables' => $tables,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path
        );
    }

    /**
     * Motor B (Paso Iterativo): Respalda un lote (chunk) de filas de una tabla
     */
    public function backup_table_chunk($table, $offset, $limit, $backup_filename, $write_structure = false) {
        global $wpdb;

        // Validar que la tabla realmente existe en la base de datos para evitar inyección
        $all_tables = $wpdb->get_col("SHOW TABLES");
        if (!in_array($table, $all_tables)) {
            return array('success' => false, 'message' => 'Tabla no válida.');
        }

        $backup_path = $this->db_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo abrir el archivo de respaldo en modo escritura incremental.');
        }

        $buffer = "";

        // 1. Si es la primera iteración de la tabla, volcar la estructura
        if ($write_structure && $offset == 0) {
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            $buffer .= "DROP TABLE IF EXISTS `$table`;\n";
            $buffer .= $create_table[1] . ";\n\n";
        }

        // 2. Obtener la columna de llave primaria para usar Keyset Pagination si es posible
        $primary_key = $this->get_primary_key($table);
        $rows = array();

        if ($primary_key) {
            // Nota: Aquí el $offset actúa como el último id de la llave primaria procesado en el lote anterior
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM `$table` WHERE `$primary_key` > %d ORDER BY `$primary_key` ASC LIMIT %d", $offset, $limit),
                ARRAY_A
            );
        } else {
            // Fallback a Offset Pagination convencional si no hay primary key
            $rows = $wpdb->get_results(
                "SELECT * FROM `$table` LIMIT $offset, $limit",
                ARRAY_A
            );
        }

        if (empty($rows)) {
            fclose($handle);
            return array(
                'success' => true,
                'rows_written' => 0,
                'next_offset' => 0,
                'done' => true
            );
        }

        // 3. Generar sentencias INSERT
        foreach ($rows as $row) {
            $keys = array_map('esc_sql', array_keys($row));
            $values = array_map(array($this, 'clean_value'), array_values($row));
            $buffer .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n";
        }

        fwrite($handle, $buffer);
        fclose($handle);

        $rows_count = count($rows);
        $next_offset = $primary_key ? end($rows)[$primary_key] : $offset + $rows_count;

        return array(
            'success' => true,
            'rows_written' => $rows_count,
            'next_offset' => $next_offset,
            'done' => ($rows_count < $limit)
        );
    }

    /**
     * Motor B (Cierre): Finaliza el volcado escribiendo llaves foráneas activas
     */
    public function finish_chunk_backup($backup_filename) {
        $backup_path = $this->db_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo cerrar la escritura del archivo.');
        }

        fwrite($handle, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);

        // Liberar el semáforo de bloqueo
        $this->unlock_backup();

        // Renombrar de .sql.tmp a .sql antes de comprimir
        $final_sql_path = str_replace('.sql.tmp', '.sql', $backup_path);
        if (@rename($backup_path, $final_sql_path)) {
            $backup_path = $final_sql_path;
            $backup_filename = basename($final_sql_path);
        }

        $zip_res = $this->compress_sql_to_zip($backup_path);
        if ($zip_res['success']) {
            return array(
                'success' => true,
                'backup_name' => $zip_res['zip_name'],
                'backup_path' => $zip_res['zip_path'],
                'size' => size_format(filesize($zip_res['zip_path']))
            );
        }

        return array(
            'success' => true,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'size' => size_format(filesize($backup_path)),
            'message' => 'Backup finalizado pero no se pudo comprimir: ' . $zip_res['message']
        );
    }

    private function get_primary_key($table) {
        global $wpdb;
        $keys = $wpdb->get_results("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
        if (!empty($keys)) {
            return $keys[0]->Column_name;
        }
        return false;
    }

    private function clean_value($value) {
        if (is_null($value)) {
            return 'NULL';
        }
        return "'" . esc_sql($value) . "'";
    }

    /**
     * Verifica si hay un bloqueo de backup activo (archivo db_backup.lock de menos de 10 min)
     */
    private function is_backup_locked() {
        $lock_file = $this->temp_dir . 'db_backup.lock';
        if (!file_exists($lock_file)) {
            return false;
        }
        $now = time();
        $lock_time = filemtime($lock_file);
        if (($now - $lock_time) < 600) {
            return true;
        }
        // Si tiene más de 10 minutos, lo consideramos huérfano y lo eliminamos
        @unlink($lock_file);
        return false;
    }

    /**
     * Crea el archivo de bloqueo
     */
    private function lock_backup() {
        if (!is_dir($this->temp_dir)) {
            wp_mkdir_p($this->temp_dir);
        }
        @file_put_contents($this->temp_dir . 'db_backup.lock', time());
    }

    /**
     * Elimina el archivo de bloqueo
     */
    private function unlock_backup() {
        $lock_file = $this->temp_dir . 'db_backup.lock';
        if (file_exists($lock_file)) {
            @unlink($lock_file);
        }
    }

    /**
     * Comprime un archivo SQL a un archivo ZIP nativo y elimina el SQL original
     */
    public function compress_sql_to_zip($sql_path) {
        if (!file_exists($sql_path)) {
            return array('success' => false, 'message' => 'El archivo SQL no existe.');
        }

        $zip_path = $sql_path . '.zip';
        $sql_filename = basename($sql_path);
        $zip_filename = $sql_filename . '.zip';

        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
                if ($zip->addFile($sql_path, $sql_filename)) {
                    $zip->close();
                    @unlink($sql_path);
                    return array('success' => true, 'zip_path' => $zip_path, 'zip_name' => $zip_filename);
                }
                $zip->close();
            }
        }

        // Fallback a PclZip si ZipArchive no está habilitado en PHP
        if (file_exists($zip_path)) {
            @unlink($zip_path);
        }

        require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        $archive = new PclZip($zip_path);
        $list = $archive->create($sql_path, PCLZIP_OPT_REMOVE_PATH, dirname($sql_path));
        
        if ($list != 0) {
            @unlink($sql_path);
            return array('success' => true, 'zip_path' => $zip_path, 'zip_name' => $zip_filename);
        }

        return array('success' => false, 'message' => 'No se pudo inicializar la compresión con ZipArchive ni PclZip.');
    }

    /**
     * Inicia el proceso de backup de base de datos asíncrono mediante Chained Loopbacks
     */
    public function start_async_backup() {
        if ($this->is_backup_locked()) {
            return array('success' => false, 'message' => 'Un proceso de respaldo de base de datos ya está en curso (Bloqueo activo).');
        }
        $this->lock_backup();
        global $wpdb;

        $tables = $wpdb->get_col("SHOW TABLES");
        
        // Exclusiones inteligentes
        $exclude_patterns = array(
            'wsal_metadata',
            'wsal_occurrences',
            'actionscheduler_actions',
            'actionscheduler_logs',
            'yoast_seo_links'
        );

        $filtered_tables = array();
        foreach ($tables as $table) {
            $exclude = false;
            foreach ($exclude_patterns as $pattern) {
                if (strpos($table, $pattern) !== false) {
                    $exclude = true;
                    break;
                }
            }
            if (!$exclude) {
                $filtered_tables[] = $table;
            }
        }
        $tables = $filtered_tables;

        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql.tmp';
        $backup_path = $this->db_dir . $backup_filename;

        $handle = fopen($backup_path, 'w');
        if (!$handle) {
            $this->unlock_backup();
            return array('success' => false, 'message' => 'No se pudo crear el archivo de respaldo en el disco.');
        }

        // Escribir cabeceras iniciales
        fwrite($handle, "-- Sentinel DB Async Loopback Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Host: " . DB_HOST . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        fclose($handle);

        $task_id = 'task_db_' . uniqid();
        $task_data = array(
            'id' => $task_id,
            'status' => 'running',
            'progress' => 0,
            'current_table' => 'Inicializando...',
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'tables_queue' => $tables,
            'total_tables' => count($tables),
            'processed_tables_count' => 0,
            'current_table_index' => 0,
            'current_table_offset' => 0,
            'write_structure' => true,
            'start_time' => time(),
            'last_activity' => time()
        );
        update_option('sentinel_active_backup_task', $task_data);

        // Disparar el primer paso asíncrono
        $this->dispatch_async_loopback();

        return array(
            'success' => true,
            'method' => 'async_loopback',
            'task_id' => $task_id,
            'backup_name' => $backup_filename,
            'message' => 'Backup de base de datos iniciado en segundo plano de forma autónoma'
        );
    }

    /**
     * Procesa un lote iterativo de la tabla actual y encadena el siguiente loopback
     */
    public function process_async_backup_step() {
        $task_data = get_option('sentinel_active_backup_task');
        if (!$task_data || $task_data['status'] !== 'running') {
            return array('success' => false, 'message' => 'No hay tareas asíncronas activas.');
        }

        $task_data['last_activity'] = time();
        $tables = $task_data['tables_queue'];
        $current_table_index = intval($task_data['current_table_index']);
        $total_tables = intval($task_data['total_tables']);
        $offset = $task_data['current_table_offset'];
        $write_structure = (bool)$task_data['write_structure'];
        $backup_filename = $task_data['backup_name'];

        // Si ya terminamos todas las tablas
        if ($current_table_index >= $total_tables) {
            $finish_res = $this->finish_chunk_backup($backup_filename);
            if ($finish_res['success']) {
                $task_data['status'] = 'completed';
                $task_data['progress'] = 100;
                $task_data['backup_name'] = $finish_res['backup_name'];
                $task_data['current_table'] = 'Finalizado';
            } else {
                $task_data['status'] = 'failed';
                $task_data['message'] = isset($finish_res['message']) ? $finish_res['message'] : 'Fallo al empaquetar backup.';
            }
            update_option('sentinel_active_backup_task', $task_data);
            return $finish_res;
        }

        $table = $tables[$current_table_index];
        $task_data['current_table'] = $table;
        
        $limit = 2000; // Límite seguro de filas por request
        $step_res = $this->backup_table_chunk($table, $offset, $limit, $backup_filename, $write_structure);

        if ($step_res['success']) {
            $done = $step_res['done'];
            $next_offset = $step_res['next_offset'];

            if ($done) {
                // Avanzar a la siguiente tabla
                $task_data['current_table_index'] = $current_table_index + 1;
                $task_data['current_table_offset'] = 0;
                $task_data['write_structure'] = true;
                
                $progress = intval((($current_table_index + 1) / $total_tables) * 95);
                $task_data['progress'] = min(95, $progress);
            } else {
                // Continuar con la misma tabla
                $task_data['current_table_offset'] = $next_offset;
                $task_data['write_structure'] = false;
            }

            update_option('sentinel_active_backup_task', $task_data);
            
            // Disparar el siguiente loopback asíncrono
            $this->dispatch_async_loopback();

            return array(
                'success' => true,
                'table' => $table,
                'offset' => $offset,
                'done' => $done
            );
        } else {
            // Registrar error y liberar bloqueo
            $task_data['status'] = 'failed';
            $task_data['message'] = isset($step_res['message']) ? $step_res['message'] : 'Fallo procesando tabla: ' . $table;
            update_option('sentinel_active_backup_task', $task_data);
            $this->unlock_backup();
            return array('success' => false, 'message' => 'Fallo al procesar fragmento.');
        }
    }

    /**
     * Envía una petición HTTP POST asíncrona y no bloqueante a sí mismo
     */
    private function dispatch_async_loopback() {
        $secret = get_option('controlcenter_agent_secret');
        $endpoint = site_url('wp-json/sentinel/v1/backup/db/async/step');
        
        $args = array(
            'timeout'   => 0.5,
            'blocking'  => false,
            'sslverify' => false,
            'headers'   => array(
                'X-Sentinel-API-Key' => $secret,
                'Authorization'      => 'Bearer ' . $secret,
                'Content-Type'       => 'application/json'
            ),
            'body'      => json_encode(array('action' => 'continue'))
        );
        
        wp_remote_post($endpoint, $args);
    }
}
