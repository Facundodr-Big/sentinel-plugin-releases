<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Backup_DB {

    private $backup_dir;

    public function __construct() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $this->backup_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $this->backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $this->ensure_directory_secured();
    }

    private function ensure_directory_secured() {
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        $htaccess = $this->backup_dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "deny from all\nOptions -Indexes");
        }

        $index_html = $this->backup_dir . 'index.html';
        if (!file_exists($index_html)) {
            file_put_contents($index_html, '');
        }
    }

    /**
     * Verifica la disponibilidad de comandos shell y mysqldump
     */
    public function check_environment_support() {
        $exec_enabled = false;
        $mysqldump_available = false;

        // 1. Verificar si exec() está habilitado y no deshabilitado en php.ini
        if (function_exists('exec')) {
            $disabled = explode(',', ini_get('disable_functions'));
            $disabled = array_map('trim', $disabled);
            if (!in_array('exec', $disabled)) {
                $exec_enabled = true;
            }
        }

        // 2. Si exec está habilitado, verificar si mysqldump está disponible
        if ($exec_enabled) {
            $output = array();
            $retval = -1;
            @exec('mysqldump --version', $output, $retval);
            if ($retval === 0) {
                $mysqldump_available = true;
            } else {
                // Intento alternativo buscando rutas comunes
                $common_paths = array('/usr/bin/mysqldump', '/usr/local/bin/mysqldump', '/usr/mysql/bin/mysqldump');
                foreach ($common_paths as $path) {
                    if (@is_executable($path)) {
                        $mysqldump_available = true;
                        break;
                    }
                }
            }
        }

        return array(
            'exec_enabled' => $exec_enabled,
            'mysqldump_available' => $mysqldump_available
        );
    }

    /**
     * Motor A: Volcado rápido en segundo plano usando mysqldump
     */
    public function run_backup_mysqldump() {
        @set_time_limit(0);
        $env = $this->check_environment_support();
        if (!$env['exec_enabled'] || !$env['mysqldump_available']) {
            return array('success' => false, 'message' => 'mysqldump no está disponible en este servidor.');
        }

        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql';
        $backup_path = $this->backup_dir . $backup_filename;
        $temp_backup_path = $backup_path . '.tmp';

        $is_win = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
        $rename_cmd = $is_win 
            ? 'move ' . escapeshellarg($temp_backup_path) . ' ' . escapeshellarg($backup_path)
            : 'mv ' . escapeshellarg($temp_backup_path) . ' ' . escapeshellarg($backup_path);

        // Construir comando de mysqldump con parámetros de wp-config.php
        $cmd = sprintf(
            '(mysqldump --host=%s --user=%s --password=%s --quick --single-transaction --no-autocommit %s > %s 2>&1 && %s) &',
            escapeshellarg(DB_HOST),
            escapeshellarg(DB_USER),
            escapeshellarg(DB_PASSWORD),
            escapeshellarg(DB_NAME),
            escapeshellarg($temp_backup_path),
            $rename_cmd
        );

        @exec($cmd);

        // Pequeña espera para verificar si el proceso falló de inmediato
        usleep(500000); // 0.5 segundos

        if (file_exists($temp_backup_path) && filesize($temp_backup_path) > 0) {
            return array(
                'success' => true,
                'method' => 'mysqldump',
                'backup_name' => $backup_filename,
                'backup_path' => $backup_path,
                'size' => 'En proceso...'
            );
        }

        return array('success' => false, 'message' => 'Falló la ejecución inicial del comando mysqldump.');
    }

    /**
     * Motor B (Inicializar): Prepara el entorno para el backup iterativo y devuelve las tablas
     */
    public function start_chunk_backup() {
        global $wpdb;

        $tables = $wpdb->get_col("SHOW TABLES");
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql';
        $backup_path = $this->backup_dir . $backup_filename;

        $handle = fopen($backup_path, 'w');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo crear el archivo de respaldo.');
        }

        // Escribir cabeceras iniciales
        fwrite($handle, "-- Sentinel DB Chunk Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Host: " . DB_HOST . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        fclose($handle);

        // Retornar lista de tablas para que el panel controle las llamadas iterativas
        return array(
            'success' => true,
            'method' => 'chunk',
            'tables' => $tables,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path
        );
    }

    /**
     * Motor B (Paso Iterativo): Respalda un lote (chunk) de filas de una tabla
     */
    public function backup_table_chunk($table, $offset, $limit, $backup_filename, $write_structure = false) {
        global $wpdb;

        // Validar que la tabla realmente existe en la base de datos para evitar inyección
        $all_tables = $wpdb->get_col("SHOW TABLES");
        if (!in_array($table, $all_tables)) {
            return array('success' => false, 'message' => 'Tabla no válida.');
        }

        $backup_path = $this->backup_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo abrir el archivo de respaldo en modo escritura incremental.');
        }

        $buffer = "";

        // 1. Si es la primera iteración de la tabla, volcar la estructura
        if ($write_structure && $offset == 0) {
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            $buffer .= "DROP TABLE IF EXISTS `$table`;\n";
            $buffer .= $create_table[1] . ";\n\n";
        }

        // 2. Obtener la columna de llave primaria para usar Keyset Pagination si es posible
        $primary_key = $this->get_primary_key($table);
        $rows = array();

        if ($primary_key) {
            // Nota: Aquí el $offset actúa como el último id de la llave primaria procesado en el lote anterior
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM `$table` WHERE `$primary_key` > %d ORDER BY `$primary_key` ASC LIMIT %d", $offset, $limit),
                ARRAY_A
            );
        } else {
            // Fallback a Offset Pagination convencional si no hay primary key
            $rows = $wpdb->get_results(
                "SELECT * FROM `$table` LIMIT $offset, $limit",
                ARRAY_A
            );
        }

        if (empty($rows)) {
            fclose($handle);
            return array(
                'success' => true,
                'rows_written' => 0,
                'next_offset' => 0,
                'done' => true
            );
        }

        // 3. Generar sentencias INSERT
        foreach ($rows as $row) {
            $keys = array_map('esc_sql', array_keys($row));
            $values = array_map(array($this, 'clean_value'), array_values($row));
            $buffer .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n";
        }

        fwrite($handle, $buffer);
        fclose($handle);

        $rows_count = count($rows);
        $next_offset = $primary_key ? end($rows)[$primary_key] : $offset + $rows_count;

        return array(
            'success' => true,
            'rows_written' => $rows_count,
            'next_offset' => $next_offset,
            'done' => ($rows_count < $limit)
        );
    }

    /**
     * Motor B (Cierre): Finaliza el volcado escribiendo llaves foráneas activas
     */
    public function finish_chunk_backup($backup_filename) {
        $backup_path = $this->backup_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo cerrar la escritura del archivo.');
        }

        fwrite($handle, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);

        return array(
            'success' => true,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'size' => size_format(filesize($backup_path))
        );
    }

    private function get_primary_key($table) {
        global $wpdb;
        $keys = $wpdb->get_results("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
        if (!empty($keys)) {
            return $keys[0]->Column_name;
        }
        return false;
    }

    private function clean_value($value) {
        if (is_null($value)) {
            return 'NULL';
        }
        return "'" . esc_sql($value) . "'";
    }
}
