<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Backup_DB {

    private $backup_dir;

    public function __construct() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $this->backup_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $this->backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $this->ensure_directory_secured();
    }

    /**
     * Asegura la creación y protección del directorio
     */
    private function ensure_directory_secured() {
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        $htaccess = $this->backup_dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "deny from all\nOptions -Indexes");
        }

        $index_html = $this->backup_dir . 'index.html';
        if (!file_exists($index_html)) {
            file_put_contents($index_html, '');
        }
    }

    /**
     * Realiza un volcado de base de datos asíncrono / iterativo
     */
    public function run_backup() {
        global $wpdb;

        // Nombre del backup de base de datos
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql';
        $backup_path = $this->backup_dir . $backup_filename;

        $handle = fopen($backup_path, 'w');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo abrir el archivo de respaldo para escritura.');
        }

        // Obtener todas las tablas de la base de datos
        $tables = $wpdb->get_col("SHOW TABLES");

        // Cabecera del dump SQL
        fwrite($handle, "-- Sentinel DB Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Host: " . DB_HOST . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");

        $buffer = "";
        $buffer_limit = 512 * 1024; // Buffer de 512 KB para acumular escrituras

        foreach ($tables as $table) {
            // Estructura de la tabla (CREATE TABLE)
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            $buffer .= "DROP TABLE IF EXISTS `$table`;\n";
            $buffer .= $create_table[1] . ";\n\n";

            $primary_key = $this->get_primary_key($table);
            $limit = 1000;

            if ($primary_key) {
                // Keyset Pagination: Paginación ultra-rápida basada en índice primario
                $last_id = 0;
                while (true) {
                    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM `$table` WHERE `$primary_key` > %d ORDER BY `$primary_key` ASC LIMIT %d", $last_id, $limit), ARRAY_A);
                    if (empty($rows)) {
                        break;
                    }

                    foreach ($rows as $row) {
                        $keys = array_map('esc_sql', array_keys($row));
                        $values = array_map(array($this, 'clean_value'), array_values($row));
                        $buffer .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n";
                        
                        if (strlen($buffer) >= $buffer_limit) {
                            fwrite($handle, $buffer);
                            $buffer = "";
                        }
                    }

                    $last_id = end($rows)[$primary_key];
                }
            } else {
                // Fallback a paginación tradicional si la tabla no tiene PRIMARY KEY
                $row_count = $wpdb->get_var("SELECT COUNT(*) FROM `$table`");
                $offset = 0;

                while ($offset < $row_count) {
                    $rows = $wpdb->get_results("SELECT * FROM `$table` LIMIT $offset, $limit", ARRAY_A);
                    if (empty($rows)) {
                        break;
                    }

                    foreach ($rows as $row) {
                        $keys = array_map('esc_sql', array_keys($row));
                        $values = array_map(array($this, 'clean_value'), array_values($row));
                        $buffer .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n";

                        if (strlen($buffer) >= $buffer_limit) {
                            fwrite($handle, $buffer);
                            $buffer = "";
                        }
                    }
                    $offset += $limit;
                }
            }
            $buffer .= "\n\n";
        }

        $buffer .= "SET FOREIGN_KEY_CHECKS=1;\n";
        
        // Escribir remanente del buffer
        if (!empty($buffer)) {
            fwrite($handle, $buffer);
        }
        
        fclose($handle);

        return array(
            'success'     => true,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'size'        => size_format(filesize($backup_path))
        );
    }

    /**
     * Obtiene el nombre de la columna PRIMARY KEY si existe
     */
    private function get_primary_key($table) {
        global $wpdb;
        $keys = $wpdb->get_results("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
        if (!empty($keys)) {
            return $keys[0]->Column_name;
        }
        return false;
    }

    /**
     * Limpia los valores para ser inyectados de forma segura en el archivo SQL
     */
    private function clean_value($value) {
        if (is_null($value)) {
            return 'NULL';
        }
        global $wpdb;
        return "'" . esc_sql($value) . "'";
    }
}
