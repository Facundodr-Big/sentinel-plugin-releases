<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Backup_DB {

    private $backup_dir;

    public function __construct() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $this->backup_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $this->backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $this->ensure_directory_secured();
    }

    private function ensure_directory_secured() {
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        $htaccess = $this->backup_dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "deny from all\nOptions -Indexes");
        }

        $index_html = $this->backup_dir . 'index.html';
        if (!file_exists($index_html)) {
            file_put_contents($index_html, '');
        }
    }

    /**
     * Verifica la disponibilidad de comandos shell y mysqldump
     */
    public function check_environment_support() {
        $exec_enabled = false;
        $mysqldump_available = false;

        // 1. Verificar si exec() está habilitado y no deshabilitado en php.ini
        if (function_exists('exec')) {
            $disabled = explode(',', ini_get('disable_functions'));
            $disabled = array_map('trim', $disabled);
            if (!in_array('exec', $disabled)) {
                $exec_enabled = true;
            }
        }

        // 2. Si exec está habilitado, verificar si mysqldump está disponible
        if ($exec_enabled) {
            $output = array();
            $retval = -1;
            @exec('mysqldump --version', $output, $retval);
            if ($retval === 0) {
                $mysqldump_available = true;
            } else {
                // Intento alternativo buscando rutas comunes
                $common_paths = array('/usr/bin/mysqldump', '/usr/local/bin/mysqldump', '/usr/mysql/bin/mysqldump');
                foreach ($common_paths as $path) {
                    if (@is_executable($path)) {
                        $mysqldump_available = true;
                        break;
                    }
                }
            }
        }

        return array(
            'exec_enabled' => $exec_enabled,
            'mysqldump_available' => $mysqldump_available
        );
    }

    /**
     * Motor A: Volcado rápido en segundo plano usando mysqldump
     */
    public function run_backup_mysqldump() {
        @set_time_limit(0);
        if ($this->is_backup_locked()) {
            return array('success' => false, 'message' => 'Un proceso de respaldo de base de datos ya está en curso (Bloqueo activo).');
        }
        
        $env = $this->check_environment_support();
        
        // Usar siempre el motor PDO nativo robusto (asíncrono o síncrono) por defecto
        require_once dirname(__FILE__) . '/class-sentinel-mysqldump.php';
        
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql.tmp';
        $backup_path = $this->backup_dir . $backup_filename;

        $task_id = 'task_db_' . uniqid();
        $task_data = array(
            'id' => $task_id,
            'status' => 'running',
            'progress' => 0,
            'current_table' => 'Inicializando...',
            'method' => 'pdo',
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'start_time' => time(),
            'last_activity' => time()
        );
        update_option('sentinel_active_backup_task', $task_data);

        if (function_exists('fastcgi_finish_request')) {
            // Retornar éxito inmediato al cliente HTTP y continuar el hilo en segundo plano
            if (ob_get_level()) {
                ob_end_clean();
            }
            ob_start();
            echo json_encode(array(
                'success' => true,
                'method' => 'pdo',
                'task_id' => $task_id,
                'backup_name' => $backup_filename,
                'message' => 'Volcado PDO iniciado en segundo plano'
            ));
            $size = ob_get_length();
            header('Content-Type: application/json');
            header("Content-Length: $size");
            header('Connection: close');
            ob_end_flush();
            ob_flush();
            flush();
            fastcgi_finish_request();
            
            // Ejecución asíncrona
            $dumper = new Sentinel_Mysqldump($backup_path, $task_id);
            $res = $dumper->dump();
            if ($res['success']) {
                $final_sql_path = str_replace('.sql.tmp', '.sql', $backup_path);
                if (@rename($backup_path, $final_sql_path)) {
                    $backup_path = $final_sql_path;
                    $backup_filename = basename($final_sql_path);
                }
                $zip_res = $this->compress_sql_to_zip($backup_path);
                if ($zip_res['success']) {
                    $task_data['status'] = 'completed';
                    $task_data['progress'] = 100;
                    $task_data['backup_name'] = $zip_res['zip_name'];
                    update_option('sentinel_active_backup_task', $task_data);
                } else {
                    $task_data['status'] = 'completed';
                    $task_data['progress'] = 100;
                    $task_data['backup_name'] = $backup_filename;
                    update_option('sentinel_active_backup_task', $task_data);
                }
            } else {
                $task_data['status'] = 'failed';
                $task_data['message'] = $res['message'];
                update_option('sentinel_active_backup_task', $task_data);
            }
            exit;
        } else {
            // Fallback síncrono si no hay soporte de FPM/fastcgi_finish_request
            $dumper = new Sentinel_Mysqldump($backup_path, $task_id);
            $res = $dumper->dump();
            if ($res['success']) {
                $final_sql_path = str_replace('.sql.tmp', '.sql', $backup_path);
                if (@rename($backup_path, $final_sql_path)) {
                    $backup_path = $final_sql_path;
                    $backup_filename = basename($final_sql_path);
                }
                $zip_res = $this->compress_sql_to_zip($backup_path);
                if ($zip_res['success']) {
                    $task_data['status'] = 'completed';
                    $task_data['progress'] = 100;
                    $task_data['backup_name'] = $zip_res['zip_name'];
                    update_option('sentinel_active_backup_task', $task_data);
                    
                    return array(
                        'success' => true,
                        'method' => 'pdo_sync',
                        'backup_name' => $zip_res['zip_name'],
                        'backup_path' => $zip_res['zip_path'],
                        'size' => size_format(filesize($zip_res['zip_path']))
                    );
                }
            }
            return array('success' => false, 'message' => isset($res['message']) ? $res['message'] : 'Fallo en volcado PDO síncrono');
        }
    }

    /**
     * Motor B (Inicializar): Prepara el entorno para el backup iterativo y devuelve las tablas
     */
    public function start_chunk_backup() {
        if ($this->is_backup_locked()) {
            return array('success' => false, 'message' => 'Un proceso de respaldo de base de datos ya está en curso (Bloqueo activo).');
        }
        global $wpdb;

        $tables = $wpdb->get_col("SHOW TABLES");
        
        // Exclusiones inteligentes por defecto para evitar timeouts en hostings limitados
        $exclude_patterns = array(
            'wsal_metadata',
            'wsal_occurrences',
            'actionscheduler_actions',
            'actionscheduler_logs',
            'yoast_seo_links'
        );

        $filtered_tables = array();
        foreach ($tables as $table) {
            $exclude = false;
            foreach ($exclude_patterns as $pattern) {
                if (strpos($table, $pattern) !== false) {
                    $exclude = true;
                    break;
                }
            }
            if (!$exclude) {
                $filtered_tables[] = $table;
            }
        }
        $tables = $filtered_tables;
        $backup_filename = 'backup_db_' . date('Ymd_His') . '.sql.tmp';
        $backup_path = $this->backup_dir . $backup_filename;

        $handle = fopen($backup_path, 'w');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo crear el archivo de respaldo.');
        }

        // Escribir cabeceras iniciales
        fwrite($handle, "-- Sentinel DB Chunk Backup\n");
        fwrite($handle, "-- Fecha: " . date('Y-m-d H:i:s') . "\n");
        fwrite($handle, "-- Host: " . DB_HOST . "\n\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        fclose($handle);

        // Retornar lista de tablas para que el panel controle las llamadas iterativas
        return array(
            'success' => true,
            'method' => 'chunk',
            'tables' => $tables,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path
        );
    }

    /**
     * Motor B (Paso Iterativo): Respalda un lote (chunk) de filas de una tabla
     */
    public function backup_table_chunk($table, $offset, $limit, $backup_filename, $write_structure = false) {
        global $wpdb;

        // Validar que la tabla realmente existe en la base de datos para evitar inyección
        $all_tables = $wpdb->get_col("SHOW TABLES");
        if (!in_array($table, $all_tables)) {
            return array('success' => false, 'message' => 'Tabla no válida.');
        }

        $backup_path = $this->backup_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo abrir el archivo de respaldo en modo escritura incremental.');
        }

        $buffer = "";

        // 1. Si es la primera iteración de la tabla, volcar la estructura
        if ($write_structure && $offset == 0) {
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            $buffer .= "DROP TABLE IF EXISTS `$table`;\n";
            $buffer .= $create_table[1] . ";\n\n";
        }

        // 2. Obtener la columna de llave primaria para usar Keyset Pagination si es posible
        $primary_key = $this->get_primary_key($table);
        $rows = array();

        if ($primary_key) {
            // Nota: Aquí el $offset actúa como el último id de la llave primaria procesado en el lote anterior
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM `$table` WHERE `$primary_key` > %d ORDER BY `$primary_key` ASC LIMIT %d", $offset, $limit),
                ARRAY_A
            );
        } else {
            // Fallback a Offset Pagination convencional si no hay primary key
            $rows = $wpdb->get_results(
                "SELECT * FROM `$table` LIMIT $offset, $limit",
                ARRAY_A
            );
        }

        if (empty($rows)) {
            fclose($handle);
            return array(
                'success' => true,
                'rows_written' => 0,
                'next_offset' => 0,
                'done' => true
            );
        }

        // 3. Generar sentencias INSERT
        foreach ($rows as $row) {
            $keys = array_map('esc_sql', array_keys($row));
            $values = array_map(array($this, 'clean_value'), array_values($row));
            $buffer .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n";
        }

        fwrite($handle, $buffer);
        fclose($handle);

        $rows_count = count($rows);
        $next_offset = $primary_key ? end($rows)[$primary_key] : $offset + $rows_count;

        return array(
            'success' => true,
            'rows_written' => $rows_count,
            'next_offset' => $next_offset,
            'done' => ($rows_count < $limit)
        );
    }

    /**
     * Motor B (Cierre): Finaliza el volcado escribiendo llaves foráneas activas
     */
    public function finish_chunk_backup($backup_filename) {
        $backup_path = $this->backup_dir . sanitize_file_name($backup_filename);
        $handle = fopen($backup_path, 'a+');
        if (!$handle) {
            return array('success' => false, 'message' => 'No se pudo cerrar la escritura del archivo.');
        }

        fwrite($handle, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);

        // Renombrar de .sql.tmp a .sql antes de comprimir
        $final_sql_path = str_replace('.sql.tmp', '.sql', $backup_path);
        if (@rename($backup_path, $final_sql_path)) {
            $backup_path = $final_sql_path;
            $backup_filename = basename($final_sql_path);
        }

        $zip_res = $this->compress_sql_to_zip($backup_path);
        if ($zip_res['success']) {
            return array(
                'success' => true,
                'backup_name' => $zip_res['zip_name'],
                'backup_path' => $zip_res['zip_path'],
                'size' => size_format(filesize($zip_res['zip_path']))
            );
        }

        return array(
            'success' => true,
            'backup_name' => $backup_filename,
            'backup_path' => $backup_path,
            'size' => size_format(filesize($backup_path)),
            'message' => 'Backup finalizado pero no se pudo comprimir: ' . $zip_res['message']
        );
    }

    private function get_primary_key($table) {
        global $wpdb;
        $keys = $wpdb->get_results("SHOW KEYS FROM `$table` WHERE Key_name = 'PRIMARY'");
        if (!empty($keys)) {
            return $keys[0]->Column_name;
        }
        return false;
    }

    private function clean_value($value) {
        if (is_null($value)) {
            return 'NULL';
        }
        return "'" . esc_sql($value) . "'";
    }

    /**
     * Verifica si hay un bloqueo de backup activo (archivos .tmp de menos de 10 min)
     */
    private function is_backup_locked() {
        if (!is_dir($this->backup_dir)) {
            return false;
        }
        $files = @scandir($this->backup_dir);
        if ($files === false) {
            return false;
        }
        $now = time();
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'tmp') {
                $file_path = $this->backup_dir . $file;
                if (file_exists($file_path) && ($now - filemtime($file_path)) < 600) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Comprime un archivo SQL a un archivo ZIP nativo y elimina el SQL original
     */
    public function compress_sql_to_zip($sql_path) {
        if (!file_exists($sql_path)) {
            return array('success' => false, 'message' => 'El archivo SQL no existe.');
        }

        $zip_path = $sql_path . '.zip';
        $sql_filename = basename($sql_path);
        $zip_filename = $sql_filename . '.zip';

        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
                if ($zip->addFile($sql_path, $sql_filename)) {
                    $zip->close();
                    @unlink($sql_path);
                    return array('success' => true, 'zip_path' => $zip_path, 'zip_name' => $zip_filename);
                }
                $zip->close();
            }
        }

        // Fallback a PclZip si ZipArchive no está habilitado en PHP
        if (file_exists($zip_path)) {
            @unlink($zip_path);
        }

        require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        $archive = new PclZip($zip_path);
        $list = $archive->create($sql_path, PCLZIP_OPT_REMOVE_PATH, dirname($sql_path));
        
        if ($list != 0) {
            @unlink($sql_path);
            return array('success' => true, 'zip_path' => $zip_path, 'zip_name' => $zip_filename);
        }

        return array('success' => false, 'message' => 'No se pudo inicializar la compresión con ZipArchive ni PclZip.');
    }
}
