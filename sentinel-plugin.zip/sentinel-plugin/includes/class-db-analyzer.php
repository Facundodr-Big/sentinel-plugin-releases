<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_DB_Analyzer {

    /**
     * The instance of the class.
     *
     * @var Sentinel_DB_Analyzer|null
     */
    private static $instance = null;

    /**
     * Get the instance of the class.
     *
     * @return Sentinel_DB_Analyzer
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation.
     */
    private function __construct() {}

    /**
     * Analyze the database and save the results in SQLite.
     *
     * @return array
     */
    public function analyze_database() {
        global $wpdb;

        $analysis_results = [];
        $sqlite = Sentinel_SQLite_DB::get_instance();

        try {
            // Execute the query to get table status.
            $table_status = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);

            if (empty($table_status)) {
                throw new Exception('No tables found in the database.');
            }

            foreach ($table_status as $table_info) {
                // Extract necessary information from each table.
                $table_name = sanitize_text_field($table_info['Name']);
                $rows       = isset($table_info['Rows']) ? absint($table_info['Rows']) : 0;
                
                $data_length = isset($table_info['Data_length']) ? floatval($table_info['Data_length']) : 0;
                $index_length = isset($table_info['Index_length']) ? floatval($table_info['Index_length']) : 0;
                $size_mb    = round(($data_length + $index_length) / (1024 * 1024), 2);
                
                $engine     = isset($table_info['Engine']) ? sanitize_text_field($table_info['Engine']) : 'unknown';
                $collation  = isset($table_info['Collation']) ? sanitize_text_field($table_info['Collation']) : 'unknown';

                // Insert data into SQLite db_growth_history
                $sqlite->query_files(
                    "INSERT INTO db_growth_history (table_name, rows_count, timestamp) VALUES (:table_name, :rows_count, :timestamp)",
                    array(
                        'table_name' => $table_name,
                        'rows_count' => $rows,
                        'timestamp'  => time()
                    )
                );

                // Add to analysis results.
                $analysis_results[] = [
                    'table_name' => $table_name,
                    'rows'       => $rows,
                    'size_mb'    => $size_mb,
                    'engine'     => $engine,
                    'collation'  => $collation,
                ];
            }
        } catch (Exception $e) {
            error_log('Database analysis failed: ' . $e->getMessage());
            return [];
        }

        return $analysis_results;
    }
}