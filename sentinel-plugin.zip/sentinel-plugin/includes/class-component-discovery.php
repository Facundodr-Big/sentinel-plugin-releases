<?php
/**
 * Sentinel_Component_Discovery Class
 *
 * This class is responsible for discovering components of a WordPress installation,
 * including the core, plugins, and themes.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Component_Discovery {

    /**
     * The singleton instance of this class.
     *
     * @var Sentinel_Component_Discovery
     */
    private static $instance;

    /**
     * Get the singleton instance of this class.
     *
     * @return Sentinel_Component_Discovery
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {}

    /**
     * Discover components of the WordPress installation.
     *
     * @return array An associative array with core, plugins, and themes information.
     */
    public function discover_components() {
        $components = [
            'core' => [],
            'plugins' => [],
            'themes' => [],
        ];

        // Core Information
        $components['core'] = [
            'version' => $this->get_core_version(),
            'path'    => str_replace('\\', '/', ABSPATH),
        ];

        // Plugins Information
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $wp_plugin_dir = str_replace('\\', '/', WP_PLUGIN_DIR);

        foreach ($all_plugins as $plugin_file => $plugin_data) {
            $components['plugins'][] = [
                'id'      => $plugin_file,
                'name'    => esc_html($plugin_data['Name']),
                'version' => esc_html($plugin_data['Version']),
                'status'  => is_plugin_active($plugin_file) ? 'active' : 'inactive',
                'path'    => $wp_plugin_dir . '/' . str_replace('\\', '/', dirname($plugin_file)),
            ];
        }

        // Themes Information
        $all_themes = wp_get_themes();
        foreach ($all_themes as $theme) {
            $components['themes'][] = [
                'id'      => esc_html($theme->get_stylesheet()),
                'name'    => esc_html($theme->get('Name')),
                'version' => esc_html($theme->get('Version')),
                'status'  => $theme->is_active() ? 'active' : 'inactive',
                'path'    => str_replace('\\', '/', $theme->get_stylesheet_directory()),
            ];
        }

        return $components;
    }

    /**
     * Get the version of WordPress core.
     *
     * @return string The version of WordPress core.
     */
    private function get_core_version() {
        global $wp_version;
        return esc_html($wp_version);
    }
}