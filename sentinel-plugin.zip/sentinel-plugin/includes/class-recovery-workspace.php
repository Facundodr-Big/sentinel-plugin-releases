<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Recovery_Workspace {

    /**
     * The single instance of the class.
     *
     * @var Sentinel_Recovery_Workspace|null
     */
    private static $instance = null;

    /**
     * Directory path for the recovery workspace.
     *
     * @var string
     */
    const WORKSPACE_DIR = WP_CONTENT_DIR . '/controlcenter/restore_workspace';

    /**
     * Main instance of Sentinel_Recovery_Workspace.
     *
     * Ensures only one instance is loaded or can be loaded.
     *
     * @return Sentinel_Recovery_Workspace - Main instance.
     */
    public static function get_instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Prepare the recovery workspace directory.
     *
     * Checks if the workspace directory exists, cleans it if it does,
     * and creates it with proper permissions if it doesn't.
     *
     * @return string|bool - The path to the cleaned workspace or false on error.
     */
    public function prepare_workspace() {
        $workspace_dir = self::WORKSPACE_DIR;

        // Clean existing workspace directory
        if (file_exists($workspace_dir)) {
            if (!$this->clean_workspace()) {
                return false;
            }
        }

        // Create the workspace directory with proper permissions
        if (!wp_mkdir_p($workspace_dir)) {
            return false;
        }

        // Create an empty index.html file to prevent directory listing
        $index_file_path = trailingslashit($workspace_dir) . 'index.html';
        if (!file_put_contents($index_file_path, '')) {
            return false;
        }

        return $workspace_dir;
    }

    /**
     * Clean the recovery workspace directory.
     *
     * Recursively deletes all files and subdirectories within the workspace.
     *
     * @return bool - True on success, false on failure.
     */
    public function clean_workspace() {
        $workspace_dir = self::WORKSPACE_DIR;

        if (!file_exists($workspace_dir)) {
            return true; // Nothing to clean
        }

        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($workspace_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($files as $fileinfo) {
            if ($fileinfo->isDir()) {
                rmdir($fileinfo->getRealPath());
            } else {
                unlink($fileinfo->getRealPath());
            }
        }

        return true;
    }
}