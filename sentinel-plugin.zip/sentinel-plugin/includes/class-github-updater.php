<?php

if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_GitHub_Updater {

    private static $instance = null;

    public static function get_instance() {
        if ( self::$instance == null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        if ( isset( $_GET['_nocache'] ) ) {
            delete_site_transient( 'update_plugins' );
            delete_transient( 'sentinel_github_update_info' );
        }
        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_update' ), 10, 1 );
        add_filter( 'plugins_api', array( $this, 'plugins_api_info' ), 20, 3 );
    }

    public function check_update($transient) {
        if (!is_object($transient) || !isset($transient->response)) {
            return $transient;
        }

        $cache_key = 'sentinel_github_update_info';
        $nocache = isset($_GET['_nocache']);

        if ($nocache) {
            delete_transient($cache_key);
        }

        if ($nocache || !get_transient($cache_key)) {
            $url = 'https://raw.githubusercontent.com/Facundodr-Big/sentinel-plugin-releases/main/version.json?t=' . time();
            $response = wp_remote_get( $url, array('timeout' => 10, 'sslverify' => false) );

            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
                return $transient;
            }

            $body = wp_remote_retrieve_body($response);
            $update_info = json_decode($body);

            if (!is_object($update_info)) {
                return $transient;
            }

            set_transient($cache_key, $update_info, 12 * HOUR_IN_SECONDS);
        } else {
            $update_info = get_transient($cache_key);
        }

        if (isset($update_info->version) && version_compare($update_info->version, SENTINEL_VERSION, '>')) {
            $remote_version = $update_info->version;
            $remote_url = 'https://github.com/Facundodr-Big/sentinel-plugin-releases';
            $remote_package = 'https://raw.githubusercontent.com/Facundodr-Big/sentinel-plugin-releases/main/sentinel-plugin.zip?t=' . time();

            $transient->response['sentinel-plugin/sentinel.php'] = (object) array(
                'slug' => 'sentinel-plugin',
                'plugin' => 'sentinel-plugin/sentinel.php',
                'new_version' => $remote_version,
                'url' => $remote_url,
                'package' => $remote_package
            );
        } else {
            unset($transient->response['sentinel-plugin/sentinel.php']);
        }

        return $transient;
    }

    public function plugins_api_info($res, $action, $args) {
        if ($action !== 'plugin_information' || !is_object($args) || !isset($args->slug) || $args->slug !== 'sentinel-plugin') {
            return $res;
        }

        $cache_key = 'sentinel_github_update_info';
        $update_info = get_transient($cache_key);

        if (!$update_info) {
            $url = 'https://raw.githubusercontent.com/Facundodr-Big/sentinel-plugin-releases/main/version.json?t=' . time();
            $response = wp_remote_get( $url, array('timeout' => 10, 'sslverify' => false) );

            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
                return $res;
            }

            $body = wp_remote_retrieve_body($response);
            $update_info = json_decode($body);

            if (!is_object($update_info)) {
                return $res;
            }

            set_transient($cache_key, $update_info, 12 * HOUR_IN_SECONDS);
        }

        if (isset($update_info->version)) {
            $res = new stdClass();
            $res->name = 'Sentinel';
            $res->slug = 'sentinel-plugin';
            $res->version = $update_info->version;
            $res->author = 'Sentinel';
            $res->homepage = 'https://github.com/Facundodr-Big/sentinel-plugin-releases';
            $res->download_link = 'https://raw.githubusercontent.com/Facundodr-Big/sentinel-plugin-releases/main/sentinel-plugin.zip?t=' . time();
            $res->sections = array('description' => 'Agente pasivo inteligente para persistencia local y mantenimiento.');
            $res->banners = array('low' => '', 'high' => '');
        }

        return $res;
    }
}

Sentinel_GitHub_Updater::get_instance();