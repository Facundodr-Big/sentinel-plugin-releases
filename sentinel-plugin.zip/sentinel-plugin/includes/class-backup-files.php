<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Backup_Files {

    private $backup_dir;
    private $last_backup_time_key = 'sentinel_last_backup_time';
    private $incremental_counter_key = 'sentinel_incremental_count';

    public function __construct() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $this->backup_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $this->backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }

        // Asegurar que la carpeta existe y está protegida
        $this->ensure_directory_secured();
    }

    /**
     * Crea el directorio de copias de seguridad y le inyecta un .htaccess protector
     */
    private function ensure_directory_secured() {
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        // Proteger contra acceso web directo por Apache/Nginx
        $htaccess = $this->backup_dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "deny from all\nOptions -Indexes");
        }

        // Fichero index.html para evitar listado de directorios
        $index_html = $this->backup_dir . 'index.html';
        if (!file_exists($index_html)) {
            file_put_contents($index_html, '');
        }
    }

    /**
     * Retorna si un archivo debe ser incluido según el tipo de backup y la fecha de última copia
     */
    private function should_include_file($file_path, $backup_type, $last_backup_time, $excluded_files = array()) {
        $normalized_backup_dir = str_replace('\\', '/', $this->backup_dir);
        $normalized_path = str_replace('\\', '/', $file_path);

        // Evitar incluir la propia carpeta de backups
        if (false !== stripos($normalized_path, $normalized_backup_dir)) {
            return false;
        }

        // Seguridad ante Symlinks: Validar que el archivo real esté contenido en la web
        $real_path = realpath($file_path);
        if ($real_path === false) {
            return false;
        }
        $real_path = str_replace('\\', '/', $real_path);
        
        $real_abspath = realpath(ABSPATH);
        $real_content_dir = defined('WP_CONTENT_DIR') ? realpath(WP_CONTENT_DIR) : false;
        
        $real_abspath_norm = $real_abspath ? trailingslashit(str_replace('\\', '/', $real_abspath)) : '';
        $real_content_norm = $real_content_dir ? trailingslashit(str_replace('\\', '/', $real_content_dir)) : '';

        // Usamos stripos para case-insensitive (evita fallos en Windows por C:/ vs c:/)
        $in_abspath = (!empty($real_abspath_norm) && stripos($real_path, $real_abspath_norm) === 0);
        $in_content = (!empty($real_content_norm) && stripos($real_path, $real_content_norm) === 0);

        if (!$in_abspath && !$in_content) {
            return false;
        }

        // Evitar incluir archivos y directorios excluidos
        $relative_path = str_replace(ABSPATH, '', $file_path);
        $relative_path = '/' . ltrim(str_replace('\\', '/', $relative_path), '/');
        if (!empty($excluded_files) && is_array($excluded_files)) {
            foreach ($excluded_files as $excluded) {
                if (!is_string($excluded)) {
                    continue;
                }
                $normalized_excluded = '/' . ltrim(str_replace('\\', '/', $excluded), '/');
                
                // Comparación exacta
                if ($relative_path === $normalized_excluded) {
                    return false;
                }
                
                // Comparación de subdirectorio (exclusión recursiva de carpetas)
                $dir_excluded = rtrim($normalized_excluded, '/') . '/';
                if (strpos($relative_path, $dir_excluded) === 0) {
                    return false;
                }
            }
        }

        // Si es Full Backup, incluir todos
        if ($backup_type === 'full') {
            return true;
        }

        // Si es incremental, comparar mtime
        $mtime = filemtime($file_path);
        if ($mtime === false) {
            return false;
        }

        // Incluir solo si el archivo fue modificado después de la última copia de seguridad
        return ($mtime > $last_backup_time);
    }

    private function scan_dir_recursive($dir, $backup_type, $last_backup_time, $excluded_paths, $excluded_dirs, &$files) {
        $items = @scandir($dir);
        if ($items === false) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            // Exclusión rígida rápida por nombre de carpeta
            $item_lower = strtolower($item);
            if ($item_lower === 'node_modules' || $item_lower === '.git' || $item_lower === '.venv' || $item_lower === '__pycache__') {
                continue;
            }

            $path = str_replace('\\\\', '/', $dir . '/' . $item);
            
            // Verificar si este path específico o directorio está excluido
            $relative_path = str_replace(ABSPATH, '', $path);
            $relative_path = '/' . ltrim($relative_path, '/');

            // Exclusiones rígidas de directorios por ruta relativa
            if (strpos($relative_path, '/wp-content/cache') === 0 || strpos($relative_path, '/wp-content/uploads/sentinel-backups') === 0) {
                continue;
            }

            if (is_dir($path)) {
                if (isset($excluded_dirs[$relative_path])) {
                    continue;
                }
                $this->scan_dir_recursive($path, $backup_type, $last_backup_time, $excluded_paths, $excluded_dirs, $files);
            } else {
                if (isset($excluded_paths[$relative_path])) {
                    continue;
                }
                if ($backup_type === 'full') {
                    $files[] = $path;
                } else {
                    $mtime = @filemtime($path);
                    if ($mtime !== false && $mtime > $last_backup_time) {
                        $files[] = $path;
                    }
                }
            }
        }
    }

    private function generate_file_list($dir, $backup_type, $last_backup_time, $excluded_files = array()) {
        $files = array();
        if (!is_dir($dir)) {
            return $files;
        }

        // Indexar exclusiones dinámicas en arreglos asociativos para búsquedas O(1)
        $excluded_paths = array();
        $excluded_dirs = array();
        if (!empty($excluded_files) && is_array($excluded_files)) {
            foreach ($excluded_files as $excluded) {
                if (!is_string($excluded)) {
                    continue;
                }
                $normalized = '/' . ltrim(str_replace('\\\\', '/', $excluded), '/');
                $normalized_dir = rtrim($normalized, '/');
                $excluded_dirs[$normalized_dir] = true;
                $excluded_paths[$normalized] = true;
            }
        }

        try {
            $dir = str_replace('\\\\', '/', rtrim($dir, '/'));
            $this->scan_dir_recursive($dir, $backup_type, $last_backup_time, $excluded_paths, $excluded_dirs, $files);
        } catch (Exception $e) {
            error_log('Sentinel: Fallo al iterar directorios de forma eficiente: ' . $e->getMessage());
        }

        return $files;
    }

    /**
     * Ejecuta el backup incremental/por lotes con rotación 4 a 1
     */
    public function run_backup($offset = 0, $limit = 500, $requested_type = 'auto', $excluded_files = array()) {
        @set_time_limit(0);
        $db_excluded = get_option('sentinel_excluded_files', array());
        if (!is_array($db_excluded)) {
            $db_excluded = array();
        }
        $excluded_files = array_unique(array_merge($excluded_files, $db_excluded));

        $last_full_backup_time = intval(get_option('sentinel_last_full_backup_time', 0));
        $last_backup_time = intval(get_option($this->last_backup_time_key, 0));
        $incremental_count = intval(get_option($this->incremental_counter_key, 0));
        
        // Decidir tipo de backup (Completo o Incremental)
        $backup_type = $requested_type;
        if ($requested_type === 'auto') {
            // true weekly incremental files backup
            if ($last_full_backup_time === 0 || (time() - $last_full_backup_time) >= 7 * 24 * 3600) {
                $backup_type = 'full';
            } else {
                $backup_type = 'incremental';
            }
        }

        $target_dir = ABSPATH;
        $index_file = $this->backup_dir . 'index_files.json';

        if ($offset === 0) {
            // Escanear disco aplicando los filtros correspondientes
            $file_list = $this->generate_file_list($target_dir, $backup_type, $last_backup_time, $excluded_files);
            file_put_contents($index_file, json_encode($file_list));
        } else {
            // Leer el índice en lugar de re-escanear
            if (file_exists($index_file)) {
                $file_list = json_decode(file_get_contents($index_file), true);
                if (!is_array($file_list)) {
                    $file_list = array();
                }
            } else {
                $file_list = array();
            }
        }

        $total_files = count($file_list);

        // Si es incremental y no hay archivos modificados desde el principio
        if ($offset === 0 && $total_files === 0 && $backup_type === 'incremental') {
            if (file_exists($index_file)) {
                unlink($index_file);
            }
            return array(
                'success' => true,
                'completed' => true,
                'message' => 'No hay cambios detectados desde el último backup.',
                'total_files' => 0,
                'backup_type' => 'incremental',
                'backup_path' => ''
            );
        }

        // Segmentar por el offset y limite
        $chunk = array_slice($file_list, $offset, $limit);
        $processed_count = count($chunk);

        if ($processed_count === 0) {
            if (file_exists($index_file)) {
                unlink($index_file);
            }
            return array(
                'success' => true,
                'completed' => true,
                'message' => 'Proceso finalizado sin más archivos.',
                'total_files' => $total_files,
                'offset' => $offset,
                'backup_type' => $backup_type
            );
        }

        // Nombre del backup temporal
        $backup_filename = 'backup_files_temp.zip';
        $backup_path = $this->backup_dir . $backup_filename;

        // Comprimir el lote actual
        $zip = new ZipArchive();
        $mode = ($offset === 0) ? (ZipArchive::CREATE | ZipArchive::OVERWRITE) : ZipArchive::CREATE;

        if ($zip->open($backup_path, $mode) === true) {
            foreach ($chunk as $file_path) {
                $relative_path = str_replace(ABSPATH, '', $file_path);
                if (file_exists($file_path) && is_readable($file_path)) {
                    $zip->addFile($file_path, $relative_path);
                }
            }
            $zip->close();
            $success = true;
        } else {
            $success = $this->build_tar_fallback($backup_path, $chunk, $offset);
        }

        $next_offset = $offset + $processed_count;
        $completed = ($next_offset >= $total_files);

        // Al finalizar exitosamente todo el proceso
        if ($completed) {
            if (file_exists($index_file)) {
                unlink($index_file);
            }
            if ($success) {
                $timestamp_str = date('Ymd_His');
                $final_name = 'backup_files_' . $backup_type . '_' . $timestamp_str . '.zip';
                rename($backup_path, $this->backup_dir . $final_name);
                $backup_path = $this->backup_dir . $final_name;

                // Actualizar marcas temporales y contador de rotación en WordPress
                update_option($this->last_backup_time_key, time());
                if ($backup_type === 'full') {
                    update_option($this->incremental_counter_key, 0);
                    update_option('sentinel_last_full_backup_time', time());
                } else {
                    update_option($this->incremental_counter_key, $incremental_count + 1);
                }
            }
        }

        return array(
            'success'     => $success,
            'completed'   => $completed,
            'offset'      => $next_offset,
            'total_files' => $total_files,
            'processed'   => $processed_count,
            'backup_type' => $backup_type,
            'backup_path' => $success ? $backup_path : ''
        );
    }

    /**
     * Fallback para compresión en TAR en servidores PHP limitados
     */
    private function build_tar_fallback($backup_path, $files, $offset) {
        error_log('Sentinel: ZipArchive fallido, fallback TAR activándose.');
        return false;
    }
}
