<?php
if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Updater {

    private $backup_dir;

    public function __construct() {
        if (!function_exists('request_filesystem_credentials')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if (!class_exists('Plugin_Upgrader')) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        }
        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $uploads = wp_upload_dir();
        $this->backup_dir = $uploads['basedir'] . '/sentinel-backups/';
    }

    /**
     * Volcado rápido de base de datos para rollback
     */
    private function quick_db_dump($suffix, $version = '') {
        global $wpdb;
        $filename_part = sanitize_title($suffix);
        if (!empty($version)) {
            $filename_part .= '_' . sanitize_title($version);
        }
        $backup_file = $this->backup_dir . 'rollback_db_' . $filename_part . '.sql';
        
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }
        
        $handle = @fopen($backup_file, 'w');
        if (!$handle) {
            return false;
        }
        
        fwrite($handle, "-- Sentinel Quick DB Dump\n");
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=0;\n\n");
        
        $tables = $wpdb->get_col("SHOW TABLES");
        foreach ($tables as $table) {
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table`", ARRAY_N);
            if (!empty($create_table)) {
                fwrite($handle, "DROP TABLE IF EXISTS `$table`;\n" . $create_table[1] . ";\n\n");
            }
            
            $rows = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $keys = array_map('esc_sql', array_keys($row));
                    $values = array_map(function($val) {
                        if (is_null($val)) return 'NULL';
                        return "'" . esc_sql($val) . "'";
                    }, array_values($row));
                    fwrite($handle, "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $values) . ");\n");
                }
                fwrite($handle, "\n");
            }
        }
        
        fwrite($handle, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($handle);
        return $backup_file;
    }

    /**
     * Respalda un tema específico antes de actualizarlo
     */
    private function backup_theme_folder($theme_slug) {
        $theme_dir = get_theme_root() . '/' . $theme_slug;
        
        if (!is_dir($theme_dir)) {
            return false;
        }

        $backup_zip = $this->backup_dir . 'rollback_theme_' . $theme_slug . '.zip';

        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        $zip = new ZipArchive();
        if ($zip->open($backup_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($theme_dir),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                if (!$file->isDir()) {
                    $file_path = $file->getRealPath();
                    $relative_path = substr($file_path, strlen(get_theme_root()) + 1);
                    $zip->addFile($file_path, $relative_path);
                }
            }
            $zip->close();
            return $backup_zip;
        }

        return false;
    }

    /**
     * Respalda un plugin específico antes de actualizarlo
     */
    private function backup_plugin_folder($plugin_file, $version) {
        $plugin_dir = WP_PLUGIN_DIR . '/' . dirname($plugin_file);
        
        if (!is_dir($plugin_dir)) {
            return false;
        }

        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        $backup_zip = $this->backup_dir . 'rollback_' . sanitize_title(dirname($plugin_file)) . '_' . sanitize_title($version) . '.zip';

        // Comprimir el plugin actual
        $zip = new ZipArchive();
        if ($zip->open($backup_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($plugin_dir),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                if (!$file->isDir()) {
                    $file_path = $file->getRealPath();
                    $relative_path = substr($file_path, strlen(WP_PLUGIN_DIR) + 1);
                    $zip->addFile($file_path, $relative_path);
                }
            }
            $zip->close();
            return $backup_zip;
        }

        return false;
    }

    /**
     * Ejecuta el ciclo de actualización aislada de un plugin específico
     */
    public function update_plugin($plugin_file) {
        // Cargar librerías de WordPress Upgrader
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        include_once ABSPATH . 'wp-admin/includes/file.php';
        include_once ABSPATH . 'wp-admin/includes/plugin.php';

        // Check if there is an update package available and get expected version
        $update_plugins = get_site_transient('update_plugins');
        $has_package = false;
        $expected_version = '';
        if (isset($update_plugins->response[$plugin_file])) {
            $update_info = $update_plugins->response[$plugin_file];
            $expected_version = isset($update_info->new_version) ? $update_info->new_version : '';
            if (!empty($update_info->package)) {
                $has_package = true;
            }
        }

        $premium_keywords = array('cmsmasters', 'elementor-pro', 'wp-rocket', 'revslider', 'js_composer', 'gravityforms');
        $is_known_premium = false;
        foreach ($premium_keywords as $kw) {
            if (false !== strpos(strtolower($plugin_file), $kw)) {
                $is_known_premium = true;
                break;
            }
        }

        // Return needs_manual => true for premium/unlicensed plugins before updating
        if ((isset($update_plugins->response[$plugin_file]) && !$has_package) || $is_known_premium) {
            return array(
                'success' => false,
                'needs_manual' => true,
                'message' => 'El plugin requiere actualización manual (premium o sin licencia activa).'
            );
        }

        // Obtener versión antes de actualizar
        $plugin_abs_path = WP_PLUGIN_DIR . '/' . $plugin_file;
        $version_before = '0.0.0';
        if (file_exists($plugin_abs_path)) {
            $plugin_data = get_plugin_data($plugin_abs_path);
            $version_before = isset($plugin_data['Version']) ? $plugin_data['Version'] : '0.0.0';
        }

        // 1. Respaldar antes de actualizar (Rollback Seguro)
        $backup_path = $this->backup_plugin_folder($plugin_file, $version_before);
        if (!$backup_path) {
            return array('success' => false, 'message' => 'No se pudo realizar el backup de seguridad previo al update.');
        }

        // Si el plugin es crítico o requiere backup de BD, hacer volcado rápido de base de datos
        $plugin_slug = dirname($plugin_file);
        $critical_plugins = array('woocommerce', 'elementor', 'wp-rocket', 'gravityforms', 'wpforms', 'contact-form-7');
        $is_critical = false;
        foreach ($critical_plugins as $keyword) {
            if (strpos(strtolower($plugin_slug), $keyword) !== false) {
                $is_critical = true;
                break;
            }
        }
        
        $db_backup_path = false;
        if ($is_critical) {
            $db_backup_path = $this->quick_db_dump($plugin_slug, $version_before);
        }

        // Comprobar privilegios y credenciales de sistema de archivos
        $url = 'plugins.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }

        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        // Crear una skin silenciosa para no emitir output visual
        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);

        // Desactivar el plugin temporalmente antes de actualizar
        deactivate_plugins($plugin_file);

        // Actualizar
        $result = $upgrader->upgrade($plugin_file);

        // Obtener versión después de actualizar
        $version_after = '0.0.0';
        if (file_exists($plugin_abs_path)) {
            $plugin_data = get_plugin_data($plugin_abs_path);
            $version_after = isset($plugin_data['Version']) ? $plugin_data['Version'] : '0.0.0';
        }

        // Identificar si falló el paquete o no cambió la versión (típico de premium de pago)
        $is_wp_error = is_wp_error($result);
        $error_code = $is_wp_error ? $result->get_error_code() : '';
        $error_msg = $is_wp_error ? $result->get_error_message() : '';

        // Pre/post version checks & failure detection
        $failed_upgrade = $is_wp_error || !$result || ($version_before === $version_after) || (!empty($expected_version) && $version_after !== $expected_version);

        if ($failed_upgrade) {
            // Intentar restaurar de inmediato si la actualización falló o hubo mismatch
            $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '_' . $version_before . '.zip');
            // Si hay rollback de BD, restaurarlo también
            if ($db_backup_path) {
                $this->restore_backup('rollback_db_' . sanitize_title($plugin_slug) . '_' . $version_before . '.sql');
            }
            // Reactivar el plugin anterior tras restaurarlo
            activate_plugin($plugin_file);

            $is_license_issue = ($error_code === 'no_package' || 
                                 strpos(strtolower($error_msg), 'no disponible') !== false || 
                                 strpos(strtolower($error_msg), 'package not available') !== false ||
                                 $version_before === $version_after);

            if ($is_license_issue || $is_known_premium || !$has_package) {
                return array(
                    'success' => false,
                    'needs_manual' => true,
                    'message' => 'El plugin requiere actualización manual (posiblemente de pago o sin licencia activa).'
                );
            }

            return array(
                'success' => false,
                'message' => $is_wp_error ? $error_msg : 'La actualización ha fallado o la versión no ha cambiado/mismatch. Rollback disparado automáticamente.'
            );
        }

        // Reactivar plugin
        $activation_result = activate_plugin($plugin_file);
        
        // Comprobar si el plugin se activó correctamente
        if (is_wp_error($activation_result) || !is_plugin_active($plugin_file)) {
            // El plugin falló al reactivarse (posible error fatal o incompatibilidad de código)
            $activation_err = is_wp_error($activation_result) ? $activation_result->get_error_message() : 'El plugin no quedó activo tras la actualización.';
            
            // Disparar Rollback de emergencia
            $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '_' . $version_before . '.zip');
            if ($db_backup_path) {
                $this->restore_backup('rollback_db_' . sanitize_title($plugin_slug) . '_' . $version_before . '.sql');
            }
            activate_plugin($plugin_file);
            
            return array(
                'success' => false,
                'message' => 'Fallo de activación tras actualización: ' . $activation_err . ' Rollback automático ejecutado exitosamente.'
            );
        }

        // Test de salud rápido tras la actualización mediante loopback interno
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 10,
            'sslverify' => false,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        if (!is_wp_error($test_response)) {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                // El sitio arrojó pantalla blanca o error fatal con el nuevo plugin activo
                $this->restore_backup('rollback_' . sanitize_title(dirname($plugin_file)) . '_' . $version_before . '.zip');
                if ($db_backup_path) {
                    $this->restore_backup('rollback_db_' . sanitize_title($plugin_slug) . '_' . $version_before . '.sql');
                }
                activate_plugin($plugin_file);
                return array(
                    'success' => false,
                    'message' => 'El plugin provocó un error fatal en el sitio (HTTP ' . $test_code . '). Rollback automático ejecutado exitosamente.'
                );
            }
        }

        // Auto-Pruning
        $this->prune_backups();

        return array(
            'success' => true,
            'message' => 'Plugin actualizado, verificado y reactivado con éxito.',
            'backup_rollback' => basename($backup_path)
        );
    }

    /**
     * Realiza la sobreescritura y el deploy de rescate ante desastres
     */
    public function restore_backup($backup_name) {
        $backup_path = $this->backup_dir . sanitize_file_name($backup_name);

        if (!file_exists($backup_path)) {
            return array('success' => false, 'message' => 'Fichero de respaldo no encontrado.');
        }

        // Determinar tipo de respaldo
        $extension = pathinfo($backup_path, PATHINFO_EXTENSION);

        if ($extension === 'zip') {
            // Restaurar plugin o archivos usando la API nativa de WordPress
            require_once ABSPATH . 'wp-admin/includes/file.php';
            global $wp_filesystem;
            
            if (empty($wp_filesystem)) {
                if (!WP_Filesystem()) {
                    return array('success' => false, 'message' => 'No se pudo inicializar WP_Filesystem para la restauración.');
                }
            }

            // Si el backup es de un tema, extraer en el directorio de temas
            $extract_to = WP_PLUGIN_DIR;
            if (strpos(basename($backup_name), 'rollback_theme_') === 0) {
                $extract_to = get_theme_root();
            }

            $unzip_result = unzip_file($backup_path, $extract_to);
            if (is_wp_error($unzip_result)) {
                return array('success' => false, 'message' => 'Fallo al descomprimir el backup: ' . $unzip_result->get_error_message());
            }

            // Normalización recursiva de permisos para asegurar la mutabilidad de los archivos
            if ($wp_filesystem->exists($extract_to)) {
                $wp_filesystem->chmod($extract_to, 0755, true);
            }

            return array('success' => true, 'message' => 'Archivos restaurados con éxito.');
        } elseif ($extension === 'sql') {
            // Restaurar base de datos
            global $wpdb;
            $sql = file_get_contents($backup_path);
            
            // Separar consultas SQL de forma rústica y segura para ejecutar una por una
            $queries = preg_split("/;[ \t]*\n/", $sql);
            
            foreach ($queries as $query) {
                $query = trim($query);
                if (!empty($query)) {
                    $wpdb->query($query);
                }
            }
            return array('success' => true, 'message' => 'Base de datos importada correctamente.');
        }

        return array('success' => false, 'message' => 'Formato de restauración no compatible.');
    }

    /**
     * Ejecuta el ciclo de actualización de un tema
     */
    public function update_theme($theme_slug) {
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/file.php';
        include_once ABSPATH . 'wp-admin/includes/theme.php';

        // 1. Respaldar antes de actualizar
        $backup_path = $this->backup_theme_folder($theme_slug);
        if (!$backup_path) {
            return array('success' => false, 'message' => 'No se pudo realizar el backup de seguridad del tema previo al update.');
        }

        // Comprobar privilegios y credenciales de sistema de archivos
        $url = 'themes.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }

        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        // Crear una skin silenciosa para no emitir output visual
        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Theme_Upgrader($skin);

        // Actualizar
        $result = $upgrader->upgrade($theme_slug);

        $is_wp_error = is_wp_error($result);
        $failed_upgrade = $is_wp_error || !$result;

        if ($failed_upgrade) {
            $this->restore_backup('rollback_theme_' . $theme_slug . '.zip');
            return array(
                'success' => false,
                'message' => $is_wp_error ? $result->get_error_message() : 'La actualización del tema ha fallado. Rollback disparado automáticamente.'
            );
        }

        // Test de salud rápido tras la actualización mediante loopback interno
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 10,
            'sslverify' => false,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        if (!is_wp_error($test_response)) {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                $this->restore_backup('rollback_theme_' . $theme_slug . '.zip');
                return array(
                    'success' => false,
                    'message' => 'El tema provocó un error fatal en el sitio (HTTP ' . $test_code . '). Rollback automático ejecutado exitosamente.'
                );
            }
        }

        // Auto-Pruning
        $this->prune_backups();

        return array(
            'success' => true,
            'message' => 'Tema actualizado, verificado y activado con éxito.',
            'backup_rollback' => basename($backup_path)
        );
    }

    /**
     * Ejecuta la actualización segura del core de WordPress
     */
    public function update_core() {
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/file.php';
        
        // 1. Respaldar la base de datos antes de actualizar
        global $wp_version;
        $backup_path = $this->quick_db_dump('core', $wp_version);
        if (!$backup_path) {
            return array('success' => false, 'message' => 'No se pudo realizar el backup de base de datos previo al update del Core.');
        }

        // Comprobar privilegios y credenciales de sistema de archivos
        $url = 'update-core.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }

        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Core_Upgrader($skin);

        // Obtener la actualización recomendada
        $updates = get_core_updates();
        if (empty($updates)) {
            return array('success' => false, 'message' => 'No hay actualizaciones disponibles de WordPress Core.');
        }

        // Correr la actualización del Core de WordPress
        $result = $upgrader->upgrade($updates[0]);

        if (is_wp_error($result)) {
            return array(
                'success' => false,
                'message' => 'La actualización de WordPress Core falló: ' . $result->get_error_message()
            );
        }

        // Test de salud rápido tras la actualización mediante loopback interno
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 15,
            'sslverify' => false,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        if (!is_wp_error($test_response)) {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                // Revertir base de datos
                $this->restore_backup(basename($backup_path));
                return array(
                    'success' => false,
                    'message' => 'La actualización del Core provocó un error fatal en el sitio (HTTP ' . $test_code . '). Rollback de base de datos ejecutado.'
                );
            }
        }

        // Auto-Pruning
        $this->prune_backups();

        return array(
            'success' => true,
            'message' => 'WordPress Core actualizado con éxito. Backup de base de datos guardado.',
            'backup_rollback' => basename($backup_path)
        );
    }

    /**
     * Limpieza automática de backups antiguos
     */
    public function prune_backups() {
        if (!is_dir($this->backup_dir)) {
            return;
        }

        $files = glob($this->backup_dir . '*');
        if (empty($files)) {
            return;
        }

        $now = time();
        $seven_days = 7 * 24 * 60 * 60;
        $total_size = 0;
        $file_list = array();

        foreach ($files as $file) {
            if (is_file($file) && !in_array(basename($file), array('.htaccess', 'index.html'))) {
                $mtime = filemtime($file);
                
                // 1. Eliminar archivos con más de 7 días
                if (($now - $mtime) > $seven_days) {
                    @unlink($file);
                } else {
                    $size = filesize($file);
                    $total_size += $size;
                    $file_list[] = array(
                        'path'  => $file,
                        'mtime' => $mtime,
                        'size'  => $size
                    );
                }
            }
        }

        // 2. Si supera 500MB, eliminar más antiguos (FIFO)
        $max_size = 500 * 1024 * 1024;
        if ($total_size > $max_size) {
            usort($file_list, function($a, $b) {
                return $a['mtime'] - $b['mtime'];
            });

            foreach ($file_list as $f) {
                if ($total_size <= $max_size) {
                    break;
                }
                if (@unlink($f['path'])) {
                    $total_size -= $f['size'];
                }
            }
        }
    }

    /**
     * Motor de Auto-Actualización seguro del propio Sentinel.
     * Descarga el ZIP, hace swap atómico, valida con un loopback HTTP request y hace rollback si falla.
     */
    public function self_update_plugin($zip_url) {
        // Inicializar sistema de archivos de WP si no se ha hecho
        $url = 'plugins.php';
        if (false === ($credentials = request_filesystem_credentials($url, '', false, false, null))) {
            return array('success' => false, 'message' => 'No se cuentan con credenciales de escritura de ficheros.');
        }
        if (!WP_Filesystem($credentials)) {
            return array('success' => false, 'message' => 'Fallo al inicializar WP_Filesystem.');
        }

        global $wp_filesystem;

        // Definir rutas
        $plugin_slug = 'sentinel-plugin';
        $plugin_dir = WP_PLUGIN_DIR . '/' . $plugin_slug;
        $plugin_old_dir = WP_PLUGIN_DIR . '/' . $plugin_slug . '_old';
        
        $temp_zip = $this->backup_dir . 'sentinel-update-temp.zip';
        $temp_extract_dir = $this->backup_dir . 'sentinel-update-extract';

        // 1. Descargar paquete ZIP
        $response = wp_remote_get($zip_url, array(
            'timeout' => 45,
            'sslverify' => false,
            'user-agent' => 'Sentinel/1.2.0 Control Center Client'
        ));

        if (is_wp_error($response)) {
            return array('success' => false, 'message' => 'Error al descargar el ZIP de actualización: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return array('success' => false, 'message' => 'El servidor del Panel Central retornó HTTP ' . $code);
        }

        $zip_body = wp_remote_retrieve_body($response);
        if (empty($zip_body)) {
            return array('success' => false, 'message' => 'Cuerpo del archivo ZIP vacío.');
        }

        // Asegurar que el directorio de backups existe
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
        }

        // Guardar ZIP temporal usando WP_Filesystem
        if (!$wp_filesystem->put_contents($temp_zip, $zip_body, FS_CHMOD_FILE)) {
            $fallback_dir = function_exists('get_temp_dir') ? get_temp_dir() : WP_CONTENT_DIR . '/';
            $temp_zip = $fallback_dir . 'sentinel-update-temp.zip';
            $temp_extract_dir = $fallback_dir . 'sentinel-update-extract';
            if (!$wp_filesystem->put_contents($temp_zip, $zip_body, FS_CHMOD_FILE)) {
                $temp_zip = WP_CONTENT_DIR . '/sentinel-update-temp.zip';
                $temp_extract_dir = WP_CONTENT_DIR . '/sentinel-update-extract';
                if (!$wp_filesystem->put_contents($temp_zip, $zip_body, FS_CHMOD_FILE)) {
                    return array('success' => false, 'message' => 'No se pudo escribir el archivo ZIP temporal en disco (Error de permisos).');
                }
            }
        }

        // 2. Extraer ZIP en carpeta temporal
        if ($wp_filesystem->exists($temp_extract_dir)) {
            $wp_filesystem->delete($temp_extract_dir, true);
        }

        // Descomprimir usando la API nativa de WordPress
        $unzip_result = unzip_file($temp_zip, $temp_extract_dir);
        $wp_filesystem->delete($temp_zip); // Eliminar el ZIP temporal

        if (is_wp_error($unzip_result)) {
            return array('success' => false, 'message' => 'Fallo al descomprimir la actualización: ' . $unzip_result->get_error_message());
        }

        // Buscar la carpeta del plugin dentro del ZIP extraído (podría estar anidada o ser directa)
        $extracted_items = $wp_filesystem->dirlist($temp_extract_dir);
        $extracted_slug = '';
        if (is_array($extracted_items)) {
            foreach ($extracted_items as $name => $item) {
                if (isset($item['type']) && $item['type'] === 'd') {
                    $extracted_slug = $name;
                    break;
                }
            }
        }

        // Si no hay subcarpeta, la raíz extraída es la fuente; de lo contrario, la subcarpeta
        if (empty($extracted_slug)) {
            $new_plugin_source = $temp_extract_dir;
        } else {
            $new_plugin_source = $temp_extract_dir . '/' . $extracted_slug;
        }

        // 3. Intercambio Atómico de Directorios
        if ($wp_filesystem->exists($plugin_old_dir)) {
            $wp_filesystem->delete($plugin_old_dir, true);
        }

        // Mover el actual a sentinel-plugin_old
        if ($wp_filesystem->exists($plugin_dir)) {
            if (!$wp_filesystem->move($plugin_dir, $plugin_old_dir, true)) {
                $wp_filesystem->delete($temp_extract_dir, true);
                return array('success' => false, 'message' => 'Fallo al renombrar la versión activa a la carpeta temporal _old.');
            }
        }

        // Mover el nuevo a sentinel-plugin
        if (!$wp_filesystem->move($new_plugin_source, $plugin_dir, true)) {
            // Restaurar de emergencia
            if ($wp_filesystem->exists($plugin_old_dir)) {
                $wp_filesystem->move($plugin_old_dir, $plugin_dir, true);
            }
            $wp_filesystem->delete($temp_extract_dir, true);
            return array('success' => false, 'message' => 'Fallo al instalar la nueva versión en la ruta activa.');
        }

        // Normalización de permisos en el nuevo directorio del plugin
        $wp_filesystem->chmod($plugin_dir, 0755, true);

        // Limpiar directorio temporal de extracción
        $wp_filesystem->delete($temp_extract_dir, true);

        // Limpiar caché de plugins de WordPress
        if (function_exists('wp_clean_plugins_cache')) {
            wp_clean_plugins_cache(true);
        }

        // 4. Petición HTTP Loopback interna al sitio para verificar que no haya Pantalla Blanca (WSOD)
        $test_url = site_url();
        $test_response = wp_remote_get($test_url, array(
            'timeout' => 15,
            'sslverify' => false,
            'redirection' => 5,
            'headers' => array('Cache-Control' => 'no-cache')
        ));

        $rollback_needed = false;
        $reason = '';

        if (is_wp_error($test_response)) {
            $rollback_needed = true;
            $reason = 'Loopback HTTP fallido: ' . $test_response->get_error_message();
        } else {
            $test_code = wp_remote_retrieve_response_code($test_response);
            if ($test_code >= 500) {
                $rollback_needed = true;
                $reason = 'El sitio arrojó un error interno de servidor (HTTP ' . $test_code . '). WSOD prevenida.';
            }
        }

        // 5. Rollback en caso de fallos
        if ($rollback_needed) {
            // Eliminar la carpeta fallida
            if (file_exists($plugin_dir)) {
                $this->recursive_rmdir($plugin_dir);
            }
            // Restaurar versión _old de regreso a activa
            if (file_exists($plugin_old_dir)) {
                rename($plugin_old_dir, $plugin_dir);
            }
            
            if (function_exists('wp_clean_plugins_cache')) {
                wp_clean_plugins_cache(true);
            }
            
            return array('success' => false, 'message' => 'Rollback automático ejecutado exitosamente. Razón: ' . $reason);
        }

        // 6. Limpieza final de la versión antigua si todo fue exitoso
        if (file_exists($plugin_old_dir)) {
            $this->recursive_rmdir($plugin_old_dir);
        }

        return array(
            'success' => true,
            'message' => 'Plugin Sentinel auto-actualizado exitosamente con verificación de loopback.'
        );
    }

    /**
     * Helper recursivo para borrar carpetas no vacías
     */
    private function recursive_rmdir($dir) {
        if (!is_dir($dir)) {
            return;
        }
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->recursive_rmdir($path);
            } else {
                @unlink($path);
            }
        }
        @rmdir($dir);
    }
}
