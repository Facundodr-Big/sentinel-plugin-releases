<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Sentinel_Journal Class
 *
 * This class is responsible for logging system events using the Singleton pattern.
 * It registers WordPress hooks to capture key system events and stores them in an SQLite database.
 */
class Sentinel_Journal {

    /**
     * The instance of this class.
     *
     * @var Sentinel_Journal|null
     */
    private static $instance = null;

    /**
     * The database handler instance.
     *
     * @var Sentinel_SQLite_DB
     */
    private $db_handler;

    /**
     * Get the instance of this class.
     *
     * @return Sentinel_Journal
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the class and register hooks.
     */
    private function __construct() {
        $this->db_handler = Sentinel_SQLite_DB::get_instance();

        // Register WordPress hooks
        add_action('activated_plugin', array($this, 'log_plugin_activated'));
        add_action('deactivated_plugin', array($this, 'log_plugin_deactivated'));
        add_action('upgrader_process_complete', array($this, 'log_system_upgraded'), 10, 2);
        add_action('switch_theme', array($this, 'log_theme_switched'));
        add_action('add_attachment', array($this, 'log_attachment_added'));
        add_action('delete_attachment', array($this, 'log_attachment_deleted'));
    }

    /**
     * Log a plugin activation event.
     *
     * @param string $plugin Path to the activated plugin file relative to the plugins directory.
     */
    public function log_plugin_activated($plugin) {
        $this->log_event('plugin_activated', array('plugin' => $plugin));
    }

    /**
     * Log a plugin deactivation event.
     *
     * @param string $plugin Path to the deactivated plugin file relative to the plugins directory.
     */
    public function log_plugin_deactivated($plugin) {
        $this->log_event('plugin_deactivated', array('plugin' => $plugin));
    }

    /**
     * Log a system upgrade event.
     *
     * @param object $upgrader Upgrader instance.
     * @param array  $options Upgrade options.
     */
    public function log_system_upgraded($upgrader, $options) {
        if (isset($options['action']) && $options['action'] === 'update') {
            $this->log_event('system_upgraded', array(
                'type' => isset($options['type']) ? $options['type'] : 'unknown',
                'updated' => isset($options['plugins']) ? $options['plugins'] : (isset($options['themes']) ? $options['themes'] : [])
            ));
        }
    }

    /**
     * Log a theme switch event.
     *
     * @param string $new_theme Name of the new theme.
     */
    public function log_theme_switched($new_theme) {
        $this->log_event('theme_switched', array('theme' => $new_theme));
    }

    /**
     * Log an attachment addition event.
     *
     * @param int $attachment_id ID of the newly added attachment.
     */
    public function log_attachment_added($attachment_id) {
        $file = get_attached_file($attachment_id);
        $this->log_event('attachment_added', array(
            'id' => $attachment_id,
            'path' => $file
        ));
    }

    /**
     * Log an attachment deletion event.
     *
     * @param int $attachment_id ID of the deleted attachment.
     */
    public function log_attachment_deleted($attachment_id) {
        $this->log_event('attachment_deleted', array('id' => $attachment_id));
    }

    /**
     * Common method to log an event.
     *
     * @param string $event_type Type of the event.
     * @param mixed  $payload Data related to the event.
     */
    private function log_event($event_type, $payload) {
        $timestamp = time(); // Store as unix epoch integer for consistency with SQLite schema
        $json_payload = json_encode($payload);

        try {
            $this->db_handler->query_events(
                "INSERT INTO events (event_type, timestamp, payload) VALUES (:event_type, :timestamp, :payload)",
                array(
                    'event_type' => $event_type,
                    'timestamp'  => $timestamp,
                    'payload'    => $json_payload
                )
            );
        } catch (Exception $e) {
            error_log("Error logging event in Sentinel: " . $e->getMessage());
        }
    }

    /**
     * Prevent cloning of the instance.
     */
    private function __clone() {}

    /**
     * Prevent unserializing of the instance.
     */
    public function __wakeup() {}
}