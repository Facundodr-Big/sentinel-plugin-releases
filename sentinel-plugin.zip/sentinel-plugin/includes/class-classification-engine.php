<?php
/**
 * Sentinel Classification Engine Class
 *
 * @package Sentinel
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Singleton class for the classification engine.
 */
class Sentinel_Classification_Engine {

    /**
     * The instance of this class.
     *
     * @var Sentinel_Classification_Engine|null
     */
    private static $instance = null;

    /**
     * Database handler instance.
     *
     * @var Sentinel_SQLite_DB
     */
    private $db_handler;

    /**
     * Get the instance of this class.
     *
     * @return Sentinel_Classification_Engine
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->db_handler = Sentinel_SQLite_DB::get_instance();
    }

    /**
     * Classify a single table based on its structure and history.
     *
     * @param string $table_name The name of the table to classify.
     * @return array An associative array with 'score' and 'classification'.
     */
    public function classify_table($table_name) {
        global $wpdb;

        // Initialize default values
        $score = 50;
        $classification = 'E'; // E = Unknown (UNKNOWN = INCLUDE)

        // Sanitize input to prevent SQL injection in dynamic table queries
        $clean_table = preg_replace('/[^a-zA-Z0-9_\-\$]/', '', $table_name);

        // Level 1 - Known patterns (check relative to WordPress table name suffix)
        $clean_suffix = preg_replace('/^' . preg_quote($wpdb->prefix, '/') . '/', '', $clean_table);

        if (preg_match('/^(options|users|usermeta)$/i', $clean_suffix)) {
            $classification = 'A'; // Critical
            $score = 100;
        } elseif (preg_match('/^(posts|postmeta|terms|termmeta|comments|commentmeta|term_relationships)$/i', $clean_suffix)) {
            $classification = 'B'; // Content
            $score = 95;
        } elseif (preg_match('/^(woocommerce_|fluentcrm_|wpforms_|learndash_|lifterlms_)/i', $clean_suffix)) {
            $classification = 'C'; // Operational
            $score = 85;
        } elseif (preg_match('/^(sessions|transient|cache|statistics|wordfence|redirection_)/i', $clean_suffix)) {
            $classification = 'D'; // Temporary
            $score = 20;
        }

        // Fetch columns for Level 2 and Level 4 if needed
        $columns = [];
        if (!in_array($classification, ['A', 'B'], true)) {
            $columns_res = $wpdb->get_results("SHOW COLUMNS FROM `{$clean_table}`");
            if (is_array($columns_res)) {
                $columns = $columns_res;
            }
        }

        // Level 2 - Structural analysis
        if (!in_array($classification, ['A', 'B', 'D'], true) && !empty($columns)) {
            $key_columns = ['user_id', 'customer_id', 'email', 'order_id', 'transaction_id', 'course_id'];
            foreach ($columns as $column) {
                if (in_array(strtolower($column->Field), $key_columns, true)) {
                    $score += 15;
                    if ('E' === $classification) {
                        $classification = 'C';
                    }
                    break;
                }
            }
        }

        // Level 4 - Detection of temporals (if not A or B)
        if (!in_array($classification, ['A', 'B'], true) && !empty($columns)) {
            $temporal_columns = ['expires', 'expiration', 'ttl', 'cache_key', 'session_id'];
            foreach ($columns as $column) {
                if (in_array(strtolower($column->Field), $temporal_columns, true)) {
                    $score -= 30;
                    break;
                }
            }
            if ($score < 40) {
                $classification = 'D';
            }
        }

        // Level 3 - Growth analysis (query growth history in SQLite files.db)
        $growth_history = $this->db_handler->query_files(
            "SELECT rows_count FROM db_growth_history WHERE table_name = :table ORDER BY timestamp DESC LIMIT 5",
            array('table' => $clean_table)
        );
        
        if (is_array($growth_history) && count($growth_history) > 1) {
            if ($this->is_constant_growth($growth_history)) {
                $score += 10;
            }
        }

        // Final score adjustments & classification mapping
        if ($score >= 90) {
            $classification = ($classification === 'B') ? 'B' : 'A';
        } elseif ($score >= 70) {
            $classification = 'C';
        } elseif ($score < 40) {
            $classification = 'D';
        } else {
            $classification = 'E'; // Fallback to Unknown (UNKNOWN = INCLUDE)
        }

        // Persist classification in SQLite
        $this->db_handler->query_files(
            "INSERT OR REPLACE INTO db_tables (table_name, score, classification, last_analyzed) VALUES (:table, :score, :class, :now)",
            array(
                'table' => $clean_table,
                'score' => $score,
                'class' => $classification,
                'now'   => time()
            )
        );

        return [
            'score'          => $score,
            'classification' => $classification,
        ];
    }

    /**
     * Classify all tables in the WordPress database.
     *
     * @return array An associative array of table names with their classifications.
     */
    public function classify_all_tables() {
        global $wpdb;

        $table_names = $wpdb->get_col("SHOW TABLES");
        $classifications = [];

        if (is_array($table_names)) {
            foreach ($table_names as $table_name) {
                // Classify all tables that belong to this WP installation prefix
                if (strpos($table_name, $wpdb->prefix) === 0) {
                    $classifications[$table_name] = $this->classify_table($table_name);
                }
            }
        }

        return $classifications;
    }

    /**
     * Check if the growth history indicates constant growth.
     *
     * @param array $growth_history An array of growth records.
     * @return bool True if there is constant growth, false otherwise.
     */
    private function is_constant_growth($growth_history) {
        $previous_count = null;
        $growth_steps = 0;
        
        // Items are in DESC order, reverse them to evaluate chronological growth
        $history = array_reverse($growth_history);
        
        foreach ($history as $record) {
            $count = (int)$record['rows_count'];
            if ($previous_count !== null) {
                if ($count > $previous_count) {
                    $growth_steps++;
                }
            }
            $previous_count = $count;
        }

        return $growth_steps >= (count($history) - 1) && $growth_steps > 0;
    }
}