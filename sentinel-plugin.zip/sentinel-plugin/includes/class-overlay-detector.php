<?php
/**
 * Class Sentinel_Overlay_Detector
 *
 * This class is responsible for detecting overlays in a given component directory by comparing local file hashes
 * with official hashes provided.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Overlay_Detector {

    /**
     * Instance of the class.
     *
     * @var Sentinel_Overlay_Detector|null
     */
    private static $instance = null;

    /**
     * Get the instance of the class.
     *
     * @return Sentinel_Overlay_Detector
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {}

    /**
     * Detect overlays in a given component directory.
     *
     * @param string $component_path   The absolute path to the local component directory.
     * @param array  $official_hashes An associative array of relative paths => official SHA-256 hashes.
     *
     * @return array An array with detection results or an error message.
     */
    public function detect_overlays($component_path, $official_hashes) {
        if (empty($component_path) || !file_exists($component_path)) {
            return ['error' => 'Invalid component path.'];
        }
        if (!is_array($official_hashes)) {
            return ['error' => 'Invalid official hashes array.'];
        }

        // Generate local fingerprint
        $fingerprint_generator = Sentinel_Fingerprint_Generator::get_instance();
        $local_data = $fingerprint_generator->generate_fingerprint($component_path);

        if (empty($local_data) || !is_array($local_data) || !isset($local_data['files'])) {
            return ['error' => 'Failed to generate local fingerprint.'];
        }

        $local_files = $local_data['files'];

        // Initialize detection results
        $modified = [];
        $added = [];
        $missing = [];

        // Compare local fingerprint files with official hashes
        foreach ($official_hashes as $relative_path => $official_hash) {
            if (isset($local_files[$relative_path])) {
                if ($local_files[$relative_path] !== $official_hash) {
                    $modified[] = $relative_path;
                }
            } else {
                $missing[] = $relative_path;
            }
        }

        foreach ($local_files as $relative_path => $local_hash) {
            if (!isset($official_hashes[$relative_path])) {
                $added[] = $relative_path;
            }
        }

        // Calculate total overlays
        $total_overlays = count($modified) + count($added) + count($missing);

        // Return detection results
        return [
            'modified'      => $modified,
            'added'         => $added,
            'missing'       => $missing,
            'total_overlays' => $total_overlays,
        ];
    }
}