<?php
/**
 * Sentinel Outbound Beacon & Heartbeat
 * Permite al plugin enviar telemetría de forma saliente hacia Sentinel Control Center,
 * eludiendo el 100% de los bloqueos WAF / Imunify360 / ModSecurity entrantes.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Beacon {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Registrar cron de telemetría periódica saliente
        add_action('sentinel_hourly_beacon_cron', array($this, 'send_beacon'));
        if (!wp_next_scheduled('sentinel_hourly_beacon_cron')) {
            wp_schedule_event(time() + 120, 'hourly', 'sentinel_hourly_beacon_cron');
        }

        // Disparar beacon saliente tras actualizar plugins o temas
        add_action('upgrader_process_complete', array($this, 'on_upgrade_complete'), 10, 2);
    }

    /**
     * Enviar telemetría saliente hacia Sentinel Control Center
     */
    public function send_beacon($reason = 'scheduled') {
        $hub_url = get_option('controlcenter_hub_url');
        if (empty($hub_url)) {
            // Intentar detectar si se definió una constante global
            if (defined('SENTINEL_HUB_URL')) {
                $hub_url = SENTINEL_HUB_URL;
            } else {
                return false; // Sin hub configurado
            }
        }

        $hub_url = rtrim($hub_url, '/');
        $endpoint = $hub_url . '/api/client/beacon';

        $agent_uuid = get_option('controlcenter_agent_uuid');
        $agent_secret = get_option('controlcenter_agent_secret');

        if (empty($agent_uuid) || empty($agent_secret)) {
            return false;
        }

        // 1. Recolectar datos de telemetría liviana
        if (!class_exists('Sentinel_Collector')) {
            require_once dirname(__FILE__) . '/class-collector.php';
        }
        $telemetry = Sentinel_Collector::get_instance()->collect_all();
        $telemetry['beacon_reason'] = sanitize_text_field($reason);
        $telemetry['beacon_time'] = current_time('mysql');

        // 2. Firmar petición HMAC
        $timestamp = time();
        $data_to_sign = $agent_uuid . $timestamp;
        $signature = hash_hmac('sha256', $data_to_sign, $agent_secret);

        $payload = array(
            'agent_uuid' => $agent_uuid,
            'timestamp'  => $timestamp,
            'signature'  => $signature,
            'site_url'   => home_url(),
            'data'       => $telemetry
        );

        // 3. Enviar HTTP POST saliente con WordPress nativo (wp_remote_post)
        $response = wp_remote_post($endpoint, array(
            'timeout'     => 20,
            'redirection' => 3,
            'httpversion' => '1.1',
            'blocking'    => false, // Asíncrono no-bloqueante para no retrasar a los usuarios
            'headers'     => array(
                'Content-Type'        => 'application/json; charset=utf-8',
                'X-Sentinel-Agent'    => $agent_uuid,
                'X-Sentinel-Signature'=> $signature,
                'X-Sentinel-Timestamp'=> $timestamp
            ),
            'body'        => wp_json_encode($payload),
            'sslverify'   => false
        ));

        update_option('sentinel_last_beacon_sent', current_time('mysql'));
        return true;
    }

    public function on_upgrade_complete($upgrader_object, $options) {
        // Enviar beacon inmediatamente tras completar una actualización
        $this->send_beacon('post_upgrade');
    }
}
