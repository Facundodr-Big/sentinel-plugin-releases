<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Collector {

    /**
     * The singleton instance of the class.
     *
     * @var Sentinel_Collector|null
     */
    private static $instance = null;

    /**
     * Returns the singleton instance of the class.
     *
     * @return Sentinel_Collector
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {}

    /**
     * Prevents cloning of the instance.
     */
    private function __clone() {}

    /**
     * Prevents unserializing of the instance.
     */
    public function __wakeup() {}

    /**
     * Returns the current version of WordPress.
     *
     * @return string
     */
    public function get_wordpress_version() {
        global $wp_version;
        return esc_html($wp_version);
    }

    /**
     * Returns the PHP version.
     *
     * @return string
     */
    public function get_php_version() {
        return esc_html(PHP_VERSION);
    }

    /**
     * Returns the MySQL server version.
     *
     * @return string
     */
    public function get_mysql_version() {
        global $wpdb;
        return esc_html($wpdb->db_version());
    }

    /**
     * Returns a list of all installed plugins with their details.
     *
     * @return array
     */
    public function get_plugins() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        $plugin_list = [];

        foreach ($plugins as $path => $details) {
            $is_active = in_array($path, $active_plugins);
            $plugin_list[] = [
                'name'    => esc_html($details['Name']),
                'version' => esc_html($details['Version']),
                'active'  => (bool) $is_active,
                'file'    => $path,
            ];
        }

        return $plugin_list;
    }

    /**
     * Returns a list of all installed themes with their details.
     *
     * @return array
     */
    public function get_themes() {
        $themes = wp_get_themes();
        $active_theme = wp_get_theme();
        $theme_list = [];

        foreach ($themes as $theme) {
            $is_active = $theme->get_stylesheet() === $active_theme->get_stylesheet();
            $theme_list[] = [
                'name'    => esc_html($theme->get('Name')),
                'version' => esc_html($theme->get('Version')),
                'active'  => (bool) $is_active,
                'slug'    => esc_html($theme->get_stylesheet()),
            ];
        }

        return $theme_list;
    }

    /**
     * Returns the disk usage details of the WordPress directory.
     *
     * @return array
     */
    public function get_disk_usage() {
        $wp_dir = ABSPATH;
        $total_space = @disk_total_space($wp_dir);
        $free_space = @disk_free_space($wp_dir);
        
        if ($total_space === false || $free_space === false) {
            return [
                'total_space' => 0,
                'free_space'  => 0,
                'used_space'  => 0,
                'percent'     => 0,
            ];
        }
        
        $used_space = $total_space - $free_space;
        $percent_used = $total_space > 0 ? ($used_space / $total_space) * 100 : 0;

        return [
            'total_space' => (int) $total_space,
            'free_space'  => (int) $free_space,
            'used_space'  => (int) $used_space,
            'percent'     => round($percent_used, 2),
        ];
    }

    /**
     * Collects all the system information and returns it as an associative array.
     *
     * @return array
     */
    public function collect_all() {
        return [
            'site_name'        => esc_html(get_bloginfo('name')),
            'site_url'         => esc_html(site_url()),
            'wordpress'        => $this->get_wordpress_version(),
            'php'              => $this->get_php_version(),
            'mysql'            => $this->get_mysql_version(),
            'plugins'          => $this->get_plugins(),
            'themes'           => $this->get_themes(),
            'disk_usage'       => $this->get_disk_usage(),
            'sentinel_version' => defined('SENTINEL_VERSION') ? SENTINEL_VERSION : '1.0.0',
        ];
    }
}