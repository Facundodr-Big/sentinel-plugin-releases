<?php
// includes/class-file-classification.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Singleton class for file classification.
 */
class Sentinel_File_Classification {

    /**
     * Instance of the class.
     *
     * @var self
     */
    private static $instance;

    /**
     * Database instance.
     *
     * @var Sentinel_SQLite_DB
     */
    private $db;

    /**
     * Private constructor to prevent instantiation.
     */
    private function __construct() {
        // Initialize the database instance.
        $this->db = Sentinel_SQLite_DB::get_instance();
    }

    /**
     * Prevent cloning of the class.
     */
    private function __clone() {}

    /**
     * Prevent unserializing of the class.
     */
    public function __wakeup() {}

    /**
     * Get the instance of the class.
     *
     * @return self
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Classify a file path.
     *
     * @param string $file_path The file path to classify.
     * @return string The classification category ('A', 'B', 'C', 'D', 'E', 'F').
     */
    public function classify_path($file_path) {
        // Convert the path to a standardized relative format.
        $relative_path = str_replace(ABSPATH, '', $file_path);
        $relative_path = str_replace('\\', '/', $relative_path);

        // Classify the file path.
        if (strpos($relative_path, 'wp-admin/') === 0 || strpos($relative_path, 'wp-includes/') === 0 ||
            in_array(basename($relative_path), ['wp-login.php', 'wp-settings.php', 'xmlrpc.php', 'index.php'])) {
            return 'A'; // Core
        } elseif (strpos($relative_path, 'wp-content/plugins/') === 0) {
            return 'B'; // Plugins
        } elseif (strpos($relative_path, 'wp-content/themes/') === 0) {
            return 'C'; // Themes
        } elseif (strpos($relative_path, 'wp-content/uploads/') === 0) {
            return 'D'; // Uploads
        } elseif (strpos($relative_path, 'wp-content/mu-plugins/') === 0 || (strpos($relative_path, '.php') !== false && !in_array(basename($relative_path), ['wp-login.php', 'wp-settings.php', 'xmlrpc.php', 'index.php']))) {
            return 'E'; // Custom
        } else {
            return 'F'; // Unknown
        }
    }

    /**
     * Classify all files in the database.
     */
    public function classify_all_files() {
        // Get all files that need classification.
        $files = $this->db->query_files("SELECT path FROM files WHERE classification IS NULL");
        if (empty($files) || !is_array($files)) {
            return;
        }

        foreach ($files as $file) {
            $path = $file['path'];
            $classification = $this->classify_path($path);

            // Update the classification in the database.
            $this->db->query_files(
                "UPDATE files SET classification = :class WHERE path = :path",
                [
                    'class' => $classification,
                    'path' => $path
                ]
            );
        }
    }
}