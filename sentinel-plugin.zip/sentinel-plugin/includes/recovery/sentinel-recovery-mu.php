<?php
/*
 * Sentinel Recovery Early Interceptor
 *
 * NOTA: Este es un helper para Must-Use (MU) plugin. Es copiado automáticamente a wp-content/mu-plugins/
 * durante la activación de Sentinel. No debe incluir cabeceras de plugin estándar de WordPress
 * para evitar que sea detectado o listado como un plugin independiente en el ZIP o en el panel.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Escuchar peticiones de recuperación
if (isset($_POST['sentinel_emergency_action']) && $_POST['sentinel_emergency_action'] === '1') {
    $controlcenter_dir = WP_CONTENT_DIR . '/controlcenter';
    $recovery_script = $controlcenter_dir . '/recovery/recovery.php';
    
    if (file_exists($recovery_script)) {
        // Cargar el script de recuperación de forma autónoma
        require_once $recovery_script;
        exit;
    }
}
