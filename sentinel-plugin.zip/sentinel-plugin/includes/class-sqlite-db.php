<?php
/**
 * Class Sentinel_SQLite_DB
 *
 * Singleton class to manage SQLite database connections and queries.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_SQLite_DB {

    /**
     * Singleton instance.
     *
     * @var Sentinel_SQLite_DB|null
     */
    private static $instance = null;

    /**
     * Last connection or initialization error.
     *
     * @var string|null
     */
    public $last_error = null;

    /**
     * Private constructor to prevent instantiation.
     */
    private function __construct() {
        // Check if the PDO SQLite extension is loaded.
        if (!extension_loaded('pdo_sqlite')) {
            error_log('PDO SQLite extension is not loaded.');
        }
    }

    /**
     * Get the singleton instance.
     *
     * @return Sentinel_SQLite_DB
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Check if PDO and pdo_sqlite extension are available on the server.
     *
     * @return bool
     */
    public static function is_pdo_sqlite_available() {
        return class_exists('PDO') && (extension_loaded('pdo_sqlite') || in_array('sqlite', PDO::getAvailableDrivers()));
    }

    /**
     * Get the PDO connection for files.db and initialize tables if necessary.
     *
     * @return PDO|null
     */
    public function get_files_connection() {
        if (!class_exists('PDO')) {
            $this->last_error = 'PHP PDO extension is missing on this server.';
            error_log('Sentinel SQLite DB Error: PDO extension is missing on this server.');
            return null;
        }

        $db_path = WP_CONTENT_DIR . '/controlcenter/indexes/files.db';
        try {
            $db_dir = dirname($db_path);
            if (!file_exists($db_dir)) {
                wp_mkdir_p($db_dir);
                @chmod($db_dir, 0755);
            }
            $pdo = new PDO('sqlite:' . $db_path);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("PRAGMA journal_mode=WAL;");
            $pdo->exec("PRAGMA synchronous=NORMAL;");
            $pdo->exec("PRAGMA busy_timeout=30000;");

            // Initialize tables if they do not exist
            $this->initialize_tables($pdo);

            return $pdo;
        } catch (\Throwable $e) {
            $this->last_error = $e->getMessage();
            error_log('Failed to connect to files.db: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get the PDO connection for events.db.
     *
     * @return PDO|null
     */
    public function get_events_connection() {
        if (!class_exists('PDO')) {
            $this->last_error = 'PHP PDO extension is missing on this server.';
            error_log('Sentinel SQLite DB Error: PDO extension is missing on this server.');
            return null;
        }

        $db_path = WP_CONTENT_DIR . '/controlcenter/journals/events.db';
        try {
            $db_dir = dirname($db_path);
            if (!file_exists($db_dir)) {
                wp_mkdir_p($db_dir);
                @chmod($db_dir, 0755);
            }
            $pdo = new PDO('sqlite:' . $db_path);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("PRAGMA journal_mode=WAL;");
            $pdo->exec("PRAGMA synchronous=NORMAL;");
            $pdo->exec("PRAGMA busy_timeout=30000;");
            return $pdo;
        } catch (\Throwable $e) {
            $this->last_error = $e->getMessage();
            error_log('Failed to connect to events.db: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Initialize tables in the database.
     *
     * @param PDO $pdo The PDO connection.
     */
    private function initialize_tables($pdo) {
        // Check if db_tables table exists
        $exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='db_tables';")->fetch();
        if (!$exists) {
            $pdo->exec("
                CREATE TABLE db_tables (
                    table_name TEXT PRIMARY KEY,
                    score INTEGER,
                    classification TEXT,
                    last_analyzed INTEGER
                );
            ");
        }

        // Check if db_chunks table exists
        $exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='db_chunks';")->fetch();
        if (!$exists) {
            $pdo->exec("
                CREATE TABLE db_chunks (
                    table_name TEXT,
                    chunk_key TEXT,
                    hash TEXT,
                    last_seen INTEGER,
                    PRIMARY KEY (table_name, chunk_key)
                );
            ");
        }

        // Check if db_growth_history table exists
        $exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='db_growth_history';")->fetch();
        if (!$exists) {
            $pdo->exec("
                CREATE TABLE db_growth_history (
                    table_name TEXT,
                    rows_count INTEGER,
                    timestamp INTEGER
                );
            ");
        }

        // Check if files table exists and add columns if necessary
        $this->ensure_files_table_columns($pdo);
    }

    /**
     * Ensure the 'files' table has the required columns.
     *
     * @param PDO $pdo The PDO connection.
     */
    private function ensure_files_table_columns($pdo) {
        // Check if files table exists
        $exists = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='files';")->fetch();
        if (!$exists) {
            $pdo->exec("
                CREATE TABLE files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE,
                    size INTEGER,
                    mtime INTEGER,
                    hash TEXT,
                    status TEXT,
                    last_scan INTEGER,
                    classification TEXT,
                    first_seen INTEGER,
                    last_seen INTEGER
                );
            ");
            return;
        }

        // Check columns
        $columns = $pdo->query("PRAGMA table_info(files);")->fetchAll(PDO::FETCH_ASSOC);
        $column_names = array_column($columns, 'name');

        // Migración: si existe 'file_name' pero no 'path', recrear la tabla
        if (in_array('file_name', $column_names) && !in_array('path', $column_names)) {
            $pdo->exec("DROP TABLE files;");
            $pdo->exec("
                CREATE TABLE files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE,
                    size INTEGER,
                    mtime INTEGER,
                    hash TEXT,
                    status TEXT,
                    last_scan INTEGER,
                    classification TEXT,
                    first_seen INTEGER,
                    last_seen INTEGER
                );
            ");
            return;
        }

        // Añadir columnas individuales si faltan
        if (!in_array('classification', $column_names)) {
            $pdo->exec("ALTER TABLE files ADD COLUMN classification TEXT;");
        }

        if (!in_array('first_seen', $column_names)) {
            $pdo->exec("ALTER TABLE files ADD COLUMN first_seen INTEGER;");
        }

        if (!in_array('last_seen', $column_names)) {
            $pdo->exec("ALTER TABLE files ADD COLUMN last_seen INTEGER;");
        }
    }

    /**
     * Execute a query on files.db.
     *
     * @param string $sql SQL statement.
     * @param array  $params Parameters for prepared statements.
     * @return mixed
     */
    public function query_files($sql, $params = []) {
        $pdo = $this->get_files_connection();
        if (!$pdo) {
            return false;
        }
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $trimmed_sql = stripos(trim($sql), 'SELECT') === 0 || stripos(trim($sql), 'PRAGMA') === 0;
            if ($trimmed_sql) {
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log('Query failed on files.db: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Execute a query on events.db.
     *
     * @param string $sql SQL statement.
     * @param array  $params Parameters for prepared statements.
     * @return mixed
     */
    public function query_events($sql, $params = []) {
        $pdo = $this->get_events_connection();
        if (!$pdo) {
            return false;
        }
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $trimmed_sql = stripos(trim($sql), 'SELECT') === 0 || stripos(trim($sql), 'PRAGMA') === 0;
            if ($trimmed_sql) {
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log('Query failed on events.db: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Prevent cloning of the instance.
     */
    private function __clone() {}

    /**
     * Prevent unserializing of the instance.
     */
    public function __wakeup() {}
}