<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Sentinel_API_Handler {

    private static $instance = null;
    private $namespace = 'controlcenter/v1';
    private $agent_secret;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->agent_secret = get_option('controlcenter_agent_secret');
        add_action('rest_api_init', array($this, 'register_routes'));
        add_filter('rest_pre_dispatch', array($this, 'decode_masked_payload'), 10, 3);
    }

    /**
     * ANTI-MODSECURITY: Decode payload masked as Base64 Form-Data.
     * Sentinel Backend ahora envia los JSON camuflados en form-data base64 para evitar firewalls.
     */
    public function decode_masked_payload($result, $server, $request) {
        $route = $request->get_route();
        // Solo actuar en rutas del plugin
        if (strpos($route, '/controlcenter/') === false && strpos($route, '/sentinel/') === false) {
            return $result;
        }

        // Si la request trae un "payload" (en form-data o URL), lo decodificamos
        $masked_payload = $request->get_param('payload');
        if (!empty($masked_payload)) {
            $json_str = base64_decode($masked_payload);
            if ($json_str !== false) {
                $decoded_params = json_decode($json_str, true);
                if (is_array($decoded_params)) {
                    // Inyectar los parametros decodificados en el Request
                    $request->set_body_params(array_merge($request->get_body_params(), $decoded_params));
                }
            }
        }
        return $result;
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/site-info', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_site_info'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/build-index', array(
            'methods' => 'POST',
            'callback' => array($this, 'build_index'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/index-status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_index_status'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/changes', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_changes'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-analyze', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_db_analyze'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-classify', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_db_classify'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-snapshot', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_db_snapshot'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-classify', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_files_classify'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-scan-malware', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_files_scan_malware'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-snapshot', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_files_snapshot'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/components', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_components'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/component-fingerprint', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_component_fingerprint'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/component-overlays', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_component_overlays'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/execute-job', array(
            'methods' => 'POST',
            'callback' => array($this, 'execute_job'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/validate', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_validate'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/files', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_files'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/db', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_db'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/commit', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_commit'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/rollback', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_rollback'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        $ns_v1 = 'sentinel/v1';

        register_rest_route($ns_v1, '/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_wpvivid_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_backup_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backups', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_backups'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup/delete', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_wpvivid_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/check', array(
            'methods'  => 'GET',
            'callback' => array($this, 'check_backup_db_support'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/mysqldump', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_mysqldump'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_backup_db_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/reset', array(
            'methods'  => 'POST',
            'callback' => array($this, 'reset_backups_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/finish', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_finish'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/async/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_async_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/async/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_async_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/async/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_files_async_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/async/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_files_async_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_backup_files_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/incremental', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_incremental'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/exclusions', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_file_exclusions'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/exclusions', array(
            'methods'  => 'POST',
            'callback' => array($this, 'update_file_exclusions'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/plugin', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_plugin'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/theme', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_theme'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/core', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_core'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/restore', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_restore'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/restore/upload', array(
            'methods'  => 'POST',
            'callback' => array($this, 'upload_backup_file'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/download', array(
            'methods'  => 'GET',
            'callback' => array($this, 'download_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/delete', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/self', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_self_update'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));
    }

    public function authenticate_request() {
        $agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? sanitize_text_field($_SERVER['HTTP_X_AGENT_ID']) : '';
        $timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
        $signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? sanitize_text_field($_SERVER['HTTP_X_SIGNATURE']) : '';

        // 1. Si están las cabeceras HMAC, validar firma
        if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
            $current_time = time();
            if (abs($current_time - $timestamp) > 300) { // 5 min tolerancia
                return false;
            }
            $data_to_sign = $agent_id . $timestamp;
            $expected_signature = hash_hmac('sha256', $data_to_sign, $this->agent_secret);
            return hash_equals($expected_signature, $signature);
        }

        // 2. Fallback: Validar con API Key (Bearer o X-Sentinel-API-Key)
        $client_key = '';
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
            if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
                $client_key = trim($matches[1]);
            }
        } elseif (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['Authorization'])) {
                if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                    $client_key = trim($matches[1]);
                }
            }
        }
        if (empty($client_key) && isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
            $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
        }
        if (empty($client_key) && isset($_REQUEST['sentinel_key'])) {
            $client_key = trim($_REQUEST['sentinel_key']);
        }

        return !empty($client_key) && hash_equals($this->agent_secret, $client_key);
    }

    public function get_site_info() {
        return Sentinel_Collector::get_instance()->collect_all();
    }

    public function build_index($request) {
        $limit = isset($request['limit']) ? absint($request['limit']) : 500;
        $status = Sentinel_Indexer::get_instance()->build_index($limit);

        $db = Sentinel_SQLite_DB::get_instance();
        $queue_count_res = $db->query_files("SELECT COUNT(*) as count FROM scan_queue");
        $scan_queue = !empty($queue_count_res) ? (int)$queue_count_res[0]['count'] : 0;

        return array(
            'status'     => $status,
            'scan_queue' => $scan_queue
        );
    }

    public function get_index_status() {
        return Sentinel_Indexer::get_instance()->get_scan_status();
    }

    public function get_changes() {
        return Sentinel_Indexer::get_instance()->get_detected_changes();
    }

    public function get_db_analyze() {
        return Sentinel_DB_Analyzer::get_instance()->analyze_database();
    }

    public function get_db_classify() {
        return Sentinel_Classification_Engine::get_instance()->classify_all_tables();
    }

    public function post_db_snapshot($request) {
        $table = isset($request['table']) ? sanitize_text_field($request['table']) : '';
        $chunk_size = isset($request['chunk_size']) ? absint($request['chunk_size']) : 1000;
        return Sentinel_Snapshot_Engine::get_instance()->create_table_snapshot($table, $chunk_size);
    }

    public function get_files_classify() {
        return Sentinel_File_Classification::get_instance()->classify_all_files();
    }

    public function post_files_scan_malware($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        if (!empty($path)) {
            return Sentinel_Malware_Scanner::get_instance()->scan_file($path);
        } else {
            return Sentinel_Malware_Scanner::get_instance()->scan_files_with_status(array('NEW', 'MODIFIED'));
        }
    }

    public function get_files_snapshot($request) {
        $classification = isset($request['classification']) ? sanitize_text_field($request['classification']) : '';
        $status = isset($request['status']) ? sanitize_text_field($request['status']) : '';
        return Sentinel_Snapshot_Engine::get_instance()->get_files_snapshot($classification, $status);
    }

    public function get_components() {
        return Sentinel_Component_Discovery::get_instance()->discover_components();
    }

    public function post_component_fingerprint($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        return Sentinel_Fingerprint_Generator::get_instance()->generate_fingerprint($path);
    }

    public function post_component_overlays($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        $official_hashes = isset($request['official_hashes']) && is_array($request['official_hashes']) ? $request['official_hashes'] : array();
        return Sentinel_Overlay_Detector::get_instance()->detect_overlays($path, $official_hashes);
    }

    public function execute_job($request) {
        // Implement job queuing logic here
        return true;
    }

    public function post_restore_validate($request) {
        $recovery_point = isset($request['recovery_point']) ? sanitize_text_field($request['recovery_point']) : '';
        $files = isset($request['files']) && is_array($request['files']) ? $request['files'] : array();

        if (empty($recovery_point) || empty($files)) {
            return new WP_REST_Response(array('status' => 'FAILED', 'error' => 'Missing recovery_point or files list'), 400);
        }

        // Simulación: Comprobar cuáles archivos existen físicamente
        $files_to_overwrite = 0;
        foreach ($files as $file_path) {
            if (file_exists(ABSPATH . $file_path)) {
                $files_to_overwrite++;
            }
        }

        return new WP_REST_Response(array(
            'status' => 'READY',
            'recovery_point' => $recovery_point,
            'files_to_overwrite' => $files_to_overwrite
        ), 200);
    }

    public function post_restore_files($request) {
        $workspace = Sentinel_Recovery_Workspace::get_instance()->prepare_workspace();
        if (!$workspace) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'Could not prepare workspace'), 500);
        }

        $files = isset($request['files']) && is_array($request['files']) ? $request['files'] : array();
        $overlays = isset($request['overlays']) && is_array($request['overlays']) ? $request['overlays'] : array();

        $restored = array();
        $failed = array();

        foreach ($files as $file) {
            $path = isset($file['path']) ? sanitize_text_field($file['path']) : '';
            $content = isset($file['content']) ? sanitize_text_field($file['content']) : '';
            $hash = isset($file['hash']) ? sanitize_text_field($file['hash']) : '';

            $res = Sentinel_File_Recovery::get_instance()->recover_file($path, $content, $hash);
            if ($res['status'] === 'success') {
                $restored[] = $path;
            } else {
                $failed[] = array('path' => $path, 'error' => $res['error']);
            }
        }

        if (!empty($overlays)) {
            Sentinel_File_Recovery::get_instance()->apply_overlays_to_workspace($overlays);
        }

        return new WP_REST_Response(array(
            'status' => 'completed',
            'restored_files' => $restored,
            'failed_files' => $failed
        ), 200);
    }

    public function post_restore_db($request) {
        $chunks = isset($request['chunks']) && is_array($request['chunks']) ? $request['chunks'] : array();
        $category = isset($request['category']) ? sanitize_text_field($request['category']) : '';

        $restored = 0;
        $failed = 0;

        foreach ($chunks as $chunk) {
            $table = isset($chunk['table']) ? sanitize_text_field($chunk['table']) : '';
            $data = isset($chunk['data']) ? $chunk['data'] : '';
            $key = isset($chunk['key']) ? sanitize_text_field($chunk['key']) : '';

            $res = Sentinel_Database_Recovery::get_instance()->restore_table_chunk($table, $data, $key);
            if ($res === true) {
                $restored++;
            } else {
                $failed++;
            }
        }

        if (!empty($category)) {
            Sentinel_Database_Recovery::get_instance()->restore_tables_by_category($category);
        }

        return new WP_REST_Response(array(
            'status' => 'completed',
            'restored_chunks' => $restored,
            'failed_chunks' => $failed
        ), 200);
    }

    public function post_restore_commit($request) {
        $workspace_dir = Sentinel_Recovery_Workspace::WORKSPACE_DIR;
        if (!file_exists($workspace_dir)) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'Workspace not prepared or empty'), 400);
        }

        $files_to_move = array();
        $directory_iterator = new RecursiveDirectoryIterator($workspace_dir, RecursiveDirectoryIterator::SKIP_DOTS);
        $iterator = new RecursiveIteratorIterator($directory_iterator, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($iterator as $item) {
            if ($item->isFile()) {
                $normalized = str_replace('\\', '/', $item->getPathname());
                $relative = ltrim(str_replace(str_replace('\\', '/', $workspace_dir), '', $normalized), '/');
                if ($relative !== 'index.html') {
                    $files_to_move[] = $relative;
                }
            }
        }

        if (empty($files_to_move)) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'No files found in workspace to commit'), 400);
        }

        // Crear pre-restore snapshot para rollback automático
        Sentinel_Rollback_Engine::get_instance()->create_pre_restore_snapshot($files_to_move);

        $start_time = microtime(true);
        $committed = 0;

        foreach ($files_to_move as $file) {
            $src = $workspace_dir . '/' . $file;
            $dest = ABSPATH . $file;
            $dest_dir = dirname($dest);

            if (!file_exists($dest_dir)) {
                wp_mkdir_p($dest_dir);
            }

            if (copy($src, $dest)) {
                $committed++;
            }
        }

        $duration = round(microtime(true) - $start_time, 4);

        // Limpiar el workspace temporal
        Sentinel_Recovery_Workspace::get_instance()->clean_workspace();

        return new WP_REST_Response(array(
            'status' => 'success',
            'committed_files' => $committed,
            'duration_seconds' => $duration
        ), 200);
    }

    public function post_restore_rollback($request) {
        $res = Sentinel_Rollback_Engine::get_instance()->restore_backup_snapshot();
        return new WP_REST_Response($res, 200);
    }

    /**
     * Retorna el estado y telemetría del servidor
     */
    public function get_status($request = null) {
        global $wp_version;

        $wpvivid_status = $this->get_wpvivid_status();

        if (isset($_GET['_nocache'])) {
            wp_update_plugins();
            wp_update_themes();
        }

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins', array());
        $updates = get_site_transient('update_plugins');
        $themes = wp_get_themes();
        $theme_updates = get_site_transient('update_themes');

        $plugin_list = array();
        foreach ($plugins as $file => $data) {
            $is_active = in_array($file, $active_plugins);
            $has_update = false;
            $new_version = '';

            if (is_object($updates) && isset($updates->response) && is_array($updates->response) && isset($updates->response[$file])) {
                $has_update = true;
                $new_version = $updates->response[$file]->new_version;
            }

            $plugin_list[] = array(
                'file'         => $file,
                'name'         => $data['Name'],
                'version'      => $data['Version'],
                'active'       => $is_active,
                'has_update'   => $has_update,
                'new_version'  => $new_version
            );
        }

        $theme_list = array();
        foreach ($themes as $theme) {
            $stylesheet = $theme->get_stylesheet();
            $is_active = $stylesheet === wp_get_theme()->get_stylesheet();
            $has_update = false;
            $new_version = '';

            if (is_object($theme_updates) && isset($theme_updates->response) && is_array($theme_updates->response) && isset($theme_updates->response[$stylesheet])) {
                $has_update = true;
                $theme_data = $theme_updates->response[$stylesheet];
                $new_version = is_array($theme_data) ? $theme_data['new_version'] : (is_object($theme_data) ? $theme_data->new_version : '');
            }

            $theme_list[] = array(
                'name'         => $theme->get('Name'),
                'version'      => $theme->get('Version'),
                'active'       => $is_active,
                'has_update'   => $has_update,
                'new_version'  => $new_version,
                'slug'         => $stylesheet
            );
        }

        $free_disk = function_exists('disk_free_space') ? @disk_free_space(ABSPATH) : 0;
        $total_disk = function_exists('disk_total_space') ? @disk_total_space(ABSPATH) : 0;
        $free_disk = ($free_disk !== false) ? (int)$free_disk : 0;
        $total_disk = ($total_disk !== false) ? (int)$total_disk : 0;

        // DB Size
        global $wpdb;
        $db_data_size = $wpdb->get_var("SELECT SUM(data_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()");
        $db_index_size = $wpdb->get_var("SELECT SUM(index_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()");
        $db_data_size = $db_data_size ? (int)$db_data_size : 0;
        $db_index_size = $db_index_size ? (int)$db_index_size : 0;
        $db_size = $db_data_size + $db_index_size;

        // Uploads Size
        $uploads_dir = wp_upload_dir();
        $uploads_size = 0;
        if (isset($uploads_dir['basedir'])) {
            $uploads_size = $this->get_dir_size($uploads_dir['basedir']);
        }

        // Large backup files scan in the whole WordPress directory (files > 15MB) - only run on manual sync
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $scan_large = isset($params['scan_large']) && $params['scan_large'] === 'true';
        $large_files = array();
        if ($scan_large) {
            try {
                // Intentar extender el tiempo de ejecución para hostings limitados
                @set_time_limit(60);
                $large_files = $this->scan_large_files(ABSPATH, 15728640); // 15MB en bytes
                if (is_array($large_files)) {
                    usort($large_files, function($a, $b) {
                        return $b['size'] - $a['size'];
                    });
                    $large_files = array_slice($large_files, 0, 10);
                } else {
                    $large_files = array();
                }
            } catch (\Throwable $scan_error) {
                // Si falla por falta de recursos o timeouts, devolver vacío sin tumbar el endpoint
                $large_files = array();
                error_log('Sentinel: Scan de archivos grandes falló: ' . $scan_error->getMessage());
            }
        }

        // Estado del Malware Scanner (colas y estados)
        $scan_queue = 0;
        $scan_state = 'IDLE';
        if (class_exists('Sentinel_Indexer')) {
            $indexer = Sentinel_Indexer::get_instance();
            $scan_queue_res = Sentinel_SQLite_DB::get_instance()->query_files("SELECT COUNT(*) as count FROM scan_queue");
            $scan_queue = !empty($scan_queue_res) ? (int)$scan_queue_res[0]['count'] : 0;
            $scan_state = $indexer->is_scan_active() ? 'ACTIVE' : 'COMPLETED';
        }

        // WordPress Core Updates
        $core_updates = get_site_transient('update_core');
        $wp_has_update = false;
        $wp_new_version = '';
        if (is_object($core_updates) && isset($core_updates->updates)) {
            foreach ($core_updates->updates as $update) {
                if (isset($update->response) && $update->response === 'upgrade') {
                    $wp_has_update = true;
                    $wp_new_version = $update->current;
                    break;
                }
            }
        }

        // Indexed Files Count
        $indexed_files_count = 0;
        try {
            if (class_exists('Sentinel_SQLite_DB')) {
                $db = Sentinel_SQLite_DB::get_instance();
                $files_count_res = $db->query_files("SELECT COUNT(*) as count FROM files WHERE status != 'DELETED'");
                if (!empty($files_count_res) && isset($files_count_res[0]['count'])) {
                    $indexed_files_count = (int)$files_count_res[0]['count'];
                }
            }
        } catch (\Exception $e) {
            // Handle exception
        }

        $sentinel_backups = $this->get_sentinel_backups_list();
        if ($wpvivid_status['active']) {
            $wpvivid_backups_res = $this->get_wpvivid_backups();
            if (isset($wpvivid_backups_res['backups']) && is_array($wpvivid_backups_res['backups'])) {
                foreach ($wpvivid_backups_res['backups'] as $wv_backup) {
                    $wv_type_raw = strtolower(isset($wv_backup['type']) ? $wv_backup['type'] : 'full');
                    $mapped_type = 'full';
                    if ($wv_type_raw === 'db') {
                        $mapped_type = 'db';
                    } elseif ($wv_type_raw === 'files' || $wv_type_raw === 'file') {
                        $mapped_type = 'files';
                    } elseif (strpos($wv_type_raw, 'files') !== false || strpos($wv_type_raw, 'db') !== false) {
                        $mapped_type = 'full';
                    }

                    $sentinel_backups[] = array(
                        'filename'       => isset($wv_backup['filename']) ? $wv_backup['filename'] : '',
                        'size'           => isset($wv_backup['size']) ? $wv_backup['size'] : 0,
                        'formatted_size' => isset($wv_backup['formatted_size']) ? $wv_backup['formatted_size'] : '',
                        'date'           => isset($wv_backup['date']) ? $wv_backup['date'] : '',
                        'type'           => $mapped_type,
                        'is_wpvivid'     => true,
                        'wpvivid_id'     => isset($wv_backup['id']) ? $wv_backup['id'] : ''
                    );
                }
            }
        }

        return array(
            'status'            => 'online',
            'sentinel_version'  => SENTINEL_VERSION,
            'wp_version'        => $wp_version,
            'php_version'       => PHP_VERSION,
            'woo_active'        => class_exists('WooCommerce'),
            'disk_space'        => array(
                'free_bytes'    => $free_disk,
                'total_bytes'   => $total_disk,
                'free_percent'  => $total_disk > 0 ? round(($free_disk / $total_disk) * 100, 2) : 0
            ),
            'db_size_bytes'     => $db_size,
            'db_data_size_bytes'=> $db_data_size,
            'db_index_size_bytes'=> $db_index_size,
            'uploads_size_bytes'=> $uploads_size,
            'large_files'       => $large_files,
            'memory_limit'      => ini_get('memory_limit'),
            'max_execution_time'=> ini_get('max_execution_time'),
            'plugins'           => $plugin_list,
            'themes'            => $theme_list,
            'sentinel_backups'  => $sentinel_backups,
            'scan_queue'        => $scan_queue,
            'scan_state'        => $scan_state,
            'wp_has_update'     => $wp_has_update,
            'wp_new_version'    => $wp_new_version,
            'indexed_files_count' => $indexed_files_count,
            'wpvivid_installed' => $wpvivid_status['installed'],
            'wpvivid_active'    => $wpvivid_status['active'],
            'wpvivid_version'   => $wpvivid_status['version']
        );
    }

    /**
     * Retorna el listado de archivos de backup generados en la carpeta del plugin
     */
    private function get_sentinel_backups_list() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $base_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $base_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $backups = array();

        // Escanear subdirectorios db/, files/ y la raíz para compatibilidad retroactiva
        $scan_dirs = array(
            $base_dir . 'db/',
            $base_dir . 'files/',
            $base_dir
        );

        foreach ($scan_dirs as $backup_dir) {
            if (!is_dir($backup_dir)) {
                continue;
            }
            $files = @scandir($backup_dir);
            if ($files === false) {
                continue;
            }
            foreach ($files as $file) {
                if ($file === '.' || $file === '..' || $file === '.htaccess' || $file === 'index.html') {
                    continue;
                }
                if (strpos($file, '_temp') !== false) {
                    continue;
                }
                $full_path = $backup_dir . $file;
                if (!is_file($full_path)) {
                    continue;
                }
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if ($ext === 'sql') {
                    if (class_exists('Sentinel_Backup_DB')) {
                        $backup_db = new Sentinel_Backup_DB();
                        $zip_res = $backup_db->compress_sql_to_zip($full_path);
                        if ($zip_res['success']) {
                            $file = $zip_res['zip_name'];
                            $full_path = $zip_res['zip_path'];
                            $ext = 'zip';
                        }
                    }
                }
                if (in_array($ext, array('zip', 'sql', 'tar', 'gz'))) {
                    // Inferir el tipo de backup desde el nombre del archivo
                    $bk_type = 'full';
                    if (strpos($file, 'backup_db_') !== false || strpos($file, '_db_') !== false || $ext === 'sql') {
                        $bk_type = 'db';
                    } elseif (strpos($file, 'backup_files_') !== false || strpos($file, '_files_') !== false) {
                        $bk_type = 'files';
                    }
                    $file_size = @filesize($full_path);
                    $backups[] = array(
                        'filename'       => $file,
                        'file_name'      => $file,
                        'size'           => $file_size,
                        'formatted_size' => size_format($file_size),
                        'date'           => date('Y-m-d H:i:s', @filemtime($full_path)),
                        'type'           => $bk_type,
                        'is_wpvivid'     => false
                    );
                }
            }
        }
        return $backups;
    }

    /**
     * Calcula el tamaño total de una carpeta de forma recursiva
     */
    private function get_dir_size($path) {
        $size = 0;
        $path = rtrim($path, '/\\') . '/';
        if (is_dir($path)) {
            $files = @scandir($path);
            if ($files !== false) {
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..') {
                        $full_path = $path . $file;
                        if (is_dir($full_path)) {
                            $size += $this->get_dir_size($full_path);
                        } else {
                            if (file_exists($full_path)) {
                                $size += @filesize($full_path);
                            }
                        }
                    }
                }
            }
        }
        return $size;
    }

    /**
     * Escanea la ruta buscando archivos pesados (>15MB) de extensiones de backup
     */
    private function scan_large_files($path, $min_size) {
        $large_files = array();
        if (!is_dir($path)) {
            return $large_files;
        }
        $start_time = time();
        $max_duration = 45; // Límite extendido para sitios grandes (>2GB)
        $memory_limit_bytes = $this->get_memory_limit_bytes();

        try {
            $flags = RecursiveDirectoryIterator::SKIP_DOTS;
            if (defined('FilesystemIterator::UNFOLLOW_SYMLINKS')) {
                $flags |= FilesystemIterator::UNFOLLOW_SYMLINKS;
            }
            $directory = new RecursiveDirectoryIterator($path, $flags);
            $iterator = new RecursiveIteratorIterator($directory, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

            foreach ($iterator as $item) {
                // Chequear límite de tiempo en cada ciclo para salir si se demora
                if ((time() - $start_time) > $max_duration) {
                    break;
                }
                
                // Abortar si se consume más del 80% de la memoria disponible
                if ($memory_limit_bytes > 0 && memory_get_usage(true) > ($memory_limit_bytes * 0.8)) {
                    break;
                }
                
                try {
                    if ($item->isFile()) {
                        $file_size = @$item->getSize();
                        if ($file_size >= $min_size) {
                            $ext = strtolower(pathinfo($item->getFilename(), PATHINFO_EXTENSION));
                            if (in_array($ext, array('zip', 'tar', 'gz', 'sql', 'log', 'bak', 'rar'))) {
                                $large_files[] = array(
                                    'path' => str_replace(wp_normalize_path(ABSPATH), '', wp_normalize_path($item->getPathname())),
                                    'size' => $file_size,
                                    'formatted_size' => size_format($file_size)
                                );
                            }
                        }
                    }
                } catch (\Throwable $inner_ex) {
                    // Ignorar fallos de permisos en archivos individuales
                }
            }
        } catch (\Throwable $e) {
            // Ignorar errores generales (permisos, symlinks rotos, etc.)
        }
        return $large_files;
    }

    /**
     * Convierte el memory_limit de PHP a bytes para control de uso de memoria
     */
    private function get_memory_limit_bytes() {
        $limit = ini_get('memory_limit');
        if ($limit === '-1') {
            return 0; // Sin límite
        }
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit) - 1]);
        $value = intval($limit);
        switch ($last) {
            case 'g': $value *= 1024;
            case 'm': $value *= 1024;
            case 'k': $value *= 1024;
        }
        return $value;
    }

    /**
     * Inicia el volcado de base de datos
     */
    public function trigger_backup_db($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup();
    }

    /**
     * Inicia el backup de archivos
     */
    public function trigger_backup_incremental($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }

        // Obtener parámetros
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 500;

        // Obtener tipo de backup solicitado (auto, full, incremental)
        $type = 'auto';
        if (isset($params['type'])) {
            $type = sanitize_text_field($params['type']);
        }
        
        $excluded_files = array();
        if (is_a($request, 'WP_REST_Request')) {
            $body = $request->get_json_params();
            if (isset($body['excluded_files']) && is_array($body['excluded_files'])) {
                $excluded_files = array_map('sanitize_text_field', $body['excluded_files']);
            }
            if (isset($body['type'])) {
                $type = sanitize_text_field($body['type']);
            }
        } elseif (isset($_REQUEST['excluded_files'])) {
            $raw = $_REQUEST['excluded_files'];
            if (is_string($raw)) {
                $decoded = json_decode(stripslashes($raw), true);
                if (is_array($decoded)) {
                    $excluded_files = array_map('sanitize_text_field', $decoded);
                }
            } elseif (is_array($raw)) {
                $excluded_files = array_map('sanitize_text_field', $raw);
            }
        }
        if (isset($_REQUEST['type'])) {
            $type = sanitize_text_field($_REQUEST['type']);
        }
        
        $format = 'zip';
        if (is_a($request, 'WP_REST_Request')) {
            $body = $request->get_json_params();
            if (isset($body['format'])) {
                $format = sanitize_text_field($body['format']);
            }
        } elseif (isset($_REQUEST['format'])) {
            $format = sanitize_text_field($_REQUEST['format']);
        }

        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->run_backup($offset, $limit, $type, $excluded_files, $format);
    }

    public function trigger_update_plugin($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $plugin_file = isset($params['plugin_file']) ? sanitize_text_field($params['plugin_file']) : '';

        if (empty($plugin_file)) {
            return array('success' => false, 'message' => 'Especifica un archivo de plugin.');
        }

        $updater = new Sentinel_Updater();
        return $updater->update_plugin($plugin_file);
    }

    /**
     * Inicia la actualización de un tema
     */
    public function trigger_update_theme($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $theme_slug = isset($params['theme_slug']) ? sanitize_text_field($params['theme_slug']) : '';

        if (empty($theme_slug)) {
            return array('success' => false, 'message' => 'Especifica un slug de tema.');
        }

        $updater = new Sentinel_Updater();
        return $updater->update_theme($theme_slug);
    }

    /**
     * Inicia la actualización de WordPress Core
     */
    public function trigger_update_core($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $updater = new Sentinel_Updater();
        return $updater->update_core();
    }

    /**
     * Inicia la restauración del sitio
     */
    public function trigger_restore($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        
        $action = isset($params['action']) ? sanitize_text_field($params['action']) : '';
        $updater = new Sentinel_Updater();

        if ($action === 'restore_rp') {
            $files_baseline = isset($params['files_baseline']) ? sanitize_text_field($params['files_baseline']) : '';
            $files_deltas = isset($params['files_deltas']) ? $params['files_deltas'] : array();
            $database_file = isset($params['database_file']) ? sanitize_text_field($params['database_file']) : '';

            $logs = array();

            // 1. Restaurar archivos baseline
            if (!empty($files_baseline)) {
                $res = $updater->restore_backup($files_baseline);
                if (!$res['success']) {
                    return array('success' => false, 'message' => 'Fallo al restaurar archivos baseline: ' . $res['message']);
                }
                $logs[] = 'Archivos baseline restaurados con éxito.';
            }

            // 2. Restaurar deltas (si existen)
            if (is_array($files_deltas) && !empty($files_deltas)) {
                foreach ($files_deltas as $delta) {
                    $delta_clean = sanitize_text_field($delta);
                    if (!empty($delta_clean)) {
                        $res = $updater->restore_backup($delta_clean);
                        if (!$res['success']) {
                            return array('success' => false, 'message' => 'Fallo al restaurar delta ' . $delta_clean . ': ' . $res['message']);
                        }
                        $logs[] = 'Delta ' . $delta_clean . ' restaurado con éxito.';
                    }
                }
            }

            // 3. Restaurar base de datos
            if (!empty($database_file)) {
                $res = $updater->restore_backup($database_file);
                if (!$res['success']) {
                    return array('success' => false, 'message' => 'Fallo al restaurar base de datos: ' . $res['message']);
                }
                $logs[] = 'Base de datos restaurada con éxito.';
            }

            return array(
                'success' => true,
                'message' => 'Recovery Point restaurado con éxito: ' . implode(' | ', $logs)
            );
        }

        $backup_name = isset($params['backup_name']) ? sanitize_text_field($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Especifica el nombre del backup para restaurar.');
        }

        return $updater->restore_backup($backup_name);
    }

    /**
     * Sube un archivo de backup manual al servidor
     */
    public function upload_backup_file($request = null) {
        if (empty($_FILES['backup_file'])) {
            return new WP_Error('no_file', 'No se ha subido ningún archivo.', array('status' => 400));
        }

        $file = $_FILES['backup_file'];
        
        // Validar extensión
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($extension !== 'zip' && $extension !== 'sql') {
            return new WP_Error('invalid_file_type', 'Tipo de archivo no permitido. Solo se permiten archivos .zip o .sql.', array('status' => 400));
        }

        $uploads = wp_upload_dir();
        $backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';

        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }

        $dest_filename = sanitize_file_name($file['name']);
        $dest_path = $backup_dir . $dest_filename;

        if (move_uploaded_file($file['tmp_name'], $dest_path)) {
            return array(
                'success' => true,
                'message' => 'Archivo de respaldo subido con éxito.',
                'file_name' => $dest_filename
            );
        }

        return new WP_Error('upload_error', 'Fallo al mover el archivo subido al directorio de backups.', array('status' => 500));
    }

    /**
     * Descarga de forma segura un archivo de backup
     */
    public function download_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $raw_file = isset($params['file']) ? trim($params['file']) : '';

        if (empty($raw_file)) {
            return new WP_Error('sentinel_bad_request', 'Especifica un nombre de archivo.', array('status' => 400));
        }

        // Validación de seguridad por expresión regular (evitar path traversal)
        if (!preg_match('/^[a-zA-Z0-9_\-\.]+\.(zip|tar|gz|sql|tmp)$/', $raw_file)) {
            return new WP_Error('sentinel_bad_request', 'Nombre de archivo no válido o caracteres sospechosos detectados.', array('status' => 400));
        }
        $file = $raw_file;

        $uploads = wp_upload_dir();
        $base_backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        
        // Enrutar al subdirectorio correspondiente según el patrón del nombre
        $wpvivid_base_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';
        if (strpos($file, 'backup_db_') !== false || strpos($file, '_db_') !== false) {
            $backup_dir = $base_backup_dir . 'db/';
        } elseif (strpos($file, 'backup_files_') !== false || strpos($file, '_files_') !== false) {
            $backup_dir = $base_backup_dir . 'files/';
        } else {
            $backup_dir = $base_backup_dir;
        }
        
        $file_path = $backup_dir . $file;

        if (!file_exists($file_path) || !is_readable($file_path)) {
            // Fallback 1: Si piden un .sql plano pero ya fue comprimido
            if (pathinfo($file, PATHINFO_EXTENSION) === 'sql' && file_exists($file_path . '.zip') && is_readable($file_path . '.zip')) {
                $file = $file . '.zip';
                $file_path = $file_path . '.zip';
            } else {
                // Fallback 2: Buscar recursivamente en wpvividbackups/ (backups WPvivid no siguen patron Sentinel)
                $wpvivid_found = $this->find_file_recursive($wpvivid_base_dir, $file);
                if ($wpvivid_found) {
                    $file_path = $wpvivid_found;
                } else {
                    return new WP_Error('sentinel_not_found', 'El archivo no existe o no se puede leer.', array('status' => 404));
                }
            }
        }

        $file_size = filesize($file_path);
        $fp = @fopen($file_path, 'rb');
        if (!$fp) {
            return new WP_Error('sentinel_server_error', 'No se pudo abrir el archivo para lectura.', array('status' => 500));
        }

        // Limpiar buffers previos de salida
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Parámetros de descarga parcial (HTTP Range)
        $start = 0;
        $end = $file_size - 1;

        if (isset($_SERVER['HTTP_RANGE'])) {
            if (preg_match('/bytes=\s*(\d+)-(\d*)/i', $_SERVER['HTTP_RANGE'], $matches)) {
                $start = intval($matches[1]);
                if (!empty($matches[2])) {
                    $end = intval($matches[2]);
                }
            }
        }

        if ($start > 0 || $end < ($file_size - 1)) {
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes $start-$end/$file_size");
        } else {
            header('HTTP/1.1 200 OK');
        }

        // Cabeceras estándares de descarga
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Accept-Ranges: bytes');
        
        // Evitar md5_file en caliente para prevenir timeouts por I/O limits en archivos grandes
        header('X-Sentinel-File-Hash: ');

        $content_length = $end - $start + 1;
        header('Content-Length: ' . $content_length);

        // Mover puntero al byte de inicio solicitado
        fseek($fp, $start);

        $chunk_size = 8192; // 8 KB chunks
        $bytes_sent = 0;

        while (!feof($fp) && $bytes_sent < $content_length && (connection_status() == 0)) {
            $to_read = min($chunk_size, $content_length - $bytes_sent);
            $buffer = fread($fp, $to_read);
            echo $buffer;
            flush();
            
            $bytes_sent += strlen($buffer);
        }

        fclose($fp);
        exit;
    }

    /**
     * Elimina un archivo de copia de seguridad del hosting
     */
    public function delete_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $raw_file = isset($params['file']) ? trim($params['file']) : '';

        if (empty($raw_file)) {
            return array('success' => false, 'message' => 'Especifica un nombre de archivo.');
        }

        // Validación de seguridad por expresión regular (evitar path traversal y preservar extensión)
        if (!preg_match('/^[a-zA-Z0-9_\-\.]+\.(zip|tar|gz|sql|tmp)$/', $raw_file)) {
            return array('success' => false, 'message' => 'Nombre de archivo no válido o caracteres sospechosos detectados.');
        }
        $file = $raw_file;

        $uploads = wp_upload_dir();
        $base_backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        $wpvivid_base_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';

        // Determinar directorios de búsqueda: primero verificar si es archivo WPvivid
        if (is_dir($wpvivid_base_dir) && $this->find_file_recursive($wpvivid_base_dir, $file)) {
            $search_dirs = array($wpvivid_base_dir);
        } elseif (strpos($file, 'backup_db_') !== false || strpos($file, '_db_') !== false) {
            $search_dirs = array($base_backup_dir . 'db/', $base_backup_dir);
        } elseif (strpos($file, 'backup_files_') !== false || strpos($file, '_files_') !== false) {
            $search_dirs = array($base_backup_dir . 'files/', $base_backup_dir);
        } else {
            $search_dirs = array($base_backup_dir);
        }

        foreach ($search_dirs as $backup_dir) {
            // Buscar también en subdirectorios de WPvivid
            if ($backup_dir === $wpvivid_base_dir) {
                $found_path = $this->find_file_recursive($wpvivid_base_dir, $file);
                if ($found_path) {
                    if (unlink($found_path)) {
                        return array('success' => true, 'message' => 'Copia de seguridad WPvivid eliminada del hosting.');
                    }
                    return array('success' => false, 'message' => 'No se pudo eliminar el archivo físico de WPvivid.');
                }
                continue;
            }
            $file_path = $backup_dir . $file;
            if (file_exists($file_path) && is_file($file_path)) {
                if (unlink($file_path)) {
                    return array('success' => true, 'message' => 'Copia de seguridad remota eliminada del hosting.');
                }
                return array('success' => false, 'message' => 'No se pudo eliminar el archivo físico del hosting.');
            }
        }

        return array('success' => false, 'message' => 'El archivo no existe en el hosting remoto.');
    }

    /**
     * Dispara la auto-actualización del plugin Sentinel
     */
    public function trigger_self_update($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $zip_url = isset($params['zip_url']) ? esc_url_raw($params['zip_url']) : '';

        if (empty($zip_url)) {
            return array('success' => false, 'message' => 'Especifica la URL del paquete zip de actualización.');
        }

        require_once plugin_dir_path(__FILE__) . 'class-updater.php';
        $updater = new Sentinel_Updater();
        
        if (method_exists($updater, 'self_update_plugin')) {
            return $updater->self_update_plugin($zip_url);
        }

        return array('success' => false, 'message' => 'El actualizador no soporta auto-actualización en esta versión.');
    }

    public function check_backup_db_support($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->check_environment_support();
    }

    public function trigger_backup_db_mysqldump($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup_mysqldump();
    }

    public function get_backup_db_status($request = null) {
        $task = get_option('sentinel_active_backup_task');
        if (empty($task)) {
            return array('success' => false, 'message' => 'No hay tareas activas de respaldo.');
        }

        if (isset($task['is_wpvivid']) && $task['is_wpvivid']) {
            if (class_exists('WPvivid_Public_Interface')) {
                $wpvivid = new WPvivid_Public_Interface();
                $wpvivid_status = $wpvivid->get_status();
                
                $wpvivid_task_id = $task['wpvivid_task_id'];
                
                if (isset($wpvivid_status['wpvivid']['task'][$wpvivid_task_id])) {
                    $wv_task = $wpvivid_status['wpvivid']['task'][$wpvivid_task_id];
                    $progress_str = isset($wv_task['task_info']['backup_percent']) ? $wv_task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $descript = isset($wv_task['task_info']['descript']) ? $wv_task['task_info']['descript'] : 'Procesando con WPVivid...';
                    
                    $task['progress'] = $progress;
                    $task['current_table'] = $descript;
                    $task['last_activity'] = time();
                    update_option('sentinel_active_backup_task', $task);
                } else {
                    $backup_list = isset($wpvivid_status['wpvivid']['backup_list']) ? $wpvivid_status['wpvivid']['backup_list'] : array();
                    if (isset($backup_list[$wpvivid_task_id])) {
                        $wv_backup = $backup_list[$wpvivid_task_id];
                        $files = isset($wv_backup['files']) ? $wv_backup['files'] : array();
                        
                        $backup_name = '';
                        if (!empty($files)) {
                            $first_file = reset($files);
                            $backup_name = isset($first_file['file_name']) ? $first_file['file_name'] : (is_string($first_file) ? $first_file : '');
                            if (empty($backup_name) && isset($first_file['name'])) {
                                $backup_name = $first_file['name'];
                            }
                        }
                        
                        if (empty($backup_name)) {
                            $backup_name = $wpvivid_task_id . '_db.zip';
                        }
                        
                        $task['status'] = 'completed';
                        $task['progress'] = 100;
                        $task['backup_name'] = $backup_name;
                        $task['current_table'] = 'Finalizado con WPVivid';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_backup_task', $task);
                    } else {
                        $task['status'] = 'failed';
                        $task['current_table'] = 'La tarea de WPVivid no se encontró o falló.';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_backup_task', $task);
                    }
                }
            } else {
                $task['status'] = 'failed';
                $task['current_table'] = 'Plugin WPVivid desactivado inesperadamente.';
                update_option('sentinel_active_backup_task', $task);
            }
        }

        return array('success' => true, 'task' => $task);
    }

    public function trigger_backup_db_chunk_start($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->start_chunk_backup();
    }

    public function trigger_backup_db_chunk_step($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $table = isset($params['table']) ? sanitize_text_field($params['table']) : '';
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 1000;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';
        $write_structure = isset($params['write_structure']) ? (bool)$params['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure);
    }

    public function trigger_backup_db_chunk_finish($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetro "backup_name" requerido.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->finish_chunk_backup($backup_name);
    }

    public function trigger_backup_db_async_start($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->start_async_backup();
    }

    public function trigger_backup_db_async_step($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->process_async_backup_step();
    }

    public function get_file_exclusions($request = null) {
        $exclusions = get_option('sentinel_excluded_files', array());
        if (!is_array($exclusions)) {
            $exclusions = array();
        }
        return array('success' => true, 'exclusions' => $exclusions);
    }

    public function update_file_exclusions($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        
        $exclusions = array();
        if (isset($params['exclusions'])) {
            $raw_exclusions = $params['exclusions'];
            if (is_array($raw_exclusions)) {
                $exclusions = array_map('sanitize_text_field', $raw_exclusions);
            } elseif (is_string($raw_exclusions)) {
                $decoded = json_decode(stripslashes($raw_exclusions), true);
                if (is_array($decoded)) {
                    $exclusions = array_map('sanitize_text_field', $decoded);
                }
            }
        }
        
        update_option('sentinel_excluded_files', $exclusions);
        return array('success' => true, 'message' => 'Exclusiones guardadas correctamente.', 'exclusions' => $exclusions);
    }

    public function trigger_backup_files_async_start($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $type = isset($params['type']) ? sanitize_text_field($params['type']) : 'auto';
        $format = isset($params['format']) ? sanitize_text_field($params['format']) : 'zip';
        $exclusions = isset($params['exclusions']) ? (array)$params['exclusions'] : array();

        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->start_async_backup($type, $exclusions, $format);
    }

    public function trigger_backup_files_async_step($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }
        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->process_async_backup_step();
    }

    public function get_backup_files_status($request = null) {
        $task = get_option('sentinel_active_files_backup_task');
        if (!$task) {
            return array('success' => true, 'task' => array('status' => 'idle', 'progress' => 0));
        }

        if (isset($task['is_wpvivid']) && $task['is_wpvivid']) {
            if (class_exists('WPvivid_Public_Interface')) {
                $wpvivid = new WPvivid_Public_Interface();
                $wpvivid_status = $wpvivid->get_status();
                
                $wpvivid_task_id = $task['wpvivid_task_id'];
                
                if (isset($wpvivid_status['wpvivid']['task'][$wpvivid_task_id])) {
                    $wv_task = $wpvivid_status['wpvivid']['task'][$wpvivid_task_id];
                    $progress_str = isset($wv_task['task_info']['backup_percent']) ? $wv_task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $descript = isset($wv_task['task_info']['descript']) ? $wv_task['task_info']['descript'] : 'Procesando con WPVivid...';
                    
                    $task['progress'] = $progress;
                    $task['current_file'] = $descript;
                    $task['last_activity'] = time();
                    update_option('sentinel_active_files_backup_task', $task);
                } else {
                    $backup_list = isset($wpvivid_status['wpvivid']['backup_list']) ? $wpvivid_status['wpvivid']['backup_list'] : array();
                    if (isset($backup_list[$wpvivid_task_id])) {
                        $wv_backup = $backup_list[$wpvivid_task_id];
                        $files = isset($wv_backup['files']) ? $wv_backup['files'] : array();
                        
                        $backup_name = '';
                        if (!empty($files)) {
                            $first_file = reset($files);
                            $backup_name = isset($first_file['file_name']) ? $first_file['file_name'] : (is_string($first_file) ? $first_file : '');
                            if (empty($backup_name) && isset($first_file['name'])) {
                                $backup_name = $first_file['name'];
                            }
                        }
                        
                        if (empty($backup_name)) {
                            $backup_name = $wpvivid_task_id . '_full.zip';
                        }
                        
                        $task['status'] = 'completed';
                        $task['progress'] = 100;
                        $task['backup_name'] = $backup_name;
                        $task['current_file'] = 'Finalizado con WPVivid';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_files_backup_task', $task);
                    } else {
                        $task['status'] = 'failed';
                        $task['current_file'] = 'La tarea de WPVivid no se encontró o falló.';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_files_backup_task', $task);
                    }
                }
            } else {
                $task['status'] = 'failed';
                $task['current_file'] = 'Plugin WPVivid desactivado inesperadamente.';
                update_option('sentinel_active_files_backup_task', $task);
            }
        }

        return array('success' => true, 'task' => $task);
    }

    public function reset_backups_status() {
        delete_option('sentinel_active_backup_task');
        delete_option('sentinel_active_files_backup_task');

        $upload_dir = wp_upload_dir();
        $sentinel_dir = $upload_dir['basedir'] . '/sentinel/';
        
        $db_lock = $sentinel_dir . 'db/db_backup.lock';
        $files_lock = $sentinel_dir . 'tmp/files_backup.lock';

        if (file_exists($db_lock)) {
            @unlink($db_lock);
        }
        if (file_exists($files_lock)) {
            @unlink($files_lock);
        }

        return array('success' => true, 'message' => 'Locks y tareas limpiadas de forma absoluta.');
    }

    public function get_wpvivid_status($request = null) {
        $installed = false;
        $active = false;
        $version = '';

        // 1. Comprobar en active_plugins
        $active_plugins = get_option('active_plugins', array());
        foreach ($active_plugins as $plugin_file) {
            if (strpos($plugin_file, 'wpvivid') !== false) {
                $installed = true;
                $active = true;
                break;
            }
        }

        // 2. Comprobar mediante clases/constantes
        if (!$active) {
            if (class_exists('WPvivid_Plugin') || class_exists('WPvivid_Public_Interface') || defined('WPVIVID_PLUGIN_VERSION') || class_exists('WPvivid')) {
                $active = true;
                $installed = true;
                $version = defined('WPVIVID_PLUGIN_VERSION') ? WPVIVID_PLUGIN_VERSION : '';
            }
        } else {
            if (defined('WPVIVID_PLUGIN_VERSION')) {
                $version = WPVIVID_PLUGIN_VERSION;
            }
        }

        // 3. Fallback de búsqueda en plugins instalados
        if (!$installed || empty($version)) {
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $plugins = get_plugins();
            foreach ($plugins as $file => $data) {
                if (strpos($file, 'wpvivid-backuprestore') !== false) {
                    $installed = true;
                    $version = isset($data['Version']) ? $data['Version'] : '';
                    if (is_plugin_active($file)) {
                        $active = true;
                    }
                    break;
                }
            }
        }

        return array(
            'success'   => true,
            'installed' => $installed,
            'active'    => $active,
            'version'   => $version
        );
    }

    public function trigger_wpvivid_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $type = isset($params['type']) ? sanitize_text_field($params['type']) : 'full';

        $backup_files = ($type === 'db') ? 'db' : 'files+db';

        $data = array('backup' => array(
            'backup_files' => $backup_files,
            'local' => '1',
            'remote' => '0',
            'type' => 'Manual'
        ));

        $ret = apply_filters('wpvivid_prepare_backup_mainwp', $data);

        // Si el filtro retornó el mismo array (indicando que WPvivid no está cargado o activo)
        if ($ret === $data || !has_filter('wpvivid_prepare_backup_mainwp')) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'El plugin WPvivid no está activo o no está inicializado correctamente en este sitio.',
                'response' => $ret
            ), 400);
        }

        if (is_array($ret) && isset($ret['task_id'])) {
            $task_id = $ret['task_id'];
            $now_ret = apply_filters('wpvivid_backup_now_mainwp', array('task_id' => $task_id));
            
            // Seleccionar la opción y nombre correcto según el tipo de backup solicitado
            $backup_name_suffix = ($type === 'db') ? '_db.zip' : '_full.zip';
            $task_option_key    = ($type === 'db') ? 'sentinel_active_backup_task' : 'sentinel_active_files_backup_task';
            $task = array(
                'status'          => 'running',
                'progress'        => 0,
                'is_wpvivid'      => true,
                'wpvivid_task_id' => $task_id,
                'backup_name'     => $task_id . $backup_name_suffix,
                'current_file'    => 'Preparando con WPVivid...',
                'last_activity'   => time()
            );
            update_option($task_option_key, $task);

            return array(
                'success' => true,
                'task_id' => $task_id,
                'status'  => 'running',
                'response' => $ret,
                'now_response' => $now_ret
            );
        } else {
            $error_message = isset($ret['error']) ? $ret['error'] : 'Error preparando el backup de WPvivid.';
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $error_message,
                'response' => $ret
            ), 500);
        }
    }

    public function get_wpvivid_backup_status($request = null) {
        $ret = apply_filters('wpvivid_get_status_mainwp', array());
        
        $active_tasks = array();
        if (isset($ret['wpvivid']['task']) && is_array($ret['wpvivid']['task'])) {
            foreach ($ret['wpvivid']['task'] as $id => $task) {
                $progress = 0;
                $status = 'running';
                $descript = '';
                
                if (isset($task['task_info'])) {
                    $progress_str = isset($task['task_info']['backup_percent']) ? $task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $status = isset($task['task_info']['status']) ? $task['task_info']['status'] : 'running';
                    $descript = isset($task['task_info']['descript']) ? $task['task_info']['descript'] : '';
                }
                
                $active_tasks[] = array(
                    'task_id'      => $id,
                    'status'       => $status,
                    'progress'     => $progress,
                    'description'  => $descript,
                    'raw_task'     => $task
                );
            }
        }
        
        return array(
            'success' => true,
            'active_tasks' => $active_tasks,
            'raw_status' => $ret
        );
    }

    public function get_wpvivid_backups($request = null) {
        $ret = apply_filters('wpvivid_get_backup_list_mainwp', array());
        
        $backup_list = array();
        if (isset($ret['wpvivid']['backup_list']) && is_array($ret['wpvivid']['backup_list'])) {
            $backup_list = $ret['wpvivid']['backup_list'];
        } else {
            // Fallback: Leer directamente de la base de datos de WordPress la lista de backups nativa de WPvivid
            $native_list = get_option('wpvivid_backup_list', array());
            if (is_array($native_list)) {
                $backup_list = $native_list;
            }
        }
        
        $formatted = array();
        if (!empty($backup_list) && is_array($backup_list)) {
            foreach ($backup_list as $id => $backup) {
                $date = isset($backup['create_time']) ? date('Y-m-d H:i:s', $backup['create_time']) : '';
                
                $filename = $id;
                $size = 0;
                
                if (isset($backup['backup']['files']) && is_array($backup['backup']['files'])) {
                    $files_info = array();
                    foreach ($backup['backup']['files'] as $file) {
                        if (is_array($file)) {
                            // Soportar tanto 'name' como 'file_name' (varía según versión de WPvivid)
                            $fname = isset($file['file_name']) ? $file['file_name'] : (isset($file['name']) ? $file['name'] : '');
                            $files_info[] = $fname;
                            if (isset($file['size'])) {
                                $size += intval($file['size']);
                            }
                        } else {
                            $files_info[] = $file;
                        }
                    }
                    if (!empty($files_info)) {
                        $filename = implode(', ', $files_info);
                    }
                }
                
                if ($size === 0 && isset($backup['local']['path'])) {
                    $path = rtrim($backup['local']['path'], '/\\') . DIRECTORY_SEPARATOR;
                    if (isset($backup['backup']['files']) && is_array($backup['backup']['files'])) {
                        foreach ($backup['backup']['files'] as $file) {
                            $fname = is_array($file) ? (isset($file['name']) ? $file['name'] : '') : $file;
                            if (!empty($fname) && file_exists($path . $fname)) {
                                $size += @filesize($path . $fname);
                            }
                        }
                    }
                }
                
                // Normalizar tipo de backup desde la estructura de WPvivid
                $wv_type_raw = isset($backup['backup']['type']) ? $backup['backup']['type'] : (isset($backup['type']) ? $backup['type'] : 'unknown');
                // Intentar inferir tipo si es 'unknown' desde los nombres de archivo
                if ($wv_type_raw === 'unknown' && !empty($filename)) {
                    if (strpos($filename, '_db') !== false || strpos($filename, 'database') !== false) {
                        $wv_type_raw = 'db';
                    } elseif (strpos($filename, '_full') !== false || strpos($filename, 'complete') !== false) {
                        $wv_type_raw = 'full';
                    } elseif (strpos($filename, '_files') !== false) {
                        $wv_type_raw = 'files';
                    }
                }
                $formatted[] = array(
                    'id'             => $id,
                    'filename'       => $filename,
                    'file_name'      => $filename,
                    'size'           => $size,
                    'formatted_size' => size_format($size),
                    'date'           => $date,
                    'type'           => $wv_type_raw,
                    'is_wpvivid'     => true,
                    'wpvivid_id'     => $id
                );
            }
        }
        
        // Fallback 3: Si no se encontraron backups vía API ni DB, escanear directorio físico
        if (empty($formatted)) {
            $wpvivid_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';
            if (is_dir($wpvivid_dir)) {
                $scanned = $this->scan_wpvivid_physical_dir($wpvivid_dir);
                $formatted = array_merge($formatted, $scanned);
            }
        }
        
        return array('success' => true, 'backups' => $formatted);
    }

    /**
     * Busca un archivo de forma recursiva en un directorio dado.
     * Retorna la ruta absoluta del archivo si lo encuentra, o false si no.
     */
    private function find_file_recursive($dir, $filename) {
        $dir = trailingslashit($dir);
        if (!is_dir($dir)) return false;
        $direct_path = $dir . $filename;
        if (file_exists($direct_path) && is_file($direct_path)) {
            return $direct_path;
        }
        $entries = @scandir($dir);
        if (!$entries) return false;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $full_path = $dir . $entry;
            if (is_dir($full_path)) {
                $found = $this->find_file_recursive($full_path, $filename);
                if ($found) return $found;
            }
        }
        return false;
    }

    /**
     * Escanea físicamente el directorio wpvividbackups/ y retorna una lista de backups
     * para usar como fallback cuando la DB de WPvivid no tiene registros.
     */
    private function scan_wpvivid_physical_dir($wpvivid_dir) {
        $result   = array();
        $wpvivid_dir = trailingslashit($wpvivid_dir);
        $entries = @scandir($wpvivid_dir);
        if (!$entries) return $result;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $entry_path = $wpvivid_dir . $entry;
            $files_to_check = array();
            if (is_dir($entry_path)) {
                // Subdirectorio de tarea WPvivid: buscar archivos .zip dentro
                $sub_entries = @scandir($entry_path . DIRECTORY_SEPARATOR);
                if ($sub_entries) {
                    foreach ($sub_entries as $sub) {
                        if ($sub !== '.' && $sub !== '..' && is_file($entry_path . DIRECTORY_SEPARATOR . $sub)) {
                            $files_to_check[] = array('path' => $entry_path . DIRECTORY_SEPARATOR . $sub, 'name' => $sub, 'task_id' => $entry);
                        }
                    }
                }
            } elseif (is_file($entry_path)) {
                $files_to_check[] = array('path' => $entry_path, 'name' => $entry, 'task_id' => $entry);
            }
            foreach ($files_to_check as $finfo) {
                $ext = strtolower(pathinfo($finfo['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, array('zip', 'sql', 'tar', 'gz'))) continue;
                $file_size = @filesize($finfo['path']);
                $file_mtime = @filemtime($finfo['path']);
                // Inferir tipo desde el nombre del archivo
                $bk_type = 'full';
                if (strpos($finfo['name'], '_db') !== false || strpos($finfo['name'], 'database') !== false || $ext === 'sql') {
                    $bk_type = 'db';
                } elseif (strpos($finfo['name'], '_files') !== false) {
                    $bk_type = 'files';
                }
                $result[] = array(
                    'id'             => $finfo['task_id'],
                    'filename'       => $finfo['name'],
                    'file_name'      => $finfo['name'],
                    'size'           => $file_size,
                    'formatted_size' => size_format($file_size),
                    'date'           => $file_mtime ? date('Y-m-d H:i:s', $file_mtime) : '',
                    'type'           => $bk_type,
                    'is_wpvivid'     => true,
                    'wpvivid_id'     => $finfo['task_id'],
                    'source'         => 'physical_scan'
                );
            }
        }
        return $result;
    }

    public function delete_wpvivid_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $backup_id = isset($params['backup_id']) ? sanitize_text_field($params['backup_id']) : '';

        if (empty($backup_id)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Parámetro backup_id requerido.'), 400);
        }

        $ret = apply_filters('wpvivid_delete_backup_mainwp', array('backup_id' => $backup_id));

        return array(
            'success' => isset($ret['result']) && $ret['result'] === 'success',
            'response' => $ret
        );
    }
}