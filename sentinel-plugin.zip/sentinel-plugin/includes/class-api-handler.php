<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Sentinel_API_Handler {

    private static $instance = null;
    private $namespace = 'controlcenter/v1';
    private $agent_secret;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->agent_secret = get_option('controlcenter_agent_secret');
        add_action('rest_api_init', array($this, 'register_routes'));
        add_filter('rest_pre_dispatch', array($this, 'decode_masked_payload'), 10, 3);
    }

    /**
     * ANTI-MODSECURITY: Decode payload masked as Base64 Form-Data.
     * Sentinel Backend ahora envia los JSON camuflados en form-data base64 para evitar firewalls.
     */
    public function decode_masked_payload($result, $server, $request) {
        $route = $request->get_route();
        // Solo actuar en rutas del plugin
        if (strpos($route, '/controlcenter/') === false && strpos($route, '/sentinel/') === false) {
            return $result;
        }

        // Si la request trae un "payload" (en form-data o URL), lo decodificamos
        $masked_payload = $request->get_param('payload');
        if (!empty($masked_payload)) {
            $json_str = base64_decode($masked_payload);
            if ($json_str !== false) {
                $decoded_params = json_decode($json_str, true);
                if (is_array($decoded_params)) {
                    // Inyectar los parametros decodificados en el Request
                    $request->set_body_params(array_merge($request->get_body_params(), $decoded_params));
                }
            }
        }
        return $result;
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/site-info', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_site_info'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/build-index', array(
            'methods' => 'POST',
            'callback' => array($this, 'build_index'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/index-status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_index_status'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/changes', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_changes'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-analyze', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_db_analyze'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-classify', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_db_classify'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/db-snapshot', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_db_snapshot'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-classify', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_files_classify'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-scan-malware', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_files_scan_malware'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/files-snapshot', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_files_snapshot'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/components', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_components'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/component-fingerprint', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_component_fingerprint'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/component-overlays', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_component_overlays'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/file/delete-physical', array(
            'methods' => 'POST',
            'callback' => array($this, 'delete_physical_file'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/file/download-physical', array(
            'methods' => 'POST',
            'callback' => array($this, 'download_physical_file'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/database/truncate-table', array(
            'methods' => 'POST',
            'callback' => array($this, 'truncate_database_table'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/database/transients/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_transients_status'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/execute-job', array(
            'methods' => 'POST',
            'callback' => array($this, 'execute_job'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/validate', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_validate'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/files', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_files'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/db', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_db'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/commit', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_commit'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        register_rest_route($this->namespace, '/restore/rollback', array(
            'methods' => 'POST',
            'callback' => array($this, 'post_restore_rollback'),
            'permission_callback' => array($this, 'authenticate_request')
        ));

        $ns_v1 = 'sentinel/v1';

        register_rest_route($ns_v1, '/file/delete-physical', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_physical_file'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_wpvivid_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_backup_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backups', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_wpvivid_backups'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/wpvivid/backup/delete', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_wpvivid_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/check', array(
            'methods'  => 'GET',
            'callback' => array($this, 'check_backup_db_support'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/mysqldump', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_mysqldump'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_backup_db_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/reset', array(
            'methods'  => 'POST',
            'callback' => array($this, 'reset_backups_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/chunk/finish', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_chunk_finish'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/async/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_async_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/db/async/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_db_async_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/async/start', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_files_async_start'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/async/step', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_files_async_step'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_backup_files_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/incremental', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_backup_incremental'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/exclusions', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_file_exclusions'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/files/exclusions', array(
            'methods'  => 'POST',
            'callback' => array($this, 'update_file_exclusions'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/plugin', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_plugin'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/theme', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_theme'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/core', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_update_core'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/restore', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_restore'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/restore/upload', array(
            'methods'  => 'POST',
            'callback' => array($this, 'upload_backup_file'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/download', array(
            'methods'  => 'GET',
            'callback' => array($this, 'download_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/backup/delete', array(
            'methods'  => 'POST',
            'callback' => array($this, 'delete_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/update/self', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_self_update'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_akeeba_status_endpoint'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/backup', array(
            'methods'  => 'POST',
            'callback' => array($this, 'trigger_akeeba_backup'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/backup/status', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_akeeba_backup_status'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/backups', array(
            'methods'  => 'GET',
            'callback' => array($this, 'get_akeeba_backups'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/backup/exclusions', array(
            'methods'  => 'POST',
            'callback' => array($this, 'update_akeeba_exclusions'),
            'permission_callback' => array($this, 'authenticate_request'),
        ));

        register_rest_route($ns_v1, '/akeeba/debug', array(
            'methods'  => 'GET',
            'callback' => array($this, 'debug_akeeba'),
            'permission_callback' => '__return_true', // Abierto temporalmente para debug
        ));
    }

    public function debug_akeeba() {
        global $wpdb;
        $table = $wpdb->prefix . 'ak_profiles';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        
        $profiles = [];
        $columns = [];
        $native_config_test = 'Failed to load Akeeba classes';
        
        if ($table_check === $table) {
            $profiles = $wpdb->get_results("SELECT * FROM `$table`", ARRAY_A);
            $columns = $wpdb->get_col("DESCRIBE `$table`");
            
            // Test loading using native Akeeba classes
            if (class_exists('AkeebaBackupWP') && method_exists('AkeebaBackupWP', 'loadAppConfig')) {
                try {
                    $method = new ReflectionMethod('AkeebaBackupWP', 'loadAppConfig');
                    $method->setAccessible(true);
                    $method->invoke(null);
                    
                    $container = \AkeebaBackupWP::loadAkeebaBackupContainer();
                    if ($container) {
                        $container->application->initialise();
                        if (class_exists('Akeeba\Engine\Util\Factory')) {
                            $secure_settings = \Akeeba\Engine\Util\Factory::getSecureSettings();
                            $profile1 = $wpdb->get_row("SELECT configuration FROM `$table` WHERE id = 1", ARRAY_A);
                            if ($profile1) {
                                $decrypted = $secure_settings->decryptSettings($profile1['configuration']);
                                $native_config_test = 'DECRYPTED_SUCCESS: ' . substr($decrypted, 0, 300);
                            }
                        } else {
                            $native_config_test = 'Akeeba\Engine\Util\Factory not found after init';
                        }
                    }
                } catch (\Exception $e) {
                    $native_config_test = 'Exception: ' . $e->getMessage();
                }
            }
        }

        $stats_table = $wpdb->prefix . 'ak_stats';
        $stats = $wpdb->get_results("SELECT id, description, status, type FROM `$stats_table` ORDER BY id DESC LIMIT 5", ARRAY_A);
        $last_error = get_option('sentinel_akeeba_last_error', '');

        return rest_ensure_response(array(
            'prefix' => $wpdb->prefix,
            'table_expected' => $table,
            'table_exists' => $table_check,
            'columns' => $columns,
            'profiles' => $profiles,
            'stats' => $stats,
            'last_error' => $last_error,
            'native_config_test' => $native_config_test
        ));
    }

    public function authenticate_request() {
        $agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? sanitize_text_field($_SERVER['HTTP_X_AGENT_ID']) : '';
        $timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
        $signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? sanitize_text_field($_SERVER['HTTP_X_SIGNATURE']) : '';

        // 1. Si están las cabeceras HMAC, validar firma
        if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
            $current_time = time();
            if (abs($current_time - $timestamp) > 300) { // 5 min tolerancia
                return false;
            }
            $data_to_sign = $agent_id . $timestamp;
            $expected_signature = hash_hmac('sha256', $data_to_sign, $this->agent_secret);
            return hash_equals($expected_signature, $signature);
        }

        // 2. Fallback: Validar con API Key (Bearer o X-Sentinel-API-Key)
        $client_key = '';
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
            if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
                $client_key = trim($matches[1]);
            }
        } elseif (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (isset($headers['Authorization'])) {
                if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                    $client_key = trim($matches[1]);
                }
            }
        }
        if (empty($client_key) && isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
            $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
        }
        if (empty($client_key) && isset($_REQUEST['sentinel_key'])) {
            $client_key = trim($_REQUEST['sentinel_key']);
        }

        return !empty($client_key) && hash_equals($this->agent_secret, $client_key);
    }

    public function get_site_info() {
        return Sentinel_Collector::get_instance()->collect_all();
    }

    public function build_index($request) {
        $limit = isset($request['limit']) ? absint($request['limit']) : 500;
        $status = Sentinel_Indexer::get_instance()->build_index($limit);

        $db = Sentinel_SQLite_DB::get_instance();
        $queue_count_res = $db->query_files("SELECT COUNT(*) as count FROM scan_queue");
        $scan_queue = !empty($queue_count_res) ? (int)$queue_count_res[0]['count'] : 0;

        return array(
            'status'     => $status,
            'scan_queue' => $scan_queue
        );
    }

    public function get_index_status() {
        return Sentinel_Indexer::get_instance()->get_scan_status();
    }

    public function get_changes() {
        return Sentinel_Indexer::get_instance()->get_detected_changes();
    }

    public function get_db_analyze() {
        return Sentinel_DB_Analyzer::get_instance()->analyze_database();
    }

    public function get_db_classify() {
        return Sentinel_Classification_Engine::get_instance()->classify_all_tables();
    }

    public function post_db_snapshot($request) {
        $table = isset($request['table']) ? sanitize_text_field($request['table']) : '';
        $chunk_size = isset($request['chunk_size']) ? absint($request['chunk_size']) : 1000;
        return Sentinel_Snapshot_Engine::get_instance()->create_table_snapshot($table, $chunk_size);
    }

    public function get_files_classify() {
        return Sentinel_File_Classification::get_instance()->classify_all_files();
    }

    public function post_files_scan_malware($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        if (!empty($path)) {
            return Sentinel_Malware_Scanner::get_instance()->scan_file($path);
        } else {
            return Sentinel_Malware_Scanner::get_instance()->scan_files_with_status(array('NEW', 'MODIFIED'));
        }
    }

    public function get_files_snapshot($request) {
        $classification = isset($request['classification']) ? sanitize_text_field($request['classification']) : '';
        $status = isset($request['status']) ? sanitize_text_field($request['status']) : '';
        return Sentinel_Snapshot_Engine::get_instance()->get_files_snapshot($classification, $status);
    }

    public function get_components() {
        return Sentinel_Component_Discovery::get_instance()->discover_components();
    }

    public function post_component_fingerprint($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        return Sentinel_Fingerprint_Generator::get_instance()->generate_fingerprint($path);
    }

    public function post_component_overlays($request) {
        $path = isset($request['path']) ? sanitize_text_field($request['path']) : '';
        $official_hashes = isset($request['official_hashes']) && is_array($request['official_hashes']) ? $request['official_hashes'] : array();
        return Sentinel_Overlay_Detector::get_instance()->detect_overlays($path, $official_hashes);
    }

    public function execute_job($request) {
        // Implement job queuing logic here
        return true;
    }

    public function post_restore_validate($request) {
        $recovery_point = isset($request['recovery_point']) ? sanitize_text_field($request['recovery_point']) : '';
        $files = isset($request['files']) && is_array($request['files']) ? $request['files'] : array();

        if (empty($recovery_point) || empty($files)) {
            return new WP_REST_Response(array('status' => 'FAILED', 'error' => 'Missing recovery_point or files list'), 400);
        }

        // Simulación: Comprobar cuáles archivos existen físicamente
        $files_to_overwrite = 0;
        foreach ($files as $file_path) {
            if (file_exists(ABSPATH . $file_path)) {
                $files_to_overwrite++;
            }
        }

        return new WP_REST_Response(array(
            'status' => 'READY',
            'recovery_point' => $recovery_point,
            'files_to_overwrite' => $files_to_overwrite
        ), 200);
    }

    public function post_restore_files($request) {
        $workspace = Sentinel_Recovery_Workspace::get_instance()->prepare_workspace();
        if (!$workspace) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'Could not prepare workspace'), 500);
        }

        $files = isset($request['files']) && is_array($request['files']) ? $request['files'] : array();
        $overlays = isset($request['overlays']) && is_array($request['overlays']) ? $request['overlays'] : array();

        $restored = array();
        $failed = array();

        foreach ($files as $file) {
            $path = isset($file['path']) ? sanitize_text_field($file['path']) : '';
            $content = isset($file['content']) ? sanitize_text_field($file['content']) : '';
            $hash = isset($file['hash']) ? sanitize_text_field($file['hash']) : '';

            $res = Sentinel_File_Recovery::get_instance()->recover_file($path, $content, $hash);
            if ($res['status'] === 'success') {
                $restored[] = $path;
            } else {
                $failed[] = array('path' => $path, 'error' => $res['error']);
            }
        }

        if (!empty($overlays)) {
            Sentinel_File_Recovery::get_instance()->apply_overlays_to_workspace($overlays);
        }

        return new WP_REST_Response(array(
            'status' => 'completed',
            'restored_files' => $restored,
            'failed_files' => $failed
        ), 200);
    }

    public function post_restore_db($request) {
        $chunks = isset($request['chunks']) && is_array($request['chunks']) ? $request['chunks'] : array();
        $category = isset($request['category']) ? sanitize_text_field($request['category']) : '';

        $restored = 0;
        $failed = 0;

        foreach ($chunks as $chunk) {
            $table = isset($chunk['table']) ? sanitize_text_field($chunk['table']) : '';
            $data = isset($chunk['data']) ? $chunk['data'] : '';
            $key = isset($chunk['key']) ? sanitize_text_field($chunk['key']) : '';

            $res = Sentinel_Database_Recovery::get_instance()->restore_table_chunk($table, $data, $key);
            if ($res === true) {
                $restored++;
            } else {
                $failed++;
            }
        }

        if (!empty($category)) {
            Sentinel_Database_Recovery::get_instance()->restore_tables_by_category($category);
        }

        return new WP_REST_Response(array(
            'status' => 'completed',
            'restored_chunks' => $restored,
            'failed_chunks' => $failed
        ), 200);
    }

    public function post_restore_commit($request) {
        $workspace_dir = Sentinel_Recovery_Workspace::WORKSPACE_DIR;
        if (!file_exists($workspace_dir)) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'Workspace not prepared or empty'), 400);
        }

        $files_to_move = array();
        $directory_iterator = new RecursiveDirectoryIterator($workspace_dir, RecursiveDirectoryIterator::SKIP_DOTS);
        $iterator = new RecursiveIteratorIterator($directory_iterator, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($iterator as $item) {
            if ($item->isFile()) {
                $normalized = str_replace('\\', '/', $item->getPathname());
                $relative = ltrim(str_replace(str_replace('\\', '/', $workspace_dir), '', $normalized), '/');
                if ($relative !== 'index.html') {
                    $files_to_move[] = $relative;
                }
            }
        }

        if (empty($files_to_move)) {
            return new WP_REST_Response(array('status' => 'error', 'error' => 'No files found in workspace to commit'), 400);
        }

        // Crear pre-restore snapshot para rollback automático
        Sentinel_Rollback_Engine::get_instance()->create_pre_restore_snapshot($files_to_move);

        $start_time = microtime(true);
        $committed = 0;

        foreach ($files_to_move as $file) {
            $src = $workspace_dir . '/' . $file;
            $dest = ABSPATH . $file;
            $dest_dir = dirname($dest);

            if (!file_exists($dest_dir)) {
                wp_mkdir_p($dest_dir);
            }

            if (copy($src, $dest)) {
                $committed++;
            }
        }

        $duration = round(microtime(true) - $start_time, 4);

        // Limpiar el workspace temporal
        Sentinel_Recovery_Workspace::get_instance()->clean_workspace();

        return new WP_REST_Response(array(
            'status' => 'success',
            'committed_files' => $committed,
            'duration_seconds' => $duration
        ), 200);
    }

    public function post_restore_rollback($request) {
        $res = Sentinel_Rollback_Engine::get_instance()->restore_backup_snapshot();
        return new WP_REST_Response($res, 200);
    }

    /**
     * Retorna el estado y telemetría del servidor
     */
    public function get_status($request = null) {
        $this->bootstrap_wpvivid_mainwp();
        global $wp_version;

        $wpvivid_status = $this->get_wpvivid_status();

        if (isset($_GET['_nocache'])) {
            wp_update_plugins();
            wp_update_themes();
        }

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins', array());
        $updates = get_site_transient('update_plugins');
        $themes = wp_get_themes();
        $theme_updates = get_site_transient('update_themes');

        $plugin_list = array();
        foreach ($plugins as $file => $data) {
            $is_active = in_array($file, $active_plugins);
            $has_update = false;
            $new_version = '';

            if (is_object($updates) && isset($updates->response) && is_array($updates->response) && isset($updates->response[$file])) {
                $has_update = true;
                $new_version = $updates->response[$file]->new_version;
            }

            $plugin_list[] = array(
                'file'         => $file,
                'name'         => $data['Name'],
                'version'      => $data['Version'],
                'active'       => $is_active,
                'has_update'   => $has_update,
                'new_version'  => $new_version
            );
        }

        $theme_list = array();
        foreach ($themes as $theme) {
            $stylesheet = $theme->get_stylesheet();
            $is_active = $stylesheet === wp_get_theme()->get_stylesheet();
            $has_update = false;
            $new_version = '';

            if (is_object($theme_updates) && isset($theme_updates->response) && is_array($theme_updates->response) && isset($theme_updates->response[$stylesheet])) {
                $has_update = true;
                $theme_data = $theme_updates->response[$stylesheet];
                $new_version = is_array($theme_data) ? $theme_data['new_version'] : (is_object($theme_data) ? $theme_data->new_version : '');
            }

            $theme_list[] = array(
                'name'         => $theme->get('Name'),
                'version'      => $theme->get('Version'),
                'active'       => $is_active,
                'has_update'   => $has_update,
                'new_version'  => $new_version,
                'slug'         => $stylesheet
            );
        }

        $free_disk = function_exists('disk_free_space') ? @disk_free_space(ABSPATH) : 0;
        $total_disk = function_exists('disk_total_space') ? @disk_total_space(ABSPATH) : 0;
        $free_disk = ($free_disk !== false) ? (int)$free_disk : 0;
        $total_disk = ($total_disk !== false) ? (int)$total_disk : 0;

        // DB Size
        global $wpdb;
        $db_data_size = $wpdb->get_var("SELECT SUM(data_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()");
        $db_index_size = $wpdb->get_var("SELECT SUM(index_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()");
        $db_data_size = $db_data_size ? (int)$db_data_size : 0;
        $db_index_size = $db_index_size ? (int)$db_index_size : 0;
        $db_size = $db_data_size + $db_index_size;

        // Uploads Size
        $uploads_dir = wp_upload_dir();
        $uploads_size = 0;
        if (isset($uploads_dir['basedir'])) {
            $uploads_size = $this->get_dir_size($uploads_dir['basedir']);
        }

        // Files DB Size
        $files_db = WP_CONTENT_DIR . '/controlcenter/indexes/files.db';
        $files_db_size = file_exists($files_db) ? (int)@filesize($files_db) : 0;

        // Large backup files scan in the whole WordPress directory (files > 15MB) - only run on manual sync
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $scan_large = isset($params['scan_large']) && $params['scan_large'] === 'true';
        $large_files = array();
        if ($scan_large) {
            try {
                // Intentar extender el tiempo de ejecución para hostings limitados
                @set_time_limit(60);
                $large_files = $this->scan_large_files(ABSPATH, 15728640); // 15MB en bytes
                if (is_array($large_files)) {
                    usort($large_files, function($a, $b) {
                        return $b['size'] - $a['size'];
                    });
                    $large_files = array_slice($large_files, 0, 10);
                } else {
                    $large_files = array();
                }
            } catch (\Throwable $scan_error) {
                // Si falla por falta de recursos o timeouts, devolver vacío sin tumbar el endpoint
                $large_files = array();
                error_log('Sentinel: Scan de archivos grandes falló: ' . $scan_error->getMessage());
            }
        }

        // Estado del Malware Scanner (colas y estados)
        $scan_queue = 0;
        $scan_state = 'IDLE';
        if (class_exists('Sentinel_Indexer')) {
            $indexer = Sentinel_Indexer::get_instance();
            $scan_queue_res = Sentinel_SQLite_DB::get_instance()->query_files("SELECT COUNT(*) as count FROM scan_queue");
            $scan_queue = !empty($scan_queue_res) ? (int)$scan_queue_res[0]['count'] : 0;
            $scan_state = $indexer->is_scan_active() ? 'ACTIVE' : 'COMPLETED';
        }

        // WordPress Core Updates
        $core_updates = get_site_transient('update_core');
        $wp_has_update = false;
        $wp_new_version = '';
        if (is_object($core_updates) && isset($core_updates->updates)) {
            foreach ($core_updates->updates as $update) {
                if (isset($update->response) && $update->response === 'upgrade') {
                    $wp_has_update = true;
                    $wp_new_version = $update->current;
                    break;
                }
            }
        }

        // Indexed Files Count & Audits (WebP ratio, giant files list, and categories)
        $indexed_files_count = 0;
        $image_optimization = array(
            'modern_count' => 0,
            'standard_count' => 0,
            'total_images' => 0,
            'ratio' => 0
        );
        $file_size_alerts = array(
            'over_1mb_images' => 0,
            'over_10mb_pdfs' => 0,
            'over_25mb_videos' => 0,
            'total_alerts' => 0
        );
        $giant_files_list = array();
        
        try {
            if (class_exists('Sentinel_SQLite_DB')) {
                $db = Sentinel_SQLite_DB::get_instance();
                
                // 1. Indexed Count
                $files_count_res = $db->query_files("SELECT COUNT(*) as count FROM files WHERE status != 'DELETED'");
                if (!empty($files_count_res) && isset($files_count_res[0]['count'])) {
                    $indexed_files_count = (int)$files_count_res[0]['count'];
                }
                
                // 2. Image Optimization Metrics (WebP/AVIF ratio in uploads)
                $img_query = "SELECT 
                    SUM(CASE WHEN path LIKE '%.webp' OR path LIKE '%.avif' THEN 1 ELSE 0 END) as modern_count,
                    SUM(CASE WHEN path LIKE '%.jpg' OR path LIKE '%.jpeg' OR path LIKE '%.png' THEN 1 ELSE 0 END) as standard_count
                    FROM files 
                    WHERE status != 'DELETED' 
                      AND (path LIKE '%uploads%.jpg' 
                        OR path LIKE '%uploads%.jpeg' 
                        OR path LIKE '%uploads%.png' 
                        OR path LIKE '%uploads%.webp' 
                        OR path LIKE '%uploads%.avif')";
                $img_res = $db->query_files($img_query);
                if (!empty($img_res)) {
                    $mod = (int)($img_res[0]['modern_count'] ?? 0);
                    $std = (int)($img_res[0]['standard_count'] ?? 0);
                    $tot = $mod + $std;
                    $image_optimization = array(
                        'modern_count' => $mod,
                        'standard_count' => $std,
                        'total_images' => $tot,
                        'ratio' => $tot > 0 ? round(($mod / $tot) * 100, 2) : 0
                    );
                }
                
                // 3. File Size Metrics (Aggregated count)
                $size_query = "SELECT 
                    SUM(CASE WHEN (path LIKE '%.jpg' OR path LIKE '%.jpeg' OR path LIKE '%.png' OR path LIKE '%.webp' OR path LIKE '%.avif') AND size > 1048576 THEN 1 ELSE 0 END) as over_1mb_images,
                    SUM(CASE WHEN path LIKE '%.pdf' AND size > 10485760 THEN 1 ELSE 0 END) as over_10mb_pdfs,
                    SUM(CASE WHEN (path LIKE '%.mp4' OR path LIKE '%.webm' OR path LIKE '%.avi' OR path LIKE '%.mov') AND size > 26214400 THEN 1 ELSE 0 END) as over_25mb_videos
                    FROM files
                    WHERE status != 'DELETED'";
                $size_res = $db->query_files($size_query);
                if (!empty($size_res)) {
                    $img_o1 = (int)($size_res[0]['over_1mb_images'] ?? 0);
                    $pdf_o10 = (int)($size_res[0]['over_10mb_pdfs'] ?? 0);
                    $vid_o25 = (int)($size_res[0]['over_25mb_videos'] ?? 0);
                    $file_size_alerts = array(
                        'over_1mb_images' => $img_o1,
                        'over_10mb_pdfs' => $pdf_o10,
                        'over_25mb_videos' => $vid_o25,
                        'total_alerts' => $img_o1 + $pdf_o10 + $vid_o25
                    );
                }
                
                // 4. Detailed top 30 giant files list for the Audit tab
                $list_query = "SELECT path, size, mtime FROM files
                    WHERE status != 'DELETED'
                      AND (
                        ((path LIKE '%.jpg' OR path LIKE '%.jpeg' OR path LIKE '%.png' OR path LIKE '%.webp' OR path LIKE '%.avif') AND size > 1048576)
                        OR (path LIKE '%.pdf' AND size > 10485760)
                        OR ((path LIKE '%.mp4' OR path LIKE '%.webm' OR path LIKE '%.avi' OR path LIKE '%.mov') AND size > 26214400)
                      )
                    ORDER BY size DESC
                    LIMIT 30";
                $list_res = $db->query_files($list_query);
                if (!empty($list_res)) {
                    foreach ($list_res as $row) {
                        $giant_files_list[] = array(
                            'path' => $row['path'],
                            'size' => (int)$row['size'],
                            'mtime' => date('Y-m-d H:i:s', (int)$row['mtime'])
                        );
                    }
                }
            }
        } catch (\Exception $e) {
            // Safe fallback
        }

        // Security and Login protection plugins check
        $security_plugins_detected = array();
        $firewall_slugs = array(
            'wordfence/wordfence.php',
            'better-wp-security/better-wp-security.php',
            'sucuri-scanner/sucuri.php',
            'all-in-one-wp-security-and-firewall/wp-security.php',
            'ninja-firewall/ninja-firewall.php',
            'wp-cerber/wp-cerber.php',
            'defender-security/wp-defender.php'
        );
        $login_slugs = array(
            'limit-login-attempts-reloaded/limit-login-attempts-reloaded.php',
            'wps-hide-login/wps-hide-login.php',
            'wp-limit-login-attempts/wp-limit-login-attempts.php',
            'siteground-security/siteground-security.php'
        );
        foreach ($plugin_list as $plg) {
            if ($plg['active']) {
                if (in_array($plg['file'], $firewall_slugs)) {
                    $security_plugins_detected[] = array(
                        'file' => $plg['file'],
                        'name' => $plg['name'],
                        'type' => 'firewall'
                    );
                } elseif (in_array($plg['file'], $login_slugs)) {
                    $security_plugins_detected[] = array(
                        'file' => $plg['file'],
                        'name' => $plg['name'],
                        'type' => 'login'
                    );
                }
            }
        }

        $sentinel_backups = $this->get_sentinel_backups_list();
        if ($wpvivid_status['active']) {
            $wpvivid_backups_res = $this->get_wpvivid_backups();
            if (isset($wpvivid_backups_res['backups']) && is_array($wpvivid_backups_res['backups'])) {
                foreach ($wpvivid_backups_res['backups'] as $wv_backup) {
                    $wv_type_raw = strtolower(isset($wv_backup['type']) ? $wv_backup['type'] : 'full');
                    $mapped_type = 'full';
                    if ($wv_type_raw === 'db') {
                        $mapped_type = 'db';
                    } elseif ($wv_type_raw === 'files' || $wv_type_raw === 'file') {
                        $mapped_type = 'files';
                    } elseif (strpos($wv_type_raw, 'files') !== false || strpos($wv_type_raw, 'db') !== false) {
                        $mapped_type = 'full';
                    }

                    $sentinel_backups[] = array(
                        'filename'       => isset($wv_backup['filename']) ? $wv_backup['filename'] : '',
                        'size'           => isset($wv_backup['size']) ? $wv_backup['size'] : 0,
                        'formatted_size' => isset($wv_backup['formatted_size']) ? $wv_backup['formatted_size'] : '',
                        'date'           => isset($wv_backup['date']) ? $wv_backup['date'] : '',
                        'type'           => $mapped_type,
                        'is_wpvivid'     => true,
                        'wpvivid_id'     => isset($wv_backup['id']) ? $wv_backup['id'] : ''
                    );
                }
            }
        }

        // Akeeba Backup Detection & Tuning
        $akeebabackup_installed = false;
        $akeebabackup_active = false;
        $akeebabackup_version = '';
        $akeeba_tuning = array(
            'max_exec_time' => null,
            'min_exec_time' => null,
            'run_time_bias' => null
        );

        $active_plugins = get_option('active_plugins', array());
        foreach ($active_plugins as $plugin_file) {
            if (strpos($plugin_file, 'akeebabackupwp') !== false) {
                $akeebabackup_installed = true;
                $akeebabackup_active = true;
                break;
            }
        }

        if (!$akeebabackup_active) {
            if (class_exists('AkeebaBackupWP') || defined('AKEEBABACKUPWP_VERSION')) {
                $akeebabackup_installed = true;
                $akeebabackup_active = true;
            }
        }

        if ($akeebabackup_installed || $akeebabackup_active) {
            if (defined('AKEEBABACKUPWP_VERSION')) {
                $akeebabackup_version = AKEEBABACKUPWP_VERSION;
            } else {
                if (!function_exists('get_plugins')) {
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';
                }
                $plugins = get_plugins();
                foreach ($plugins as $file => $data) {
                    if (strpos($file, 'akeebabackupwp') !== false) {
                        $akeebabackup_installed = true;
                        $akeebabackup_version = isset($data['Version']) ? $data['Version'] : '';
                        if (is_plugin_active($file)) {
                            $akeebabackup_active = true;
                        }
                        break;
                    }
                }
            }
        }

        $profile_table = $wpdb->prefix . 'ak_profiles';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $profile_table));
        if ($table_check === $profile_table) {
            $profile_row = $wpdb->get_row("SELECT * FROM `$profile_table` WHERE `enabled` = 1 LIMIT 1", ARRAY_A);
            if (!$profile_row) {
                $profile_row = $wpdb->get_row("SELECT * FROM `$profile_table` LIMIT 1", ARRAY_A);
            }
            if ($profile_row && !empty($profile_row['configuration'])) {
                $config_str = $profile_row['configuration'];
                $config = json_decode($config_str, true);
                if (!is_array($config)) {
                    $config = @unserialize($config_str);
                }
                if (is_array($config)) {
                    $max_exec_time = isset($config['max_exec_time']) ? $config['max_exec_time'] : null;
                    $min_exec_time = isset($config['min_exec_time']) ? $config['min_exec_time'] : null;
                    $run_time_bias = isset($config['run_time_bias']) ? $config['run_time_bias'] : null;

                    if (class_exists('Akeeba\\Engine\\Util\\Factory', false) && method_exists('Akeeba\\Engine\\Util\\Factory', 'getSecureSettings')) {
                        try {
                            $secureSettings = \Akeeba\Engine\Util\Factory::getSecureSettings();
                            if ($secureSettings && method_exists($secureSettings, 'decrypt')) {
                                if (!empty($max_exec_time) && !is_numeric($max_exec_time)) {
                                    $max_exec_time = $secureSettings->decrypt($max_exec_time);
                                }
                                if (!empty($min_exec_time) && !is_numeric($min_exec_time)) {
                                    $min_exec_time = $secureSettings->decrypt($min_exec_time);
                                }
                                if (!empty($run_time_bias) && !is_numeric($run_time_bias)) {
                                    $run_time_bias = $secureSettings->decrypt($run_time_bias);
                                }
                            }
                        } catch (\Throwable $t) {
                            // ignore
                        }
                    }

                    $akeeba_tuning = array(
                        'max_exec_time' => $max_exec_time,
                        'min_exec_time' => $min_exec_time,
                        'run_time_bias' => $run_time_bias
                    );
                }
            }
        }

        return array(
            'status'            => 'online',
            'sentinel_version'  => SENTINEL_VERSION,
            'wp_version'        => $wp_version,
            'php_version'       => PHP_VERSION,
            'woo_active'        => class_exists('WooCommerce'),
            'disk_space'        => array(
                'free_bytes'    => $free_disk,
                'total_bytes'   => $total_disk,
                'free_percent'  => $total_disk > 0 ? round(($free_disk / $total_disk) * 100, 2) : 0
            ),
            'db_size_bytes'     => $db_size,
            'db_data_size_bytes'=> $db_data_size,
            'db_index_size_bytes'=> $db_index_size,
            'uploads_size_bytes'=> $uploads_size,
            'files_db_size'     => $files_db_size,
            'large_files'       => $large_files,
            'memory_limit'      => ini_get('memory_limit'),
            'max_execution_time'=> ini_get('max_execution_time'),
            'plugins'           => $plugin_list,
            'themes'            => $theme_list,
            'sentinel_backups'  => $sentinel_backups,
            'scan_queue'        => $scan_queue,
            'scan_state'        => $scan_state,
            'wp_has_update'     => $wp_has_update,
            'wp_new_version'    => $wp_new_version,
            'indexed_files_count' => $indexed_files_count,
            'db_version'        => $wpdb->db_version(),
            'image_optimization'=> $image_optimization,
            'file_size_alerts'  => $file_size_alerts,
            'giant_files_list'  => $giant_files_list,
            'security_plugins'  => $security_plugins_detected,
            'excluded_files'    => get_option('sentinel_excluded_files', array()),
            'wpvivid_installed' => $wpvivid_status['installed'],
            'wpvivid_active'    => $wpvivid_status['active'],
            'wpvivid_version'   => $wpvivid_status['version'],
            'wpvivid_has_filter'=> has_filter('wpvivid_prepare_backup_mainwp') !== false,
            'wpvivid_task_list_size' => strlen(serialize(get_option('wpvivid_task_list', array()))),
            'wpvivid_backup_list_size'=> strlen(serialize(get_option('wpvivid_backup_list', array()))),
            'akeebabackup_installed' => $akeebabackup_installed,
            'akeebabackup_active'    => $akeebabackup_active,
            'akeebabackup_version'   => $akeebabackup_version,
            'akeeba_tuning'          => $akeeba_tuning,
            'memory_usage'      => size_format(memory_get_usage(true)),
            'memory_peak_usage' => size_format(memory_get_peak_usage(true)),
            'debug_log_tail'    => $this->get_debug_log_tail()
        );
    }

    /**
     * Retorna el listado de archivos de backup generados en la carpeta del plugin
     */
    private function get_sentinel_backups_list() {
        $uploads = wp_upload_dir();
        if (false === $uploads || !empty($uploads['error'])) {
            $base_dir = ABSPATH . 'wp-content/uploads/sentinel-backups/';
        } else {
            $base_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        }
        $backups = array();

        // Escanear subdirectorios db/, files/ y la raíz para compatibilidad retroactiva
        $scan_dirs = array(
            $base_dir . 'db/',
            $base_dir . 'files/',
            $base_dir
        );

        foreach ($scan_dirs as $backup_dir) {
            if (!is_dir($backup_dir)) {
                continue;
            }
            $files = @scandir($backup_dir);
            if ($files === false) {
                continue;
            }
            foreach ($files as $file) {
                if ($file === '.' || $file === '..' || $file === '.htaccess' || $file === 'index.html') {
                    continue;
                }
                if (strpos($file, '_temp') !== false) {
                    continue;
                }
                $full_path = $backup_dir . $file;
                if (!is_file($full_path)) {
                    continue;
                }
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if ($ext === 'sql') {
                    if (class_exists('Sentinel_Backup_DB')) {
                        $backup_db = new Sentinel_Backup_DB();
                        $zip_res = $backup_db->compress_sql_to_zip($full_path);
                        if ($zip_res['success']) {
                            $file = $zip_res['zip_name'];
                            $full_path = $zip_res['zip_path'];
                            $ext = 'zip';
                        }
                    }
                }
                if (in_array($ext, array('zip', 'sql', 'tar', 'gz'))) {
                    // Inferir el tipo de backup desde el nombre del archivo
                    $bk_type = 'full';
                    if (strpos($file, 'backup_db_') !== false || strpos($file, '_db_') !== false || $ext === 'sql') {
                        $bk_type = 'db';
                    } elseif (strpos($file, 'backup_files_') !== false || strpos($file, '_files_') !== false) {
                        $bk_type = 'files';
                    }
                    $file_size = @filesize($full_path);
                    $backups[] = array(
                        'filename'       => $file,
                        'file_name'      => $file,
                        'size'           => $file_size,
                        'formatted_size' => size_format($file_size),
                        'date'           => date('Y-m-d H:i:s', @filemtime($full_path)),
                        'type'           => $bk_type,
                        'is_wpvivid'     => false
                    );
                }
            }
        }
        return $backups;
    }

    /**
     * Calcula el tamaño total de una carpeta de forma recursiva
     */
    private function get_dir_size($path) {
        $size = 0;
        $path = rtrim($path, '/\\') . '/';
        if (is_dir($path)) {
            $files = @scandir($path);
            if ($files !== false) {
                foreach ($files as $file) {
                    if ($file !== '.' && $file !== '..') {
                        $full_path = $path . $file;
                        if (is_dir($full_path)) {
                            $size += $this->get_dir_size($full_path);
                        } else {
                            if (file_exists($full_path)) {
                                $size += @filesize($full_path);
                            }
                        }
                    }
                }
            }
        }
        return $size;
    }

    /**
     * Escanea la ruta buscando archivos pesados (>15MB) de extensiones de backup
     */
    private function scan_large_files($path, $min_size) {
        $large_files = array();
        if (!is_dir($path)) {
            return $large_files;
        }
        $start_time = time();
        $max_duration = 45; // Límite extendido para sitios grandes (>2GB)
        $memory_limit_bytes = $this->get_memory_limit_bytes();

        try {
            $flags = RecursiveDirectoryIterator::SKIP_DOTS;
            if (defined('FilesystemIterator::UNFOLLOW_SYMLINKS')) {
                $flags |= FilesystemIterator::UNFOLLOW_SYMLINKS;
            }
            $directory = new RecursiveDirectoryIterator($path, $flags);
            $iterator = new RecursiveIteratorIterator($directory, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

            foreach ($iterator as $item) {
                // Chequear límite de tiempo en cada ciclo para salir si se demora
                if ((time() - $start_time) > $max_duration) {
                    break;
                }
                
                // Abortar si se consume más del 80% de la memoria disponible
                if ($memory_limit_bytes > 0 && memory_get_usage(true) > ($memory_limit_bytes * 0.8)) {
                    break;
                }
                
                try {
                    if ($item->isFile()) {
                        $file_size = @$item->getSize();
                        if ($file_size >= $min_size) {
                            $large_files[] = array(
                                'path' => str_replace(wp_normalize_path(ABSPATH), '', wp_normalize_path($item->getPathname())),
                                'size' => $file_size,
                                'formatted_size' => size_format($file_size)
                            );
                        }
                    }
                } catch (\Throwable $inner_ex) {
                    // Ignorar fallos de permisos en archivos individuales
                }
            }
        } catch (\Throwable $e) {
            // Ignorar errores generales (permisos, symlinks rotos, etc.)
        }
        return $large_files;
    }

    /**
     * Convierte el memory_limit de PHP a bytes para control de uso de memoria
     */
    private function get_memory_limit_bytes() {
        $limit = ini_get('memory_limit');
        if ($limit === '-1') {
            return 0; // Sin límite
        }
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit) - 1]);
        $value = intval($limit);
        switch ($last) {
            case 'g': $value *= 1024;
            case 'm': $value *= 1024;
            case 'k': $value *= 1024;
        }
        return $value;
    }

    /**
     * Inicia el volcado de base de datos
     */
    public function trigger_backup_db($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup();
    }

    /**
     * Inicia el backup de archivos
     */
    public function trigger_backup_incremental($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }

        // Obtener parámetros
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 500;

        // Obtener tipo de backup solicitado (auto, full, incremental)
        $type = 'auto';
        if (isset($params['type'])) {
            $type = sanitize_text_field($params['type']);
        }
        
        $excluded_files = array();
        if (is_a($request, 'WP_REST_Request')) {
            $body = $request->get_json_params();
            if (isset($body['excluded_files']) && is_array($body['excluded_files'])) {
                $excluded_files = array_map('sanitize_text_field', $body['excluded_files']);
            }
            if (isset($body['type'])) {
                $type = sanitize_text_field($body['type']);
            }
        } elseif (isset($_REQUEST['excluded_files'])) {
            $raw = $_REQUEST['excluded_files'];
            if (is_string($raw)) {
                $decoded = json_decode(stripslashes($raw), true);
                if (is_array($decoded)) {
                    $excluded_files = array_map('sanitize_text_field', $decoded);
                }
            } elseif (is_array($raw)) {
                $excluded_files = array_map('sanitize_text_field', $raw);
            }
        }
        if (isset($_REQUEST['type'])) {
            $type = sanitize_text_field($_REQUEST['type']);
        }
        
        $format = 'zip';
        if (is_a($request, 'WP_REST_Request')) {
            $body = $request->get_json_params();
            if (isset($body['format'])) {
                $format = sanitize_text_field($body['format']);
            }
        } elseif (isset($_REQUEST['format'])) {
            $format = sanitize_text_field($_REQUEST['format']);
        }

        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->run_backup($offset, $limit, $type, $excluded_files, $format);
    }

    public function trigger_update_plugin($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $plugin_file = isset($params['plugin_file']) ? sanitize_text_field($params['plugin_file']) : '';

        if (empty($plugin_file)) {
            return array('success' => false, 'message' => 'Especifica un archivo de plugin.');
        }

        $updater = new Sentinel_Updater();
        return $updater->update_plugin($plugin_file);
    }

    /**
     * Inicia la actualización de un tema
     */
    public function trigger_update_theme($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $theme_slug = isset($params['theme_slug']) ? sanitize_text_field($params['theme_slug']) : '';

        if (empty($theme_slug)) {
            return array('success' => false, 'message' => 'Especifica un slug de tema.');
        }

        $updater = new Sentinel_Updater();
        return $updater->update_theme($theme_slug);
    }

    /**
     * Inicia la actualización de WordPress Core
     */
    public function trigger_update_core($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $updater = new Sentinel_Updater();
        return $updater->update_core();
    }

    /**
     * Inicia la restauración del sitio
     */
    public function trigger_restore($request = null) {
        if (!class_exists('Sentinel_Updater')) {
            return array('success' => false, 'message' => 'Módulo de actualización no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        
        $action = isset($params['action']) ? sanitize_text_field($params['action']) : '';
        $updater = new Sentinel_Updater();

        if ($action === 'restore_rp') {
            $files_baseline = isset($params['files_baseline']) ? sanitize_text_field($params['files_baseline']) : '';
            $files_deltas = isset($params['files_deltas']) ? $params['files_deltas'] : array();
            $database_file = isset($params['database_file']) ? sanitize_text_field($params['database_file']) : '';

            $logs = array();

            // 1. Restaurar archivos baseline
            if (!empty($files_baseline)) {
                $res = $updater->restore_backup($files_baseline);
                if (!$res['success']) {
                    return array('success' => false, 'message' => 'Fallo al restaurar archivos baseline: ' . $res['message']);
                }
                $logs[] = 'Archivos baseline restaurados con éxito.';
            }

            // 2. Restaurar deltas (si existen)
            if (is_array($files_deltas) && !empty($files_deltas)) {
                foreach ($files_deltas as $delta) {
                    $delta_clean = sanitize_text_field($delta);
                    if (!empty($delta_clean)) {
                        $res = $updater->restore_backup($delta_clean);
                        if (!$res['success']) {
                            return array('success' => false, 'message' => 'Fallo al restaurar delta ' . $delta_clean . ': ' . $res['message']);
                        }
                        $logs[] = 'Delta ' . $delta_clean . ' restaurado con éxito.';
                    }
                }
            }

            // 3. Restaurar base de datos
            if (!empty($database_file)) {
                $res = $updater->restore_backup($database_file);
                if (!$res['success']) {
                    return array('success' => false, 'message' => 'Fallo al restaurar base de datos: ' . $res['message']);
                }
                $logs[] = 'Base de datos restaurada con éxito.';
            }

            return array(
                'success' => true,
                'message' => 'Recovery Point restaurado con éxito: ' . implode(' | ', $logs)
            );
        }

        $backup_name = isset($params['backup_name']) ? sanitize_text_field($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Especifica el nombre del backup para restaurar.');
        }

        return $updater->restore_backup($backup_name);
    }

    /**
     * Sube un archivo de backup manual al servidor
     */
    public function upload_backup_file($request = null) {
        if (empty($_FILES['backup_file'])) {
            return new WP_Error('no_file', 'No se ha subido ningún archivo.', array('status' => 400));
        }

        $file = $_FILES['backup_file'];
        
        // Validar extensión
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($extension !== 'zip' && $extension !== 'sql') {
            return new WP_Error('invalid_file_type', 'Tipo de archivo no permitido. Solo se permiten archivos .zip o .sql.', array('status' => 400));
        }

        $uploads = wp_upload_dir();
        $backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';

        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }

        $dest_filename = sanitize_file_name($file['name']);
        $dest_path = $backup_dir . $dest_filename;

        if (move_uploaded_file($file['tmp_name'], $dest_path)) {
            return array(
                'success' => true,
                'message' => 'Archivo de respaldo subido con éxito.',
                'file_name' => $dest_filename
            );
        }

        return new WP_Error('upload_error', 'Fallo al mover el archivo subido al directorio de backups.', array('status' => 500));
    }

    /**
     * Descarga de forma segura un archivo de backup
     */
    public function download_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $raw_file = isset($params['file']) ? trim($params['file']) : '';

        if (empty($raw_file)) {
            return new WP_Error('sentinel_bad_request', 'Especifica un nombre de archivo.', array('status' => 400));
        }

        // Validación de seguridad por expresión regular (evitar path traversal)
        if (!preg_match('/^[a-zA-Z0-9_\-\.]+\.(zip|tar|gz|sql|tmp)$/', $raw_file)) {
            return new WP_Error('sentinel_bad_request', 'Nombre de archivo no válido o caracteres sospechosos detectados.', array('status' => 400));
        }
        $file = $raw_file;

        $uploads = wp_upload_dir();
        $base_backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        
        // Enrutar al subdirectorio correspondiente según el patrón del nombre
        $wpvivid_base_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';
        if (strpos($file, 'backup_db_') !== false || strpos($file, '_db_') !== false) {
            $backup_dir = $base_backup_dir . 'db/';
        } elseif (strpos($file, 'backup_files_') !== false || strpos($file, '_files_') !== false) {
            $backup_dir = $base_backup_dir . 'files/';
        } else {
            $backup_dir = $base_backup_dir;
        }
        
        $file_path = $backup_dir . $file;

        if (!file_exists($file_path) || !is_readable($file_path)) {
            // Fallback 1: Si piden un .sql plano pero ya fue comprimido
            if (pathinfo($file, PATHINFO_EXTENSION) === 'sql' && file_exists($file_path . '.zip') && is_readable($file_path . '.zip')) {
                $file = $file . '.zip';
                $file_path = $file_path . '.zip';
            } else {
                // Fallback 2: Buscar recursivamente en wpvividbackups/ (backups WPvivid no siguen patron Sentinel)
                $wpvivid_found = $this->find_file_recursive($wpvivid_base_dir, $file);
                if ($wpvivid_found) {
                    $file_path = $wpvivid_found;
                } else {
                    return new WP_Error('sentinel_not_found', 'El archivo no existe o no se puede leer.', array('status' => 404));
                }
            }
        }

        $file_size = filesize($file_path);
        $fp = @fopen($file_path, 'rb');
        if (!$fp) {
            return new WP_Error('sentinel_server_error', 'No se pudo abrir el archivo para lectura.', array('status' => 500));
        }

        // Limpiar buffers previos de salida
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Parámetros de descarga parcial (HTTP Range)
        $start = 0;
        $end = $file_size - 1;

        if (isset($_SERVER['HTTP_RANGE'])) {
            if (preg_match('/bytes=\s*(\d+)-(\d*)/i', $_SERVER['HTTP_RANGE'], $matches)) {
                $start = intval($matches[1]);
                if (!empty($matches[2])) {
                    $end = intval($matches[2]);
                }
            }
        }

        if ($start > 0 || $end < ($file_size - 1)) {
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes $start-$end/$file_size");
        } else {
            header('HTTP/1.1 200 OK');
        }

        // Cabeceras estándares de descarga
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Accept-Ranges: bytes');
        
        // Evitar md5_file en caliente para prevenir timeouts por I/O limits en archivos grandes
        header('X-Sentinel-File-Hash: ');

        $content_length = $end - $start + 1;
        header('Content-Length: ' . $content_length);

        // Mover puntero al byte de inicio solicitado
        fseek($fp, $start);

        $chunk_size = 8192; // 8 KB chunks
        $bytes_sent = 0;

        while (!feof($fp) && $bytes_sent < $content_length && (connection_status() == 0)) {
            $to_read = min($chunk_size, $content_length - $bytes_sent);
            $buffer = fread($fp, $to_read);
            echo $buffer;
            flush();
            
            $bytes_sent += strlen($buffer);
        }

        fclose($fp);
        exit;
    }

    /**
     * Elimina un archivo de copia de seguridad del hosting
     */
    public function delete_backup($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $raw_file = isset($params['file']) ? trim($params['file']) : '';

        if (empty($raw_file)) {
            return array('success' => false, 'message' => 'Especifica un nombre de archivo.');
        }

        // Validación de seguridad por expresión regular (evitar path traversal y preservar extensión)
        if (!preg_match('/^[a-zA-Z0-9_\-\.]+\.(zip|tar|gz|sql|tmp)$/', $raw_file)) {
            return array('success' => false, 'message' => 'Nombre de archivo no válido o caracteres sospechosos detectados.');
        }
        $file = $raw_file;

        $uploads = wp_upload_dir();
        $base_backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';
        $wpvivid_base_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';

        // Determinar directorios de búsqueda de forma robusta e inclusiva
        $search_dirs = array();
        if (is_dir($wpvivid_base_dir) && $this->find_file_recursive($wpvivid_base_dir, $file)) {
            $search_dirs[] = $wpvivid_base_dir;
        }
        $search_dirs[] = $base_backup_dir;
        $search_dirs[] = $base_backup_dir . 'db/';
        $search_dirs[] = $base_backup_dir . 'files/';

        foreach ($search_dirs as $backup_dir) {
            // Buscar también en subdirectorios de WPvivid
            if ($backup_dir === $wpvivid_base_dir) {
                $found_path = $this->find_file_recursive($wpvivid_base_dir, $file);
                if ($found_path) {
                    if (unlink($found_path)) {
                        return array('success' => true, 'message' => 'Copia de seguridad WPvivid eliminada del hosting.');
                    }
                    return array('success' => false, 'message' => 'No se pudo eliminar el archivo físico de WPvivid.');
                }
                continue;
            }
            $file_path = $backup_dir . $file;
            if (file_exists($file_path) && is_file($file_path)) {
                if (unlink($file_path)) {
                    return array('success' => true, 'message' => 'Copia de seguridad remota eliminada del hosting.');
                }
                return array('success' => false, 'message' => 'No se pudo eliminar el archivo físico del hosting.');
            }
        }

        return array('success' => false, 'message' => 'El archivo no existe en el hosting remoto.');
    }

    /**
     * Dispara la auto-actualización del plugin Sentinel
     */
    public function trigger_self_update($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $zip_url = isset($params['zip_url']) ? esc_url_raw($params['zip_url']) : '';

        if (empty($zip_url)) {
            return array('success' => false, 'message' => 'Especifica la URL del paquete zip de actualización.');
        }

        require_once plugin_dir_path(__FILE__) . 'class-updater.php';
        $updater = new Sentinel_Updater();
        
        if (method_exists($updater, 'self_update_plugin')) {
            return $updater->self_update_plugin($zip_url);
        }

        return array('success' => false, 'message' => 'El actualizador no soporta auto-actualización en esta versión.');
    }

    public function check_backup_db_support($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->check_environment_support();
    }

    public function trigger_backup_db_mysqldump($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->run_backup_mysqldump();
    }

    public function get_backup_db_status($request = null) {
        $task = get_option('sentinel_active_backup_task');
        if (empty($task)) {
            return array('success' => false, 'message' => 'No hay tareas activas de respaldo.');
        }

        if (isset($task['is_wpvivid']) && $task['is_wpvivid']) {
            if (class_exists('WPvivid_Public_Interface')) {
                $wpvivid = new WPvivid_Public_Interface();
                $wpvivid_status = $wpvivid->get_status();
                
                $wpvivid_task_id = $task['wpvivid_task_id'];
                
                if (isset($wpvivid_status['wpvivid']['task'][$wpvivid_task_id])) {
                    $wv_task = $wpvivid_status['wpvivid']['task'][$wpvivid_task_id];
                    $progress_str = isset($wv_task['task_info']['backup_percent']) ? $wv_task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $descript = isset($wv_task['task_info']['descript']) ? $wv_task['task_info']['descript'] : 'Procesando con WPVivid...';
                    
                    $task['progress'] = $progress;
                    $task['current_table'] = $descript;
                    $task['last_activity'] = time();
                    update_option('sentinel_active_backup_task', $task);
                } else {
                    $backup_list = isset($wpvivid_status['wpvivid']['backup_list']) ? $wpvivid_status['wpvivid']['backup_list'] : array();
                    if (isset($backup_list[$wpvivid_task_id])) {
                        $wv_backup = $backup_list[$wpvivid_task_id];
                        $files = isset($wv_backup['files']) ? $wv_backup['files'] : array();
                        
                        $backup_name = '';
                        if (!empty($files)) {
                            $first_file = reset($files);
                            $backup_name = isset($first_file['file_name']) ? $first_file['file_name'] : (is_string($first_file) ? $first_file : '');
                            if (empty($backup_name) && isset($first_file['name'])) {
                                $backup_name = $first_file['name'];
                            }
                        }
                        
                        if (empty($backup_name)) {
                            $backup_name = $wpvivid_task_id . '_db.zip';
                        }
                        
                        $task['status'] = 'completed';
                        $task['progress'] = 100;
                        $task['backup_name'] = $backup_name;
                        $task['current_table'] = 'Finalizado con WPVivid';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_backup_task', $task);
                    } else {
                        $task['status'] = 'failed';
                        $task['current_table'] = 'La tarea de WPVivid no se encontró o falló.';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_backup_task', $task);
                    }
                }
            } else {
                $task['status'] = 'failed';
                $task['current_table'] = 'Plugin WPVivid desactivado inesperadamente.';
                update_option('sentinel_active_backup_task', $task);
            }
        }

        return array('success' => true, 'task' => $task);
    }

    public function trigger_backup_db_chunk_start($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->start_chunk_backup();
    }

    public function trigger_backup_db_chunk_step($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $table = isset($params['table']) ? sanitize_text_field($params['table']) : '';
        $offset = isset($params['offset']) ? intval($params['offset']) : 0;
        $limit = isset($params['limit']) ? intval($params['limit']) : 1000;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';
        $write_structure = isset($params['write_structure']) ? (bool)$params['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure);
    }

    public function trigger_backup_db_chunk_finish($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_params() : $_REQUEST;
        $backup_name = isset($params['backup_name']) ? sanitize_file_name($params['backup_name']) : '';

        if (empty($backup_name)) {
            return array('success' => false, 'message' => 'Parámetro "backup_name" requerido.');
        }

        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->finish_chunk_backup($backup_name);
    }

    public function trigger_backup_db_async_start($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->start_async_backup();
    }

    public function trigger_backup_db_async_step($request = null) {
        if (!class_exists('Sentinel_Backup_DB')) {
            return array('success' => false, 'message' => 'Módulo de BD no disponible.');
        }
        $backup_db = new Sentinel_Backup_DB();
        return $backup_db->process_async_backup_step();
    }

    public function get_file_exclusions($request = null) {
        $exclusions = get_option('sentinel_excluded_files', array());
        if (!is_array($exclusions)) {
            $exclusions = array();
        }
        return array('success' => true, 'exclusions' => $exclusions);
    }

    public function update_file_exclusions($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        
        $exclusions = array();
        if (isset($params['exclusions'])) {
            $raw_exclusions = $params['exclusions'];
            if (is_array($raw_exclusions)) {
                $exclusions = array_map('sanitize_text_field', $raw_exclusions);
            } elseif (is_string($raw_exclusions)) {
                $decoded = json_decode(stripslashes($raw_exclusions), true);
                if (is_array($decoded)) {
                    $exclusions = array_map('sanitize_text_field', $decoded);
                }
            }
        }
        
        update_option('sentinel_excluded_files', $exclusions);
        return array('success' => true, 'message' => 'Exclusiones guardadas correctamente.', 'exclusions' => $exclusions);
    }

    public function trigger_backup_files_async_start($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $type = isset($params['type']) ? sanitize_text_field($params['type']) : 'auto';
        $format = isset($params['format']) ? sanitize_text_field($params['format']) : 'zip';
        $exclusions = isset($params['exclusions']) ? (array)$params['exclusions'] : array();

        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->start_async_backup($type, $exclusions, $format);
    }

    public function trigger_backup_files_async_step($request = null) {
        if (!class_exists('Sentinel_Backup_Files')) {
            return array('success' => false, 'message' => 'Módulo de archivos no disponible.');
        }
        $backup_files = new Sentinel_Backup_Files();
        return $backup_files->process_async_backup_step();
    }

    public function get_backup_files_status($request = null) {
        $task = get_option('sentinel_active_files_backup_task');
        if (!$task) {
            return array('success' => true, 'task' => array('status' => 'idle', 'progress' => 0));
        }

        if (isset($task['is_wpvivid']) && $task['is_wpvivid']) {
            if (class_exists('WPvivid_Public_Interface')) {
                $wpvivid = new WPvivid_Public_Interface();
                $wpvivid_status = $wpvivid->get_status();
                
                $wpvivid_task_id = $task['wpvivid_task_id'];
                
                if (isset($wpvivid_status['wpvivid']['task'][$wpvivid_task_id])) {
                    $wv_task = $wpvivid_status['wpvivid']['task'][$wpvivid_task_id];
                    $progress_str = isset($wv_task['task_info']['backup_percent']) ? $wv_task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $descript = isset($wv_task['task_info']['descript']) ? $wv_task['task_info']['descript'] : 'Procesando con WPVivid...';
                    
                    $task['progress'] = $progress;
                    $task['current_file'] = $descript;
                    $task['last_activity'] = time();
                    update_option('sentinel_active_files_backup_task', $task);
                } else {
                    $backup_list = isset($wpvivid_status['wpvivid']['backup_list']) ? $wpvivid_status['wpvivid']['backup_list'] : array();
                    if (isset($backup_list[$wpvivid_task_id])) {
                        $wv_backup = $backup_list[$wpvivid_task_id];
                        $files = isset($wv_backup['files']) ? $wv_backup['files'] : array();
                        
                        $backup_name = '';
                        if (!empty($files)) {
                            $first_file = reset($files);
                            $backup_name = isset($first_file['file_name']) ? $first_file['file_name'] : (is_string($first_file) ? $first_file : '');
                            if (empty($backup_name) && isset($first_file['name'])) {
                                $backup_name = $first_file['name'];
                            }
                        }
                        
                        if (empty($backup_name)) {
                            $backup_name = $wpvivid_task_id . '_full.zip';
                        }
                        
                        $task['status'] = 'completed';
                        $task['progress'] = 100;
                        $task['backup_name'] = $backup_name;
                        $task['current_file'] = 'Finalizado con WPVivid';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_files_backup_task', $task);
                    } else {
                        $task['status'] = 'failed';
                        $task['current_file'] = 'La tarea de WPVivid no se encontró o falló.';
                        $task['last_activity'] = time();
                        update_option('sentinel_active_files_backup_task', $task);
                    }
                }
            } else {
                $task['status'] = 'failed';
                $task['current_file'] = 'Plugin WPVivid desactivado inesperadamente.';
                update_option('sentinel_active_files_backup_task', $task);
            }
        }

        return array('success' => true, 'task' => $task);
    }

    public function reset_backups_status() {
        delete_option('sentinel_active_backup_task');
        delete_option('sentinel_active_files_backup_task');

        $upload_dir = wp_upload_dir();
        $sentinel_dir = $upload_dir['basedir'] . '/sentinel/';
        
        $db_lock = $sentinel_dir . 'db/db_backup.lock';
        $files_lock = $sentinel_dir . 'tmp/files_backup.lock';

        if (file_exists($db_lock)) {
            @unlink($db_lock);
        }
        if (file_exists($files_lock)) {
            @unlink($files_lock);
        }

        // Limpiar también tareas de WPvivid en base de datos para desbloquear
        $wpvivid_tasks = get_option('wpvivid_task_list', array());
        if (is_array($wpvivid_tasks)) {
            $changed = false;
            foreach ($wpvivid_tasks as $id => $task) {
                if (isset($task['status']['str']) && ($task['status']['str'] === 'running' || $task['status']['str'] === 'no_responds')) {
                    $wpvivid_tasks[$id]['status']['str'] = 'error';
                    $wpvivid_tasks[$id]['status']['error'] = 'Tarea cancelada manualmente mediante Sentinel.';
                    $changed = true;
                }
            }
            if ($changed) {
                update_option('wpvivid_task_list', $wpvivid_tasks);
                wp_cache_delete('wpvivid_task_list', 'options');
            }
        }

        return array('success' => true, 'message' => 'Locks y tareas limpiadas de forma absoluta.');
    }

    public function get_wpvivid_status($request = null) {
        $installed = false;
        $active = false;
        $version = '';

        // 1. Comprobar en active_plugins
        $active_plugins = get_option('active_plugins', array());
        foreach ($active_plugins as $plugin_file) {
            if (strpos($plugin_file, 'wpvivid') !== false) {
                $installed = true;
                $active = true;
                break;
            }
        }

        // 2. Comprobar mediante clases/constantes
        if (!$active) {
            if (class_exists('WPvivid_Plugin') || class_exists('WPvivid_Public_Interface') || defined('WPVIVID_PLUGIN_VERSION') || class_exists('WPvivid')) {
                $active = true;
                $installed = true;
                $version = defined('WPVIVID_PLUGIN_VERSION') ? WPVIVID_PLUGIN_VERSION : '';
            }
        } else {
            if (defined('WPVIVID_PLUGIN_VERSION')) {
                $version = WPVIVID_PLUGIN_VERSION;
            }
        }

        // 3. Fallback de búsqueda en plugins instalados
        if (!$installed || empty($version)) {
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $plugins = get_plugins();
            foreach ($plugins as $file => $data) {
                if (strpos($file, 'wpvivid-backuprestore') !== false) {
                    $installed = true;
                    $version = isset($data['Version']) ? $data['Version'] : '';
                    if (is_plugin_active($file)) {
                        $active = true;
                    }
                    break;
                }
            }
        }

        return array(
            'success'   => true,
            'installed' => $installed,
            'active'    => $active,
            'version'   => $version
        );
    }

    public function trigger_wpvivid_backup($request = null) {
        $this->bootstrap_wpvivid_mainwp();

        // Desbloqueo proactivo: Si hay tareas colgadas (running/no_responds) en WPvivid, cancelarlas
        $wpvivid_tasks = get_option('wpvivid_task_list', array());
        if (is_array($wpvivid_tasks)) {
            $changed = false;
            foreach ($wpvivid_tasks as $id => $task) {
                if (isset($task['status']['str']) && ($task['status']['str'] === 'running' || $task['status']['str'] === 'no_responds')) {
                    $wpvivid_tasks[$id]['status']['str'] = 'error';
                    $wpvivid_tasks[$id]['status']['error'] = 'Cancelado por Sentinel para iniciar nueva copia.';
                    $changed = true;
                }
            }
            if ($changed) {
                update_option('wpvivid_task_list', $wpvivid_tasks);
                wp_cache_delete('wpvivid_task_list', 'options');
            }
        }

        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $type = isset($params['type']) ? sanitize_text_field($params['type']) : 'full';

        $backup_files = ($type === 'db') ? 'db' : 'files+db';

        $data = array('backup' => array(
            'backup_files' => $backup_files,
            'local' => '1',
            'remote' => '0',
            'type' => 'Manual'
        ));

        $ret = null;
        if (defined('WPVIVID_PLUGIN_DIR')) {
            try {
                // Carga ultra ligera directa para evadir consumo excesivo de memoria
                if (!class_exists('WPvivid_Backup_2')) {
                    include_once WPVIVID_PLUGIN_DIR . '/includes/new_backup/class-wpvivid-backup2.php';
                }
                if (!class_exists('WPvivid_Backup_Task_2')) {
                    include_once WPVIVID_PLUGIN_DIR . '/includes/new_backup/class-wpvivid-backup-task_2.php';
                }
                global $wpvivid_plugin;
                if (isset($wpvivid_plugin) && class_exists('WPvivid_Backup_2') && class_exists('WPvivid_Backup_Task_2')) {
                    if (!isset($wpvivid_plugin->backup2)) {
                        $wpvivid_plugin->backup2 = new WPvivid_Backup_2();
                    }
                    $settings = $wpvivid_plugin->backup2->get_backup_settings($data['backup']);
                    $backup = new WPvivid_Backup_Task_2();
                    $ret = $backup->new_backup_task($data['backup'], $settings);
                }
            } catch (\Exception $ex) {
                // Fallback silencioso al filtro si falla
                $ret = null;
            }
        }

        // Fallback al filtro de MainWP
        if (empty($ret)) {
            $ret = apply_filters('wpvivid_prepare_backup_mainwp', $data);
        }

        // Si fallaron ambos métodos de inicio
        if (empty($ret) || $ret === $data || (is_array($ret) && isset($ret['result']) && $ret['result'] === 'failed')) {
            $error_message = (is_array($ret) && isset($ret['error'])) ? $ret['error'] : 'El plugin WPvivid no se pudo inicializar correctamente en este sitio.';
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $error_message,
                'response' => $ret
            ), 400);
        }

        if (is_array($ret) && isset($ret['task_id'])) {
            $task_id = $ret['task_id'];
            
            // Agendar la ejecución del backup de WPvivid de forma asíncrona real en WP-Cron para no agotar la memoria en la petición REST
            wp_schedule_single_event(time(), 'wpvivid_backup_2_schedule_event', array($task_id));
            
            // Seleccionar la opción y nombre correcto según el tipo de backup solicitado
            $backup_name_suffix = ($type === 'db') ? '_db.zip' : '_full.zip';
            $task_option_key    = ($type === 'db') ? 'sentinel_active_backup_task' : 'sentinel_active_files_backup_task';
            $task = array(
                'status'          => 'running',
                'progress'        => 0,
                'is_wpvivid'      => true,
                'wpvivid_task_id' => $task_id,
                'backup_name'     => $task_id . $backup_name_suffix,
                'current_file'    => 'Preparando con WPVivid (Agendado en Cron)...',
                'last_activity'   => time()
            );
            update_option($task_option_key, $task);

            return array(
                'success' => true,
                'task_id' => $task_id,
                'status'  => 'running',
                'response' => $ret
            );
        } else {
            $error_message = isset($ret['error']) ? $ret['error'] : 'Error preparando el backup de WPvivid.';
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $error_message,
                'response' => $ret
            ), 500);
        }
    }

    public function get_wpvivid_backup_status($request = null) {
        $this->bootstrap_wpvivid_mainwp();
        $ret = apply_filters('wpvivid_get_status_mainwp', array());
        
        $active_tasks = array();
        if (isset($ret['wpvivid']['task']) && is_array($ret['wpvivid']['task'])) {
            foreach ($ret['wpvivid']['task'] as $id => $task) {
                $progress = 0;
                $status = 'running';
                $descript = '';
                
                if (isset($task['task_info'])) {
                    $progress_str = isset($task['task_info']['backup_percent']) ? $task['task_info']['backup_percent'] : '0%';
                    $progress = intval(str_replace('%', '', $progress_str));
                    $status = isset($task['task_info']['status']) ? $task['task_info']['status'] : 'running';
                    $descript = isset($task['task_info']['descript']) ? $task['task_info']['descript'] : '';
                }
                
                $active_tasks[] = array(
                    'task_id'      => $id,
                    'status'       => $status,
                    'progress'     => $progress,
                    'description'  => $descript,
                    'raw_task'     => $task
                );
            }
        }
        
        return array(
            'success' => true,
            'active_tasks' => $active_tasks,
            'raw_status' => $ret
        );
    }

    public function get_wpvivid_backups($request = null) {
        $this->bootstrap_wpvivid_mainwp();
        $ret = apply_filters('wpvivid_get_backup_list_mainwp', array());
        
        $backup_list = array();
        if (isset($ret['wpvivid']['backup_list']) && is_array($ret['wpvivid']['backup_list'])) {
            $backup_list = $ret['wpvivid']['backup_list'];
        } else {
            // Fallback: Leer directamente de la base de datos de WordPress la lista de backups nativa de WPvivid
            $native_list = get_option('wpvivid_backup_list', array());
            if (is_array($native_list)) {
                $backup_list = $native_list;
            }
        }
        
        $formatted = array();
        if (!empty($backup_list) && is_array($backup_list)) {
            foreach ($backup_list as $id => $backup) {
                $date = isset($backup['create_time']) ? date('Y-m-d H:i:s', $backup['create_time']) : '';
                
                $filename = $id;
                $size = 0;
                
                if (isset($backup['backup']['files']) && is_array($backup['backup']['files'])) {
                    $files_info = array();
                    foreach ($backup['backup']['files'] as $file) {
                        if (is_array($file)) {
                            // Soportar tanto 'name' como 'file_name' (varía según versión de WPvivid)
                            $fname = isset($file['file_name']) ? $file['file_name'] : (isset($file['name']) ? $file['name'] : '');
                            $files_info[] = $fname;
                            if (isset($file['size'])) {
                                $size += intval($file['size']);
                            }
                        } else {
                            $files_info[] = $file;
                        }
                    }
                    if (!empty($files_info)) {
                        $filename = implode(', ', $files_info);
                    }
                }
                
                if ($size === 0 && isset($backup['local']['path'])) {
                    $path = rtrim($backup['local']['path'], '/\\') . DIRECTORY_SEPARATOR;
                    if (isset($backup['backup']['files']) && is_array($backup['backup']['files'])) {
                        foreach ($backup['backup']['files'] as $file) {
                            $fname = is_array($file) ? (isset($file['name']) ? $file['name'] : '') : $file;
                            if (!empty($fname) && file_exists($path . $fname)) {
                                $size += @filesize($path . $fname);
                            }
                        }
                    }
                }
                
                // Normalizar tipo de backup desde la estructura de WPvivid
                $wv_type_raw = isset($backup['backup']['type']) ? $backup['backup']['type'] : (isset($backup['type']) ? $backup['type'] : 'unknown');
                // Intentar inferir tipo si es 'unknown' desde los nombres de archivo
                if ($wv_type_raw === 'unknown' && !empty($filename)) {
                    if (strpos($filename, '_db') !== false || strpos($filename, 'database') !== false) {
                        $wv_type_raw = 'db';
                    } elseif (strpos($filename, '_full') !== false || strpos($filename, 'complete') !== false) {
                        $wv_type_raw = 'full';
                    } elseif (strpos($filename, '_files') !== false) {
                        $wv_type_raw = 'files';
                    }
                }
                $formatted[] = array(
                    'id'             => $id,
                    'filename'       => $filename,
                    'file_name'      => $filename,
                    'size'           => $size,
                    'formatted_size' => size_format($size),
                    'date'           => $date,
                    'type'           => $wv_type_raw,
                    'is_wpvivid'     => true,
                    'wpvivid_id'     => $id
                );
            }
        }
        
        // Fallback 3: Si no se encontraron backups vía API ni DB, escanear directorio físico
        if (empty($formatted)) {
            $wpvivid_dir = trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/';
            if (is_dir($wpvivid_dir)) {
                $scanned = $this->scan_wpvivid_physical_dir($wpvivid_dir);
                $formatted = array_merge($formatted, $scanned);
            }
        }
        
        return array('success' => true, 'backups' => $formatted);
    }

    /**
     * Busca un archivo de forma recursiva en un directorio dado.
     * Retorna la ruta absoluta del archivo si lo encuentra, o false si no.
     */
    private function find_file_recursive($dir, $filename) {
        $dir = trailingslashit($dir);
        if (!is_dir($dir)) return false;
        $direct_path = $dir . $filename;
        if (file_exists($direct_path) && is_file($direct_path)) {
            return $direct_path;
        }
        $entries = @scandir($dir);
        if (!$entries) return false;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $full_path = $dir . $entry;
            if (is_dir($full_path)) {
                $found = $this->find_file_recursive($full_path, $filename);
                if ($found) return $found;
            }
        }
        return false;
    }

    /**
     * Escanea físicamente el directorio wpvividbackups/ y retorna una lista de backups
     * para usar como fallback cuando la DB de WPvivid no tiene registros.
     */
    private function scan_wpvivid_physical_dir($wpvivid_dir) {
        $result   = array();
        $wpvivid_dir = trailingslashit($wpvivid_dir);
        $entries = @scandir($wpvivid_dir);
        if (!$entries) return $result;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $entry_path = $wpvivid_dir . $entry;
            $files_to_check = array();
            if (is_dir($entry_path)) {
                // Subdirectorio de tarea WPvivid: buscar archivos .zip dentro
                $sub_entries = @scandir($entry_path . DIRECTORY_SEPARATOR);
                if ($sub_entries) {
                    foreach ($sub_entries as $sub) {
                        if ($sub !== '.' && $sub !== '..' && is_file($entry_path . DIRECTORY_SEPARATOR . $sub)) {
                            $files_to_check[] = array('path' => $entry_path . DIRECTORY_SEPARATOR . $sub, 'name' => $sub, 'task_id' => $entry);
                        }
                    }
                }
            } elseif (is_file($entry_path)) {
                $files_to_check[] = array('path' => $entry_path, 'name' => $entry, 'task_id' => $entry);
            }
            foreach ($files_to_check as $finfo) {
                $ext = strtolower(pathinfo($finfo['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, array('zip', 'sql', 'tar', 'gz'))) continue;
                $file_size = @filesize($finfo['path']);
                $file_mtime = @filemtime($finfo['path']);
                // Inferir tipo desde el nombre del archivo
                $bk_type = 'full';
                if (strpos($finfo['name'], '_db') !== false || strpos($finfo['name'], 'database') !== false || $ext === 'sql') {
                    $bk_type = 'db';
                } elseif (strpos($finfo['name'], '_files') !== false) {
                    $bk_type = 'files';
                }
                $result[] = array(
                    'id'             => $finfo['task_id'],
                    'filename'       => $finfo['name'],
                    'file_name'      => $finfo['name'],
                    'size'           => $file_size,
                    'formatted_size' => size_format($file_size),
                    'date'           => $file_mtime ? date('Y-m-d H:i:s', $file_mtime) : '',
                    'type'           => $bk_type,
                    'is_wpvivid'     => true,
                    'wpvivid_id'     => $finfo['task_id'],
                    'source'         => 'physical_scan'
                );
            }
        }
        return $result;
    }

    public function delete_wpvivid_backup($request = null) {
        $this->bootstrap_wpvivid_mainwp();
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $backup_id = isset($params['backup_id']) ? sanitize_text_field($params['backup_id']) : '';

        if (empty($backup_id)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Parámetro backup_id requerido.'), 400);
        }

        $ret = apply_filters('wpvivid_delete_backup_mainwp', array('backup_id' => $backup_id, 'force' => 1));

        return array(
            'success' => isset($ret['result']) && $ret['result'] === 'success',
            'response' => $ret
        );
    }

    /**
     * Fuerza la inicialización de la interfaz MainWP de WPvivid en llamadas REST API
     * (donde is_admin() es false y WPvivid no carga sus dependencias por defecto).
     */
    private function bootstrap_wpvivid_mainwp() {
        // Elevar temporalmente el límite de memoria para evitar Fatal Errors de agotamiento (256M -> 512M)
        @ini_set('memory_limit', '512M');

        if (defined('WPVIVID_PLUGIN_DIR')) {
            global $wpvivid_plugin;
            
            // 1. Asegurar que las clases de WPvivid estén cargadas
            if (!class_exists('WPvivid_Interface_MainWP')) {
                $mainwp_file = WPVIVID_PLUGIN_DIR . '/includes/class-wpvivid-interface-mainwp.php';
                if (file_exists($mainwp_file)) {
                    include_once $mainwp_file;
                }
            }
            if (!class_exists('WPvivid_Backup_2')) {
                $backup2_file = WPVIVID_PLUGIN_DIR . '/includes/new_backup/class-wpvivid-backup2.php';
                if (file_exists($backup2_file)) {
                    include_once $backup2_file;
                }
            }
            if (!class_exists('WPvivid_Backup_Task_2')) {
                $task2_file = WPVIVID_PLUGIN_DIR . '/includes/new_backup/class-wpvivid-backup-task_2.php';
                if (file_exists($task2_file)) {
                    include_once $task2_file;
                }
            }
            
            // 2. Instanciar los motores e interfaz de MainWP si no están inicializados
            if (isset($wpvivid_plugin)) {
                if (!isset($wpvivid_plugin->backup2) && class_exists('WPvivid_Backup_2')) {
                    $wpvivid_plugin->backup2 = new WPvivid_Backup_2();
                }
                if (!isset($wpvivid_plugin->interface_mainwp) && class_exists('WPvivid_Interface_MainWP')) {
                    $wpvivid_plugin->interface_mainwp = new WPvivid_Interface_MainWP();
                }
            }
        }
    }

    /**
     * Retorna las últimas 30 líneas del archivo de log de errores de PHP / WordPress
     */
    private function get_debug_log_tail() {
        $log_paths = array(
            WP_CONTENT_DIR . '/debug.log',
            ABSPATH . 'error_log',
            WP_CONTENT_DIR . '/error_log',
        );
        foreach ($log_paths as $path) {
            if (file_exists($path) && is_readable($path)) {
                $lines = array();
                $file = @fopen($path, 'r');
                if ($file) {
                    // Leer eficientemente el final del archivo
                    @fseek($file, 0, SEEK_END);
                    $pos = @ftell($file);
                    $line_count = 0;
                    $buffer = '';
                    while ($pos > 0 && $line_count < 35) {
                        $pos--;
                        @fseek($file, $pos);
                        $char = @fgetc($file);
                        if ($char === "\n") {
                            if (!empty($buffer)) {
                                $lines[] = strrev($buffer);
                                $buffer = '';
                                $line_count++;
                            }
                        } else {
                            $buffer .= $char;
                        }
                    }
                    if (!empty($buffer)) {
                        $lines[] = strrev($buffer);
                    }
                    @fclose($file);
                    return array(
                        'path' => basename($path),
                        'size' => filesize($path),
                        'content' => array_reverse($lines)
                    );
                }
            }
        }
        return 'No se encontró debug.log o error_log accesible.';
    }

    public function delete_physical_file($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $file_path = isset($params['path']) ? sanitize_text_field($params['path']) : '';

        if (empty($file_path)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Parámetro path requerido.'), 400);
        }

        // Sanitizar y prevenir Path Traversal
        $normalized_path = wp_normalize_path($file_path);
        // Quitar slashes iniciales para concatenar de forma segura
        $normalized_path = ltrim($normalized_path, '/');
        
        $abs_path = wp_normalize_path(ABSPATH);
        $full_path = wp_normalize_path($abs_path . $normalized_path);

        // Validar que la ruta final comience con la ruta absoluta del sitio para evitar salirse del directorio raíz
        if (strpos($full_path, $abs_path) !== 0) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Acceso denegado: Ruta de archivo inválida o fuera del directorio del sitio.'), 403);
        }

        if (!file_exists($full_path) || !is_file($full_path)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'El archivo no existe en el servidor remoto.'), 404);
        }

        if (@unlink($full_path)) {
            return array('success' => true, 'message' => 'El archivo ha sido eliminado físicamente del servidor.');
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => 'No se pudo eliminar el archivo. Comprueba los permisos de escritura en el servidor.'), 500);
        }
    }

    public function download_physical_file($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $file_path = isset($params['path']) ? sanitize_text_field($params['path']) : '';

        if (empty($file_path)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Parámetro path requerido.'), 400);
        }

        $normalized_path = wp_normalize_path($file_path);
        $normalized_path = ltrim($normalized_path, '/');
        
        $abs_path = wp_normalize_path(ABSPATH);
        $full_path = wp_normalize_path($abs_path . $normalized_path);

        if (strpos($full_path, $abs_path) !== 0) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Acceso denegado: Ruta de archivo inválida.'), 403);
        }

        if (!file_exists($full_path) || !is_file($full_path) || !is_readable($full_path)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'El archivo no existe o no se puede leer.'), 404);
        }

        $file_size = filesize($full_path);
        
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($full_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . $file_size);
        
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        $fp = fopen($full_path, 'rb');
        if ($fp) {
            while (!feof($fp)) {
                echo fread($fp, 8192);
                flush();
            }
            fclose($fp);
            exit;
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => 'Error al abrir el archivo.'), 500);
        }
    }

    public function truncate_database_table($request = null) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $table_name = isset($params['table']) ? sanitize_text_field($params['table']) : '';

        if (empty($table_name)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Parámetro "table" requerido.'), 400);
        }

        global $wpdb;
        
        $safe_prefix = $wpdb->prefix;
        $allowed_tables = array(
            $safe_prefix . 'actionscheduler_actions',
            $safe_prefix . 'actionscheduler_logs',
            $safe_prefix . 'actionscheduler_claims',
            $safe_prefix . 'woocommerce_sessions',
            $safe_prefix . 'wc_admin_notes',
            $safe_prefix . 'wc_admin_note_actions',
            $safe_prefix . 'redirection_logs',
            $safe_prefix . 'wflogins',
            $safe_prefix . 'wflocs',
            $safe_prefix . 'wfhits',
            'transients'
        );

        if (!in_array($table_name, $allowed_tables)) {
            if ($table_name !== 'transients' && $table_name !== $safe_prefix . 'options_transients') {
                return new WP_REST_Response(array('success' => false, 'message' => 'Acceso denegado: El vaciado de esta tabla no está clasificado como seguro.'), 403);
            }
        }

        if ($table_name === 'transients' || $table_name === $safe_prefix . 'options_transients') {
            $deleted = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'");
            return array('success' => true, 'message' => "Transients eliminados correctamente del sitio. Filas afectadas: $deleted");
        }

        if (!preg_match('/^[a-zA-Z0-9_]+$/', $table_name)) {
            return new WP_REST_Response(array('success' => false, 'message' => 'Nombre de tabla inválido.'), 400);
        }

        $query_check = $wpdb->prepare("SHOW TABLES LIKE %s", $table_name);
        if ($wpdb->get_var($query_check) !== $table_name) {
            return new WP_REST_Response(array('success' => false, 'message' => 'La tabla no existe en la base de datos del sitio.'), 404);
        }

        $result = $wpdb->query("TRUNCATE TABLE `$table_name`");
        if ($result !== false) {
            return array('success' => true, 'message' => "La tabla '$table_name' ha sido vaciada con éxito.");
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => 'No se pudo vaciar la tabla. Ocurrió un error en la consulta.'), 500);
        }
    }

    public function get_transients_status($request = null) {
        global $wpdb;
        $sql = "SELECT SUM(OCTET_LENGTH(option_name) + OCTET_LENGTH(option_value)) as size_bytes, COUNT(*) as count 
                FROM {$wpdb->options} 
                WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'";
        $row = $wpdb->get_row($sql);
        $size_bytes = $row && $row->size_bytes ? (int)$row->size_bytes : 0;
        $count = $row && $row->count ? (int)$row->count : 0;

        return array(
            'success' => true,
            'size_bytes' => $size_bytes,
            'size_mb' => round($size_bytes / (1024 * 1024), 2),
            'count' => $count
        );
    }

    public function get_akeeba_status_endpoint($request = null) {
        $status = array(
            'installed' => false,
            'active' => false,
            'version' => '',
            'profiles' => array()
        );

        $active_plugins = get_option('active_plugins', array());
        foreach ($active_plugins as $plugin_file) {
            if (strpos($plugin_file, 'akeebabackupwp') !== false) {
                $status['installed'] = true;
                $status['active'] = true;
                break;
            }
        }

        if (!$status['active']) {
            if (class_exists('AkeebaBackupWP') || defined('AKEEBABACKUPWP_VERSION')) {
                $status['installed'] = true;
                $status['active'] = true;
            }
        }

        if (defined('AKEEBABACKUPWP_VERSION')) {
            $status['version'] = AKEEBABACKUPWP_VERSION;
        } else {
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $plugins = get_plugins();
            foreach ($plugins as $file => $data) {
                if (strpos($file, 'akeebabackupwp') !== false) {
                    $status['installed'] = true;
                    $status['version'] = isset($data['Version']) ? $data['Version'] : '';
                    if (is_plugin_active($file)) {
                        $status['active'] = true;
                    }
                    break;
                }
            }
        }

        global $wpdb;
        $profile_table = $wpdb->prefix . 'ak_profiles';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $profile_table));
        if ($table_check === $profile_table) {
            $profiles = $wpdb->get_results("SELECT id, name, description, enabled FROM `$profile_table`", ARRAY_A);
            if (is_array($profiles)) {
                $status['profiles'] = $profiles;
            }
        }

        return array('success' => true, 'status' => $status);
    }

    private function get_or_create_akeeba_db_profile($base_profile_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'ak_profiles';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($table_check !== $table) {
            return $base_profile_id; // Si la tabla no existe, devolver el base
        }

        // 1. Buscar si ya existe el perfil autogenerado o uno creado manualmente por el usuario
        $sentinel_profile_desc = '[Sentinel] Database Backup';
        $existing = $wpdb->get_row($wpdb->prepare("SELECT `id` FROM `$table` WHERE `description` = %s OR `description` LIKE %s OR `description` LIKE %s OR `description` LIKE %s ORDER BY `id` DESC LIMIT 1", 
            $sentinel_profile_desc,
            '%backup bd%',
            '%backup db%',
            '%base de datos%'
        ));
        
        if ($existing && !empty($existing->id)) {
            return (int) $existing->id;
        }

        // 2. Si no existe, clonar el base_profile
        $base_profile = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$table` WHERE `id` = %d", $base_profile_id), ARRAY_A);
        if (!$base_profile) {
            // Si el base no existe, intentamos con el 1
            $base_profile = $wpdb->get_row($wpdb->prepare("SELECT * FROM `$table` WHERE `id` = %d", 1), ARRAY_A);
            if (!$base_profile) {
                return $base_profile_id;
            }
        }

        // 3. Modificar la configuración
        $original_config = $base_profile['configuration'];
        $is_encrypted = (strpos($original_config, '###AES128###') === 0 || strpos($original_config, '###CTR128###') === 0);
        $decrypted_config = $original_config;

        if ($is_encrypted && class_exists('Akeeba\Engine\Util\Factory')) {
            $secure_settings = \Akeeba\Engine\Util\Factory::getSecureSettings();
            $decrypted_config = $secure_settings->decryptSettings($original_config);
        }

        $new_config = '';
        $is_json = (substr(trim($decrypted_config), 0, 1) === '{');

        if ($is_json) {
            $json_data = json_decode($decrypted_config, true);
            if (is_array($json_data)) {
                $json_data['akeeba.basic.backup_type'] = 'dbonly';
                $new_config = wp_json_encode($json_data);
            }
        } else {
            $config_lines = explode("\n", $decrypted_config);
            $new_lines = array();
            $found = false;
            foreach ($config_lines as $line) {
                $line = trim($line);
                if (empty($line)) continue;
                if (strpos($line, 'akeeba.basic.backup_type') === 0 || strpos($line, 'akeeba.basic.type') === 0) {
                    $new_lines[] = 'akeeba.basic.backup_type=dbonly';
                    $found = true;
                } else {
                    $new_lines[] = $line;
                }
            }
            if (!$found) {
                $new_lines[] = "akeeba.basic.backup_type=dbonly";
            }
            $new_config = implode("\n", $new_lines);
        }

        if (empty($new_config)) {
            $new_config = $decrypted_config; // fallback
        }

        if ($is_encrypted && class_exists('Akeeba\Engine\Util\Factory')) {
            $secure_settings = \Akeeba\Engine\Util\Factory::getSecureSettings();
            $new_config = $secure_settings->encryptSettings($new_config);
        }

        // 4. Insertar el nuevo perfil de forma dinámica
        $insert_data = array(
            'description' => $sentinel_profile_desc,
            'configuration' => $new_config
        );
        $formats = array('%s', '%s');

        if (array_key_exists('filters', $base_profile)) {
            $insert_data['filters'] = $base_profile['filters'];
            $formats[] = '%s';
        }
        if (array_key_exists('quickicon', $base_profile)) {
            $insert_data['quickicon'] = 0;
            $formats[] = '%d';
        }

        $inserted = $wpdb->insert(
            $table,
            $insert_data,
            $formats
        );

        if ($inserted) {
            return (int) $wpdb->insert_id;
        }

        // Si falló, guardamos el error en una option para debug
        update_option('sentinel_akeeba_last_error', $wpdb->last_error);

        return $base_profile_id;
    }

    public function trigger_akeeba_backup($request) {
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        update_option('sentinel_akeeba_last_error', 'Params: ' . wp_json_encode($params));
        
        $profile_id = isset($params['profile_id']) ? intval($params['profile_id']) : 1;
        $action = isset($params['action']) ? $params['action'] : 'start';
        $backupid = isset($params['backupid']) ? $params['backupid'] : '';
        $type = isset($params['type']) ? $params['type'] : '';

        // Solo procesamos acciones start o step
        if ($action !== 'start' && $action !== 'step') {
            return rest_ensure_response(array('success' => false, 'message' => 'Acción de Akeeba no válida.'));
        }

        if (!class_exists('AkeebaBackupWP') || !method_exists('AkeebaBackupWP', 'loadAppConfig')) {
            return rest_ensure_response(array('success' => false, 'message' => 'Akeeba Backup no está instalado o activo.'));
        }

        try {
            $method = new ReflectionMethod('AkeebaBackupWP', 'loadAppConfig');
            $method->setAccessible(true);
            $method->invoke(null);
            
            $container = \AkeebaBackupWP::loadAkeebaBackupContainer();
            if (!$container) {
                return rest_ensure_response(array('success' => false, 'message' => 'No se pudo cargar el contenedor de Akeeba.'));
            }
            $container->application->initialise();

            // Si se solicita explícitamente tipo 'db', interceptamos el ID de perfil AHORA que el autoloader de Akeeba está activo
            if ($type === 'db') {
                $profile_id = $this->get_or_create_akeeba_db_profile($profile_id);
            }

            if (!defined('AKEEBA_BACKUP_ORIGIN')) {
                define('AKEEBA_BACKUP_ORIGIN', 'backend');
            }

            // Inyectar forzosamente los parámetros en el Input de AWF (el framework de Akeeba)
            $container->input->set('profile', $profile_id);
            $container->input->set('ajax', $action); // 'start' o 'step'
            if ($backupid) {
                $container->input->set('backupid', $backupid);
            }

            // Interceptar la salida estándar, ya que el Controlador de Akeeba inyectará cabeceras HTTP y hará flush()
            ob_start();
            $controller = $container->mvcFactory->makeController('Backup');
            $controller->execute('ajax');
            $raw_output = ob_get_clean();

            // Limpiar la firma "#\"#\"#" que Akeeba inyecta para evadir firewalls
            $clean_json = str_replace('#\"#\"#', '', $raw_output);
            $ret_array = json_decode($clean_json, true);

            return rest_ensure_response(array(
                'success' => true,
                'data'    => $ret_array
            ));
        } catch (Exception $e) {
            return rest_ensure_response(array('success' => false, 'message' => 'Error en motor Akeeba: ' . $e->getMessage()));
        } catch (Error $e) {
            return rest_ensure_response(array('success' => false, 'message' => 'Error Fatal en motor Akeeba: ' . $e->getMessage()));
        }
    }

    public function get_akeeba_backup_status($request = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'ak_stats';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($table_check !== $table) {
            return array('success' => false, 'message' => 'La tabla de backups de Akeeba no existe.');
        }

        $last_backup = $wpdb->get_row("SELECT * FROM `$table` ORDER BY `id` DESC LIMIT 1", ARRAY_A);
        if (!$last_backup) {
            return array('success' => true, 'task' => array('status' => 'idle', 'progress' => 0));
        }

        $status = 'idle';
        $progress = 0;
        if ($last_backup['status'] === 'run') {
            $status = 'running';
            $progress = 50;
        } elseif ($last_backup['status'] === 'complete') {
            $status = 'completed';
            $progress = 100;
        } elseif ($last_backup['status'] === 'fail') {
            $status = 'failed';
            $progress = 0;
        }

        return array(
            'success' => true,
            'task' => array(
                'id'            => $last_backup['id'],
                'status'        => $status,
                'progress'      => $progress,
                'backup_name'   => $last_backup['shortdesc'],
                'date'          => $last_backup['backupstart'],
                'raw_status'    => $last_backup
            )
        );
    }

    public function get_akeeba_backups($request = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'ak_stats';
        $backups = array();
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($table_check === $table) {
            $results = $wpdb->get_results("SELECT * FROM `$table` WHERE `status` IN ('ok', 'complete', 'run') ORDER BY `id` DESC LIMIT 50", ARRAY_A);
            foreach ($results as $row) {
                // Akeeba almacena el nombre del archivo en 'archivename' y el tamaño en 'total_size'
                // 'description' tiene la descripción del backup
                $backups[] = array(
                    'id' => $row['id'],
                    'filename' => !empty($row['archivename']) ? basename($row['archivename']) : $row['description'],
                    'size' => (int)$row['total_size'],
                    'formatted_size' => size_format($row['total_size']),
                    'date' => $row['backupstart'],
                    'type' => $row['type'],
                    'is_akeeba' => true
                );
            }
        }
        return array('success' => true, 'backups' => $backups);
    }

    public function update_akeeba_exclusions($request = null) {
        global $wpdb;
        $params = is_a($request, 'WP_REST_Request') ? $request->get_json_params() : $_REQUEST;
        $profile_id = isset($params['profile_id']) ? intval($params['profile_id']) : 1;
        $exclusions = isset($params['exclusions']) && is_array($params['exclusions']) ? $params['exclusions'] : array();

        $profile_table = $wpdb->prefix . 'ak_profiles';
        $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $profile_table));
        if ($table_check !== $profile_table) {
            return new WP_REST_Response(array('success' => false, 'message' => 'La tabla de perfiles de Akeeba no existe.'), 404);
        }

        $filters_str = $wpdb->get_var($wpdb->prepare("SELECT `filters` FROM `$profile_table` WHERE `id` = %d", $profile_id));
        $filters = json_decode($filters_str, true);
        if (!is_array($filters)) {
            $filters = @unserialize($filters_str);
        }
        if (!is_array($filters)) {
            $filters = array();
        }

        if (!isset($filters['directories'])) {
            $filters['directories'] = array();
        }
        $filters['directories']['[ROOT]'] = array();

        if (!isset($filters['files'])) {
            $filters['files'] = array();
        }
        $filters['files']['[ROOT]'] = array();

        $inserted = 0;
        foreach ($exclusions as $exclusion) {
            $path = sanitize_text_field($exclusion);
            if (empty($path)) continue;

            $path = wp_normalize_path($path);
            $path = ltrim($path, '/');
            if (empty($path)) continue;

            $is_dir = is_dir(ABSPATH . $path);
            if (!$is_dir) {
                $basename = basename($path);
                if (strpos($basename, '.') === false) {
                    $is_dir = true;
                }
            }

            if ($is_dir) {
                $filters['directories']['[ROOT]'][] = $path;
            } else {
                $filters['files']['[ROOT]'][] = $path;
            }
            $inserted++;
        }

        $json_options = 0;
        if (defined('JSON_HEX_TAG')) {
            $json_options |= JSON_HEX_TAG;
        }
        if (defined('JSON_HEX_AMP')) {
            $json_options |= JSON_HEX_AMP;
        }
        if (defined('JSON_HEX_APOS')) {
            $json_options |= JSON_HEX_APOS;
        }
        if (defined('JSON_HEX_QUOT')) {
            $json_options |= JSON_HEX_QUOT;
        }
        if (defined('JSON_PRETTY_PRINT')) {
            $json_options |= JSON_PRETTY_PRINT;
        }

        $updated_filters_str = json_encode($filters, $json_options);

        $wpdb->update(
            $profile_table,
            array('filters' => $updated_filters_str),
            array('id' => $profile_id),
            array('%s'),
            array('%d')
        );

        return array('success' => true, 'message' => "Se actualizaron $inserted exclusiones correctamente en el perfil $profile_id.");
    }
}