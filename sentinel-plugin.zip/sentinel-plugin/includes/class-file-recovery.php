<?php
if (!defined('ABSPATH')) {
    exit; // Evita el acceso directo al archivo
}

class Sentinel_File_Recovery {

    const FILE_RECOVERY_PREFIX = 'sentinel_file_recovery_';

    private static $instance = null;

    /**
     * Singleton instance getter.
     *
     * @return Sentinel_File_Recovery
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {}

    /**
     * Recovers a file in the workspace directory.
     *
     * @param string $relative_path The relative path of the file within the workspace.
     * @param string $content_base64 Base64 encoded content of the file.
     * @param string $expected_hash Expected SHA256 hash of the file.
     * @return array Result with status, path, and error details if applicable.
     */
    public function recover_file($relative_path, $content_base64, $expected_hash) {
        $workspace_dir = Sentinel_Recovery_Workspace::WORKSPACE_DIR;
        $absolute_path = trailingslashit($workspace_dir) . str_replace('\\', '/', $relative_path);

        // Validate path to prevent directory traversal
        if (strpos($absolute_path, $workspace_dir) !== 0 || strpos($absolute_path, '..') !== false) {
            return array('status' => 'error', 'path' => '', 'error' => 'Invalid file path');
        }

        // Create directories recursively if they don't exist
        $dir = dirname($absolute_path);
        if (!wp_mkdir_p($dir)) {
            return array('status' => 'error', 'path' => '', 'error' => 'Failed to create directory structure');
        }

        // Decode and save the file content
        $content = base64_decode($content_base64, true);
        if ($content === false) {
            return array('status' => 'error', 'path' => '', 'error' => 'Invalid base64 encoded content');
        }

        if (file_put_contents($absolute_path, $content) === false) {
            return array('status' => 'error', 'path' => '', 'error' => 'Failed to write file content');
        }

        // Validate file size and hash
        clearstatcache();
        $actual_hash = hash_file('sha256', $absolute_path);
        if ($actual_hash !== $expected_hash) {
            return array('status' => 'error', 'path' => '', 'error' => 'Hash mismatch');
        }

        return array('status' => 'success', 'path' => $relative_path);
    }

    /**
     * Applies overlays to the workspace.
     *
     * @param array $overlays_map Map of relative paths to content base64 or hex.
     */
    public function apply_overlays_to_workspace($overlays_map) {
        foreach ($overlays_map as $relative_path => $content_base64_or_hex) {
            $workspace_dir = Sentinel_Recovery_Workspace::WORKSPACE_DIR;
            $absolute_path = trailingslashit($workspace_dir) . str_replace('\\', '/', $relative_path);

            // Validate path to prevent directory traversal
            if (strpos($absolute_path, $workspace_dir) !== 0 || strpos($absolute_path, '..') !== false) {
                continue; // Skip invalid paths
            }

            // Create directories recursively if they don't exist
            $dir = dirname($absolute_path);
            if (!wp_mkdir_p($dir)) {
                continue; // Skip if directory creation fails
            }

            // Decode and save the file content
            $content = base64_decode($content_base64_or_hex, true);
            if ($content === false) {
                $content = hex2bin($content_base64_or_hex); // Try decoding as hex
            }
            if ($content === false) {
                continue; // Skip invalid content
            }

            file_put_contents($absolute_path, $content);
        }
    }
}