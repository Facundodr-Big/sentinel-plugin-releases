<?php
/**
 * Sentinel Reverse Agent (Beacon & Webhook Handler)
 * Permite la gestión y mantenimiento de sitios con bloqueo estricto WAF / Cloudflare
 * ejecutando órdenes mediante disparadores transparentes y reportando por canal saliente.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Sentinel_Reverse_Agent {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Interceptar peticiones públicas de wp-cron.php con parámetros de Sentinel
        add_action('init', array($this, 'handle_cron_trigger'), 1);

        // Endpoint alternativo de descarga segura con token efímero
        add_action('init', array($this, 'handle_secure_download'), 2);
    }

    /**
     * Valida la firma HMAC para verificar que la orden proviene del Control Center
     */
    private function verify_trigger_signature($action, $timestamp, $signature) {
        if (empty($action) || empty($timestamp) || empty($signature)) {
            return false;
        }

        // Tolerancia máxima de 10 minutos (600 segundos) para evitar desfases horarios
        if (abs(time() - intval($timestamp)) > 600) {
            return false;
        }

        $agent_secret = get_option('controlcenter_agent_secret');
        if (empty($agent_secret)) {
            return false;
        }

        $data_to_verify = $action . $timestamp;
        $expected_sig = hash_hmac('sha256', $data_to_verify, $agent_secret);

        return hash_equals($expected_sig, $signature);
    }

    /**
     * Intercepta la URL del cron cuando incluye la acción de Sentinel
     */
    public function handle_cron_trigger() {
        if (!isset($_GET['sentinel_action'])) {
            return;
        }

        $action = sanitize_text_field($_GET['sentinel_action']);
        $timestamp = isset($_GET['t']) ? sanitize_text_field($_GET['t']) : '';
        $signature = isset($_GET['sig']) ? sanitize_text_field($_GET['sig']) : '';

        if (!$this->verify_trigger_signature($action, $timestamp, $signature)) {
            status_header(403);
            wp_send_json_error(array('message' => 'Firma o timestamp inválido en orden Sentinel.'), 403);
            exit;
        }

        // Responder al cliente HTTP de inmediato (200 OK) para evitar timeouts en Cloudflare
        ignore_user_abort(true);
        if (function_exists('fastcgi_finish_request')) {
            echo json_encode(array('status' => 'dispatched', 'action' => $action));
            fastcgi_finish_request();
        }

        // Ejecutar la acción solicitada
        if ($action === 'sync_push') {
            $this->execute_sync_push();
        } elseif ($action === 'backups_push') {
            $this->execute_backups_push();
        }

        if (!function_exists('fastcgi_finish_request')) {
            wp_send_json_success(array('status' => 'dispatched', 'action' => $action));
        }
        exit;
    }

    /**
     * 1. Recopila la telemetría del sitio y la envía vía POST saliente a Sentinel
     */
    public function execute_sync_push() {
        if (!class_exists('Sentinel_Collector')) {
            require_once dirname(__FILE__) . '/class-collector.php';
        }

        $collector = Sentinel_Collector::get_instance();
        $telemetry = $collector->collect_all();
        $telemetry['is_blocked_site'] = true;
        $telemetry['delivery_mode'] = 'reverse_cron_push';
        $telemetry['synced_at'] = current_time('mysql');

        $this->send_outbound_payload('/api/remote-callback/sync', array(
            'data' => $telemetry
        ));
    }

    /**
     * 2. Recopila las rutas y enlaces directos de backups (BD y Archivos) y los despacha a Sentinel
     */
    public function execute_backups_push() {
        $backups_found = array();

        // A. Revisar backups de WPvivid si existe
        if (class_exists('Sentinel_API_Handler')) {
            $handler = Sentinel_API_Handler::get_instance();
            $wpvivid_res = $handler->get_wpvivid_backups();
            if (!empty($wpvivid_res['backups']) && is_array($wpvivid_res['backups'])) {
                foreach ($wpvivid_res['backups'] as $bk) {
                    $fname = isset($bk['file_name']) ? $bk['file_name'] : (isset($bk['filename']) ? $bk['filename'] : '');
                    $btype = isset($bk['type']) ? $bk['type'] : 'unknown';
                    $size = isset($bk['size']) ? intval($bk['size']) : 0;
                    
                    $backups_found[] = array(
                        'filename'     => $fname,
                        'file_name'    => $fname,
                        'type'         => $btype,
                        'size'         => $size,
                        'engine'       => 'wpvivid',
                        'download_url' => $this->generate_secure_download_url($fname),
                        'created_at'   => isset($bk['date']) ? $bk['date'] : current_time('mysql')
                    );
                }
            }
        }

        // B. Revisar backups nativos de Sentinel en uploads/sentinel-backups
        $uploads = wp_upload_dir();
        $base_backup_dir = trailingslashit($uploads['basedir']) . 'sentinel-backups/';

        $dirs_to_check = array(
            'db'    => $base_backup_dir . 'db/',
            'files' => $base_backup_dir . 'files/',
            'temp'  => $base_backup_dir . 'temp/'
        );

        foreach ($dirs_to_check as $type => $dir) {
            if (is_dir($dir)) {
                $files = scandir($dir);
                foreach ($files as $f) {
                    if ($f === '.' || $f === '..' || $f === '.htaccess' || $f === 'index.html') {
                        continue;
                    }
                    $full_path = $dir . $f;
                    if (is_file($full_path)) {
                        $fsize = @filesize($full_path);
                        $mtime = @filemtime($full_path);
                        $backups_found[] = array(
                            'filename'     => $f,
                            'file_name'    => $f,
                            'type'         => $type,
                            'size'         => $fsize,
                            'engine'       => 'sentinel_native',
                            'download_url' => $this->generate_secure_download_url($f, $full_path),
                            'created_at'   => $mtime ? date('Y-m-d H:i:s', $mtime) : current_time('mysql')
                        );
                    }
                }
            }
        }

        // Separar de forma clara el backup más reciente de base de datos y de archivos
        $db_backup = null;
        $files_backup = null;

        foreach ($backups_found as $b) {
            $name_lower = strtolower($b['filename']);
            if (strpos($name_lower, 'db') !== false || substr($name_lower, -4) === '.sql' || substr($name_lower, -7) === '.sql.gz') {
                if (!$db_backup || $b['created_at'] > $db_backup['created_at']) {
                    $db_backup = $b;
                }
            } else {
                if (!$files_backup || $b['created_at'] > $files_backup['created_at']) {
                    $files_backup = $b;
                }
            }
        }

        $this->send_outbound_payload('/api/remote-callback/backups', array(
            'backups_list'  => $backups_found,
            'latest_db'     => $db_backup,
            'latest_files'  => $files_backup,
            'generated_at'  => current_time('mysql')
        ));
    }

    /**
     * Genera un enlace directo seguro para descargar el archivo eludiendo el .htaccess
     */
    private function generate_secure_download_url($filename, $full_path = '') {
        $secret = get_option('controlcenter_agent_secret');
        $expires = time() + 86400; // Válido por 24 horas
        $token = hash_hmac('sha256', $filename . $expires, $secret);

        return add_query_arg(array(
            'sentinel_download' => urlencode($filename),
            'expires'           => $expires,
            'token'             => $token
        ), site_url('/'));
    }

    /**
     * Entrega el archivo mediante streaming si la solicitud tiene un token de descarga válido
     */
    public function handle_secure_download() {
        if (!isset($_GET['sentinel_download']) || !isset($_GET['token']) || !isset($_GET['expires'])) {
            return;
        }

        $filename = sanitize_text_field(urldecode($_GET['sentinel_download']));
        $expires = intval($_GET['expires']);
        $token = sanitize_text_field($_GET['token']);

        if (time() > $expires) {
            status_header(403);
            wp_die('El enlace de descarga de Sentinel ha expirado.');
        }

        $secret = get_option('controlcenter_agent_secret');
        $expected_token = hash_hmac('sha256', $filename . $expires, $secret);

        if (!hash_equals($expected_token, $token)) {
            status_header(403);
            wp_die('Firma de descarga de Sentinel inválida.');
        }

        // Buscar el archivo físico
        $found_path = null;
        $uploads = wp_upload_dir();
        $candidate_dirs = array(
            trailingslashit($uploads['basedir']) . 'sentinel-backups/db/',
            trailingslashit($uploads['basedir']) . 'sentinel-backups/files/',
            trailingslashit($uploads['basedir']) . 'sentinel-backups/temp/',
            WP_CONTENT_DIR . '/wpvividbackups/'
        );

        foreach ($candidate_dirs as $dir) {
            if (file_exists($dir . $filename)) {
                $found_path = $dir . $filename;
                break;
            }
        }

        if (!$found_path || !is_readable($found_path)) {
            status_header(404);
            wp_die('Archivo de respaldo no encontrado en el servidor.');
        }

        // Servir el archivo directamente con cabeceras de descarga binaria
        if (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($found_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($found_path));
        readfile($found_path);
        exit;
    }

    /**
     * Realiza un HTTP POST saliente autenticado hacia el Control Center
     */
    private function send_outbound_payload($endpoint_path, $data) {
        $hub_url = get_option('controlcenter_hub_url');
        if (empty($hub_url) && defined('SENTINEL_HUB_URL')) {
            $hub_url = SENTINEL_HUB_URL;
        }

        if (empty($hub_url)) {
            return false;
        }

        $hub_url = rtrim($hub_url, '/');
        $endpoint = $hub_url . $endpoint_path;

        $agent_uuid = get_option('controlcenter_agent_uuid');
        $agent_secret = get_option('controlcenter_agent_secret');

        if (empty($agent_uuid) || empty($agent_secret)) {
            return false;
        }

        $timestamp = time();
        $signature = hash_hmac('sha256', $agent_uuid . $timestamp, $agent_secret);

        $payload = array(
            'agent_uuid' => $agent_uuid,
            'timestamp'  => $timestamp,
            'signature'  => $signature,
            'site_url'   => home_url(),
            'payload'    => $data
        );

        return wp_remote_post($endpoint, array(
            'timeout'     => 30,
            'redirection' => 3,
            'httpversion' => '1.1',
            'blocking'    => false, // Asíncrono saliente
            'headers'     => array(
                'Content-Type'         => 'application/json; charset=utf-8',
                'X-Sentinel-Agent'     => $agent_uuid,
                'X-Sentinel-Signature' => $signature,
                'X-Sentinel-Timestamp' => $timestamp
            ),
            'body'        => wp_json_encode($payload),
            'sslverify'   => false
        ));
    }
}
