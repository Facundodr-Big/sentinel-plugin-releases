<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Sentinel_Snapshot_Engine {

    /**
     * Singleton instance.
     *
     * @var Sentinel_Snapshot_Engine|null
     */
    private static $instance = null;

    /**
     * Database handler instance (SQLite).
     *
     * @var Sentinel_SQLite_DB
     */
    private $sqlite_db;

    /**
     * Constructor for the Singleton pattern.
     */
    private function __construct() {
        $this->sqlite_db = Sentinel_SQLite_DB::get_instance();
    }

    /**
     * Get the instance of the class.
     *
     * @return Sentinel_Snapshot_Engine
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get the primary key column name for a given table.
     *
     * @param string $table_name The table name to check.
     * @return string|null The primary key column name, or null if not found.
     */
    public function get_primary_key($table_name) {
        global $wpdb;
        $clean_table = preg_replace('/[^a-zA-Z0-9_\-\$]/', '', $table_name);
        
        $results = $wpdb->get_results(
            $wpdb->prepare("SHOW KEYS FROM `{$clean_table}` WHERE Key_name = 'PRIMARY'", [])
        );

        if (!empty($results) && isset($results[0]->Column_name)) {
            return sanitize_text_field($results[0]->Column_name);
        }

        return null;
    }

    /**
     * Create a snapshot of the table and store chunks in SQLite.
     *
     * @param string $table_name The name of the table to snapshot.
     * @param int $chunk_size The size of each chunk.
     * @return array An array of chunks with their status.
     */
    public function create_table_snapshot($table_name, $chunk_size = 1000) {
        global $wpdb;
        
        $clean_table = preg_replace('/[^a-zA-Z0-9_\-\$]/', '', $table_name);
        $pk = $this->get_primary_key($clean_table);

        if (!$pk) {
            // If no primary key, use the first column as a secondary sort key.
            $columns = $wpdb->get_col("SHOW COLUMNS FROM `{$clean_table}`");
            if (empty($columns)) {
                return ['status' => 'EMPTY'];
            }
            $pk = sanitize_text_field(reset($columns));
        }

        // Get min and max IDs.
        $min_max = $wpdb->get_row(
            $wpdb->prepare("SELECT MIN(`{$pk}`) as min_id, MAX(`{$pk}`) as max_id FROM `{$clean_table}`", [])
        );

        if (empty($min_max) || is_null($min_max->min_id) || is_null($min_max->max_id)) {
            return ['status' => 'EMPTY'];
        }

        $chunks = [];
        $min_id = (int)$min_max->min_id;
        $max_id = (int)$min_max->max_id;

        for ($i = $min_id; $i <= $max_id; $i += $chunk_size) {
            $start_id = $i;
            $end_id = $i + $chunk_size;

            // Fetch the chunk using correct WordPress prepare placeholders (%d)
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM `{$clean_table}` WHERE `{$pk}` >= %d AND `{$pk}` < %d ORDER BY `{$pk}` ASC",
                    $start_id,
                    $end_id
                ),
                ARRAY_A
            );

            if (!empty($rows)) {
                // Serialize and hash the chunk.
                $json_data = json_encode($rows);
                $hash = hash('sha256', $json_data);
                $chunk_key = "{$start_id}_{$end_id}";

                // Check SQLite for existing chunk using direct queries.
                $existing = $this->sqlite_db->query_files(
                    "SELECT hash FROM db_chunks WHERE table_name = :table AND chunk_key = :key LIMIT 1",
                    array('table' => $clean_table, 'key' => $chunk_key)
                );

                if (empty($existing)) {
                    // New chunk.
                    $this->sqlite_db->query_files(
                        "INSERT INTO db_chunks (table_name, chunk_key, hash, last_seen) VALUES (:table, :key, :hash, :now)",
                        array(
                            'table' => $clean_table,
                            'key'   => $chunk_key,
                            'hash'  => $hash,
                            'now'   => time()
                        )
                    );
                    $chunks[] = [
                        'status'    => 'NEW',
                        'chunk_key' => $chunk_key,
                        'hash'      => $hash,
                        'data'      => $rows
                    ];
                } else {
                    $db_hash = $existing[0]['hash'];
                    if ($db_hash === $hash) {
                        // Known chunk (unchanged).
                        $this->sqlite_db->query_files(
                            "UPDATE db_chunks SET last_seen = :now WHERE table_name = :table AND chunk_key = :key",
                            array(
                                'table' => $clean_table,
                                'key'   => $chunk_key,
                                'now'   => time()
                            )
                        );
                        $chunks[] = [
                            'status'    => 'KNOWN',
                            'chunk_key' => $chunk_key,
                            'hash'      => $db_hash
                        ];
                    } else {
                        // Modified chunk.
                        $this->sqlite_db->query_files(
                            "UPDATE db_chunks SET hash = :hash, last_seen = :now WHERE table_name = :table AND chunk_key = :key",
                            array(
                                'hash'  => $hash,
                                'table' => $clean_table,
                                'key'   => $chunk_key,
                                'now'   => time()
                            )
                        );
                        $chunks[] = [
                            'status'    => 'MODIFIED',
                            'chunk_key' => $chunk_key,
                            'hash'      => $hash,
                            'data'      => $rows
                        ];
                    }
                }
            }
        }

        return $chunks;
    }
}