<?php
/**
 * Class Sentinel_Fingerprint_Generator
 *
 * Generates a fingerprint for a given directory by scanning its files and calculating their SHA256 hashes.
 */
class Sentinel_Fingerprint_Generator {

    /**
     * The singleton instance of the class.
     *
     * @var Sentinel_Fingerprint_Generator|null
     */
    private static $instance = null;

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private function __construct() {}

    /**
     * Private clone method to prevent cloning of the instance.
     */
    private function __clone() {}

    /**
     * Returns the singleton instance of the class.
     *
     * @return Sentinel_Fingerprint_Generator
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Generates a fingerprint for the given directory path.
     *
     * @param string $dir_path The absolute path to the directory.
     * @return array|null An associative array with 'fingerprint' and 'files', or null if the directory is invalid.
     */
    public function generate_fingerprint( $dir_path ) {
        $dir_path = str_replace('\\', '/', trim( $dir_path ) );

        if ( ! is_dir( $dir_path ) || ! file_exists( $dir_path ) ) {
            return null;
        }

        $ignore_dirs = [ '.git', 'node_modules', '.venv', 'wp-content/controlcenter' ];
        $files_info = [];

        // Scan the directory recursively passing $dir_path as the base path
        $this->scan_directory( $dir_path, $dir_path, $ignore_dirs, $files_info );

        // Sort the files by relative path
        ksort( $files_info );

        // Concatenate all hashes to create a global hash
        $global_hash_data = '';
        foreach ( $files_info as $relative_path => $sha256 ) {
            $global_hash_data .= $relative_path . ':' . $sha256;
        }

        // Calculate the final SHA256 hash
        $fingerprint = hash( 'sha256', $global_hash_data );

        return [
            'fingerprint' => $fingerprint,
            'files'       => $files_info,
        ];
    }

    /**
     * Recursively scans a directory and collects file paths and their SHA256 hashes.
     *
     * @param string $dir_path The absolute path to the current directory.
     * @param string $base_path The absolute path to the root directory of the scan.
     * @param array  $ignore_dirs Directories to ignore during scanning.
     * @param array  &$files_info Reference to an array where files information will be stored.
     */
    private function scan_directory( $dir_path, $base_path, $ignore_dirs, &$files_info ) {
        if ( ! $handle = opendir( $dir_path ) ) {
            return;
        }

        while ( false !== ( $entry = readdir( $handle ) ) ) {
            if ( '.' === $entry || '..' === $entry ) {
                continue;
            }

            $full_path = rtrim($dir_path, '/') . '/' . $entry;
            $normalized_path = str_replace('\\', '/', $full_path);

            if ( is_dir( $normalized_path ) ) {
                // Check if directory should be ignored
                $should_ignore = false;
                foreach ($ignore_dirs as $ignore) {
                    if (strpos($normalized_path, $ignore) !== false) {
                        $should_ignore = true;
                        break;
                    }
                }
                if ($should_ignore) {
                    continue;
                }
                $this->scan_directory( $normalized_path, $base_path, $ignore_dirs, $files_info );
            } else {
                // Calculate the relative path from the base path root
                $relative_path = ltrim(str_replace($base_path, '', $normalized_path), '/');
                $sha256 = @hash_file( 'sha256', $normalized_path );
                if ($sha256 !== false) {
                    $files_info[ $relative_path ] = $sha256;
                }
            }
        }

        closedir( $handle );
    }
}