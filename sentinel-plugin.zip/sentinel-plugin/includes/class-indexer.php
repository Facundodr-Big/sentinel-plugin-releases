<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Sentinel_Indexer class to handle file indexing and scanning.
 */
class Sentinel_Indexer {

    /**
     * Singleton instance of the class.
     *
     * @var Sentinel_Indexer|null
     */
    private static $instance = null;

    /**
     * Database handler instance.
     *
     * @var Sentinel_SQLite_DB
     */
    private $db;

    /**
     * Get the singleton instance of Sentinel_Indexer.
     *
     * @return Sentinel_Indexer
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside.
     */
    private function __construct() {
        $this->db = Sentinel_SQLite_DB::get_instance();
        $this->initialize_database();
    }

    /**
     * Initialize the database tables if they don't exist.
     */
    private function initialize_database() {
        $this->db->query_files("CREATE TABLE IF NOT EXISTS scan_queue (
            path TEXT UNIQUE
        )");
        
        $this->db->query_files("CREATE TABLE IF NOT EXISTS scan_state (
            key TEXT UNIQUE,
            value TEXT
        )");
    }

    /**
     * Get or set current scan start time.
     */
    private function get_or_set_scan_start_time() {
        $result = $this->db->query_files("SELECT value FROM scan_state WHERE key = 'scan_start_time' LIMIT 1");
        if (!empty($result)) {
            return (int) $result[0]['value'];
        }
        
        $now = time();
        $this->db->query_files("INSERT OR REPLACE INTO scan_state (key, value) VALUES ('scan_start_time', :value)", ['value' => (string)$now]);
        return $now;
    }

    /**
     * Clear scan session state.
     */
    private function clear_scan_state() {
        $this->db->query_files("DELETE FROM scan_state WHERE key = 'scan_start_time'");
        $this->db->query_files("DELETE FROM scan_queue");
    }

    /**
     * Check if there is an active scan.
     *
     * @return bool
     */
    public function is_scan_active() {
        $result = $this->db->query_files("SELECT value FROM scan_state WHERE key = 'scan_start_time' LIMIT 1");
        return !empty($result);
    }

    /**
     * Build the index by scanning files and directories.
     *
     * @param int $limit Maximum number of files to process in one batch.
     * @return string Status of the scan ('PENDING', 'COMPLETED').
     */
    public function build_index($limit = 500) {
        $scan_start = $this->get_or_set_scan_start_time();

        // Check if scan queue is empty to initialize
        $queue_count_res = $this->db->query_files("SELECT COUNT(*) as count FROM scan_queue");
        $queue_count = !empty($queue_count_res) ? (int)$queue_count_res[0]['count'] : 0;

        if ($queue_count === 0) {
            $this->db->query_files("INSERT OR IGNORE INTO scan_queue (path) VALUES (:path)", ['path' => ABSPATH]);
            error_log('Sentinel Indexer: Scan started for directory ' . ABSPATH);
        }

        $processed_files = 0;
        
        // Excluded folders relative path parts or base names
        $exclude_folders = array(
            'node_modules', 
            '.git', 
            '.venv', 
            '__pycache__', 
            'sentinel-backups'
        );

        while (true) {
            // Get one directory to process
            $queue_item = $this->db->query_files("SELECT path FROM scan_queue LIMIT 1");
            if (empty($queue_item)) {
                break;
            }
            
            $directory = $queue_item[0]['path'];
            $this->db->query_files("DELETE FROM scan_queue WHERE path = :path", ['path' => $directory]);

            if (!is_dir($directory)) {
                continue;
            }

            // Skip target system folders to prevent infinite loops/redundancy
            if (strpos($directory, WP_CONTENT_DIR . '/controlcenter') !== false) {
                continue;
            }

            $items = @scandir($directory);
            if (!is_array($items)) {
                continue;
            }

            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }

                if (in_array($item, $exclude_folders)) {
                    continue;
                }

                $full_path = rtrim($directory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $item;

                if (is_dir($full_path)) {
                    $this->db->query_files("INSERT OR IGNORE INTO scan_queue (path) VALUES (:path)", ['path' => $full_path]);
                } elseif (is_file($full_path)) {
                    $this->process_file($full_path, $scan_start);
                    $processed_files++;
                    
                    if ($processed_files >= $limit) {
                        return 'PENDING';
                    }
                }
            }
        }

        // Scan completed. Mark remaining unscanned files as DELETED
        $this->db->query_files(
            "UPDATE files SET status = 'DELETED' WHERE last_scan < :scan_start AND status != 'DELETED'", 
            ['scan_start' => $scan_start]
        );
        
        // Clean up session state
        $this->clear_scan_state();
        error_log('Sentinel Indexer: Scan completed.');
        return 'COMPLETED';
    }

    /**
     * Process a single file.
     *
     * @param string $file_path Full path to the file.
     * @param int    $scan_start Scan start timestamp.
     */
    private function process_file($file_path, $scan_start) {
        $size = @filesize($file_path);
        $mtime = @filemtime($file_path);
        
        if ($size === false || $mtime === false) {
            return;
        }

        // Consult if file is already in files table
        $existing = $this->db->query_files("SELECT size, mtime, hash FROM files WHERE path = :path LIMIT 1", ['path' => $file_path]);

        // Auto classify logic instance
        $classifier = Sentinel_File_Classification::get_instance();
        $classification = $classifier->classify_path($file_path);

        if (!empty($existing)) {
            $db_size = (int)$existing[0]['size'];
            $db_mtime = (int)$existing[0]['mtime'];
            $db_hash = $existing[0]['hash'];

            if ($size === $db_size && $mtime === $db_mtime) {
                // No changes, just update last_scan and status
                $this->db->query_files(
                    "UPDATE files SET last_scan = :now, status = 'KNOWN', last_seen = :now, classification = :class WHERE path = :path",
                    ['now' => time(), 'path' => $file_path, 'class' => $classification]
                );
            } else {
                // Recalculate hash because size or mtime changed
                $hash = @hash_file('sha256', $file_path);
                if ($hash !== false) {
                    $status = ($hash === $db_hash) ? 'KNOWN' : 'MODIFIED';
                    $this->db->query_files(
                        "UPDATE files SET size = :size, mtime = :mtime, hash = :hash, last_scan = :now, status = :status, last_seen = :now, classification = :class WHERE path = :path",
                        [
                            'size' => $size,
                            'mtime' => $mtime,
                            'hash' => $hash,
                            'now' => time(),
                            'status' => $status,
                            'path' => $file_path,
                            'class' => $classification
                        ]
                    );
                }
            }
        } else {
            // New file
            $hash = @hash_file('sha256', $file_path);
            if ($hash !== false) {
                $this->db->query_files(
                    "INSERT INTO files (path, size, mtime, hash, status, last_scan, first_seen, last_seen, classification) VALUES (:path, :size, :mtime, :hash, 'NEW', :now, :now, :now, :class)",
                    [
                        'path' => $file_path,
                        'size' => $size,
                        'mtime' => $mtime,
                        'hash' => $hash,
                        'now' => time(),
                        'class' => $classification
                    ]
                );
            }
        }
    }

    /**
     * Get the status of the current scan.
     *
     * @return string Status of the scan ('ACTIVE', 'COMPLETED').
     */
    public function get_scan_status() {
        return $this->is_scan_active() ? 'ACTIVE' : 'COMPLETED';
    }

    /**
     * Get detected changes.
     *
     * @return array Array of files with changes.
     */
    public function get_detected_changes() {
        return $this->db->query_files("SELECT path, size, mtime, hash, status, classification FROM files WHERE status IN ('NEW', 'MODIFIED', 'DELETED')");
    }
}