<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Sentinel_Indexer class to handle file indexing and scanning.
 */
class Sentinel_Indexer {

    /**
     * Singleton instance of the class.
     *
     * @var Sentinel_Indexer|null
     */
    private static $instance = null;

    /**
     * Database handler instance.
     *
     * @var Sentinel_SQLite_DB
     */
    private $db;

    /**
     * Get the singleton instance of Sentinel_Indexer.
     *
     * @return Sentinel_Indexer
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent instantiation from outside.
     */
    private function __construct() {
        $this->db = Sentinel_SQLite_DB::get_instance();
        $this->initialize_database();
    }

    /**
     * Initialize the database tables if they don't exist.
     */
    private function initialize_database() {
        $this->db->query_files("CREATE TABLE IF NOT EXISTS scan_queue (
            path TEXT UNIQUE,
            offset INTEGER DEFAULT 0
        )");
        
        // Ensure offset column exists for backward compatibility
        $columns = $this->db->query_files("PRAGMA table_info(scan_queue)");
        if (is_array($columns)) {
            $column_names = array_column($columns, 'name');
            if (!in_array('offset', $column_names)) {
                $this->db->query_files("ALTER TABLE scan_queue ADD COLUMN offset INTEGER DEFAULT 0");
            }
        }
        
        $this->db->query_files("CREATE TABLE IF NOT EXISTS scan_state (
            key TEXT UNIQUE,
            value TEXT
        )");
    }

    /**
     * Get or set current scan start time.
     */
    private function get_or_set_scan_start_time() {
        $result = $this->db->query_files("SELECT value FROM scan_state WHERE key = 'scan_start_time' LIMIT 1");
        if (!empty($result)) {
            return (int) $result[0]['value'];
        }
        
        $now = time();
        $this->db->query_files("INSERT OR REPLACE INTO scan_state (key, value) VALUES ('scan_start_time', :value)", ['value' => (string)$now]);
        return $now;
    }

    /**
     * Clear scan session state.
     */
    private function clear_scan_state() {
        $this->db->query_files("DELETE FROM scan_state WHERE key = 'scan_start_time'");
        $this->db->query_files("DELETE FROM scan_queue");
    }

    /**
     * Check if there is an active scan.
     *
     * @return bool
     */
    public function is_scan_active() {
        $result = $this->db->query_files("SELECT value FROM scan_state WHERE key = 'scan_start_time' LIMIT 1");
        return !empty($result);
    }

    /**
     * Build the index by scanning files and directories.
     *
     * @param int $limit Maximum number of files to process in one batch.
     * @return string Status of the scan ('PENDING', 'COMPLETED').
     */
    public function build_index($limit = 300) {
        @set_time_limit(60);
        @ini_set('memory_limit', '256M');

        $start_time = microtime(true);
        $max_execution_seconds = 15; // Límite de tiempo máximo seguro (15s) para prevenir fatal errors de timeout en hostings compartidos

        $scan_start = $this->get_or_set_scan_start_time();

        // Check if scan queue is empty to initialize
        $queue_count_res = $this->db->query_files("SELECT COUNT(*) as count FROM scan_queue");
        $queue_count = !empty($queue_count_res) ? (int)$queue_count_res[0]['count'] : 0;

        if ($queue_count === 0) {
            $this->db->query_files("INSERT OR IGNORE INTO scan_queue (path, offset) VALUES (:path, 0)", ['path' => ABSPATH]);
            error_log('Sentinel Indexer: Scan started for directory ' . ABSPATH);
        }

        $processed_files = 0;
        
        // Excluded folders relative path parts or base names
        $exclude_folders = array(
            'node_modules', 
            '.git', 
            '.venv', 
            '__pycache__',
            'wphb-cache',
            'cache',
            'wp-rocket',
            'et-cache',
            'updraft'
        );

        $real_abspath = rtrim(realpath(ABSPATH), '/\\');

        while (true) {
            // Verificar tiempo de ejecución acumulado antes de procesar el siguiente directorio
            if ((microtime(true) - $start_time) >= $max_execution_seconds) {
                return 'PENDING';
            }

            // Get one directory to process
            $queue_item = $this->db->query_files("SELECT path, offset FROM scan_queue LIMIT 1");
            if (empty($queue_item)) {
                break;
            }
            
            $directory = $queue_item[0]['path'];
            $offset = isset($queue_item[0]['offset']) ? intval($queue_item[0]['offset']) : 0;

            if (!is_dir($directory)) {
                $this->db->query_files("DELETE FROM scan_queue WHERE path = :path", ['path' => $directory]);
                continue;
            }

            // Skip target system folders to prevent infinite loops/redundancy
            if (strpos($directory, WP_CONTENT_DIR . '/controlcenter') !== false) {
                $this->db->query_files("DELETE FROM scan_queue WHERE path = :path", ['path' => $directory]);
                continue;
            }

            $items = @scandir($directory);
            if (!is_array($items)) {
                $this->db->query_files("DELETE FROM scan_queue WHERE path = :path", ['path' => $directory]);
                continue;
            }

            // Filter out . and .. and excluded folders, but keep them in deterministic order
            $files_and_dirs = [];
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                if (in_array($item, $exclude_folders)) {
                    continue;
                }
                $files_and_dirs[] = $item;
            }

            $total_items = count($files_and_dirs);
            $limit_reached = false;
            $local_offset = 0;

            for ($i = $offset; $i < $total_items; $i++) {
                // Control de tiempo por cada elemento iterado en el directorio
                if ((microtime(true) - $start_time) >= $max_execution_seconds) {
                    $limit_reached = true;
                    $local_offset = $i;
                    break;
                }

                $item = $files_and_dirs[$i];
                $full_path = rtrim($directory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $item;

                if (is_dir($full_path)) {
                    // Prevenir escaneo de carpetas internas de Sentinel
                    if (strpos($full_path, WP_CONTENT_DIR . '/controlcenter') !== false) {
                        continue;
                    }

                    // Prevenir escaneo de otros sitios o subdominios alojados en subcarpetas
                    if ($this->is_foreign_site_directory($full_path, $real_abspath)) {
                        continue;
                    }

                    $this->db->query_files("INSERT OR IGNORE INTO scan_queue (path, offset) VALUES (:path, 0)", ['path' => $full_path]);
                } elseif (is_file($full_path)) {
                    $this->process_file($full_path, $scan_start);
                    $processed_files++;
                    
                    if ($processed_files % 100 === 0) {
                        @usleep(5000); // 5ms micro-pausa cada 100 archivos para evitar sobrecargas de I/O en hosting compartido
                    }

                    if ($processed_files >= $limit) {
                        $limit_reached = true;
                        $local_offset = $i + 1;
                        break;
                    }
                }
            }

            if ($limit_reached) {
                // Update offset for this directory and pause
                $this->db->query_files(
                    "UPDATE scan_queue SET offset = :offset WHERE path = :path",
                    ['offset' => $local_offset, 'path' => $directory]
                );
                return 'PENDING';
            } else {
                // Fully processed, delete from queue
                $this->db->query_files("DELETE FROM scan_queue WHERE path = :path", ['path' => $directory]);
            }
        }

        // Scan completed. Mark remaining unscanned files as DELETED
        $this->db->query_files(
            "UPDATE files SET status = 'DELETED' WHERE last_scan < :scan_start AND status != 'DELETED'", 
            ['scan_start' => $scan_start]
        );
        
        // Clean up session state
        $this->clear_scan_state();
        error_log('Sentinel Indexer: Scan completed.');
        return 'COMPLETED';
    }

    /**
     * Process a single file.
     *
     * @param string $file_path Full path to the file.
     * @param int    $scan_start Scan start timestamp.
     */
    private function process_file($file_path, $scan_start) {
        $size = @filesize($file_path);
        $mtime = @filemtime($file_path);
        
        if ($size === false || $mtime === false) {
            return;
        }

        // Consult if file is already in files table
        $existing = $this->db->query_files("SELECT size, mtime, hash FROM files WHERE path = :path LIMIT 1", ['path' => $file_path]);

        // Auto classify logic instance
        $classifier = Sentinel_File_Classification::get_instance();
        $classification = $classifier->classify_path($file_path);

        // Generar hash o fallback ligero para archivos pesados (>50MB) para evitar consumo excesivo de I/O / CPU
        $calculate_hash = function($path, $sz, $mt) {
            if ($sz > 50 * 1024 * 1024) {
                return 'large_' . md5($path . '_' . $sz . '_' . $mt);
            }
            return @hash_file('sha256', $path);
        };

        if (!empty($existing)) {
            $db_size = (int)$existing[0]['size'];
            $db_mtime = (int)$existing[0]['mtime'];
            $db_hash = $existing[0]['hash'];

            if ($size === $db_size && $mtime === $db_mtime) {
                // No changes, just update last_scan and status
                $this->db->query_files(
                    "UPDATE files SET last_scan = :now, status = 'KNOWN', last_seen = :now, classification = :class WHERE path = :path",
                    ['now' => time(), 'path' => $file_path, 'class' => $classification]
                );
            } else {
                // Recalculate hash because size or mtime changed
                $hash = $calculate_hash($file_path, $size, $mtime);
                if ($hash !== false) {
                    $status = ($hash === $db_hash) ? 'KNOWN' : 'MODIFIED';
                    $this->db->query_files(
                        "UPDATE files SET size = :size, mtime = :mtime, hash = :hash, last_scan = :now, status = :status, last_seen = :now, classification = :class WHERE path = :path",
                        [
                            'size' => $size,
                            'mtime' => $mtime,
                            'hash' => $hash,
                            'now' => time(),
                            'status' => $status,
                            'path' => $file_path,
                            'class' => $classification
                        ]
                    );
                }
            }
        } else {
            // New file
            $hash = $calculate_hash($file_path, $size, $mtime);
            if ($hash !== false) {
                $this->db->query_files(
                    "INSERT INTO files (path, size, mtime, hash, status, last_scan, first_seen, last_seen, classification) VALUES (:path, :size, :mtime, :hash, 'NEW', :now, :now, :now, :class)",
                    [
                        'path' => $file_path,
                        'size' => $size,
                        'mtime' => $mtime,
                        'hash' => $hash,
                        'now' => time(),
                        'class' => $classification
                    ]
                );
            }
        }
    }

    /**
     * Get the status of the current scan.
     *
     * @return string Status of the scan ('ACTIVE', 'COMPLETED').
     */
    public function get_scan_status() {
        return $this->is_scan_active() ? 'ACTIVE' : 'COMPLETED';
    }

    /**
     * Get detected changes.
     *
     * @return array Array of files with changes.
     */
    public function get_detected_changes() {
        return $this->db->query_files("SELECT path, size, mtime, hash, status, classification FROM files WHERE status IN ('NEW', 'MODIFIED', 'DELETED')");
    }

    /**
     * Detecta si un subdirectorio pertenece a una instalación de WordPress o subdominio independiente.
     *
     * @param string $full_path Ruta completa del directorio a verificar.
     * @param string $root_abspath Ruta canónica del ABSPATH actual.
     * @return bool True si debe ser omitido por ser un sitio ajeno/subdominio.
     */
    public function is_foreign_site_directory($full_path, $root_abspath = '') {
        if (empty($root_abspath)) {
            $root_abspath = rtrim(realpath(ABSPATH), '/\\');
        }
        $real_fullpath = rtrim(realpath($full_path), '/\\');
        if (!$real_fullpath || $real_fullpath === $root_abspath) {
            return false;
        }

        // 1. Si la subcarpeta contiene su propio wp-config.php o wp-load.php fuera de la raíz principal
        if (@file_exists($full_path . '/wp-config.php') || @file_exists($full_path . '/wp-load.php')) {
            error_log('Sentinel Indexer: Omitiendo sub-sitio/WordPress ajeno en: ' . $full_path);
            return true;
        }

        // 2. Si contiene carpetas típicas de WordPress anidadas (wp-includes y wp-content o wp-admin)
        if (@is_dir($full_path . '/wp-includes') && (@is_dir($full_path . '/wp-content') || @is_dir($full_path . '/wp-admin'))) {
            error_log('Sentinel Indexer: Omitiendo sub-sitio/WordPress anidado en: ' . $full_path);
            return true;
        }

        // 3. Si el nombre de la carpeta tiene formato de dominio (ej: services.bodyrejuvenationmd.com o dominio.com)
        $folder_basename = strtolower(basename($full_path));
        if (preg_match('/\.(com|net|org|co|info|biz|us|io|store|dev|app|site|agency|online|tech|edu|gov|ar|mx|es|br|cl|co)$/i', $folder_basename)) {
            if (@file_exists($full_path . '/wp-content') || @file_exists($full_path . '/index.php')) {
                error_log('Sentinel Indexer: Omitiendo carpeta con nombre de dominio/subdominio: ' . $full_path);
                return true;
            }
        }

        // 4. Si contiene un .htaccess con RewriteBase apuntando al subdominio/subdirectorio
        $sub_htaccess = $full_path . '/.htaccess';
        if (@file_exists($sub_htaccess)) {
            $htaccess_sample = @file_get_contents($sub_htaccess, false, null, 0, 1024);
            if ($htaccess_sample && (stripos($htaccess_sample, 'WordPress') !== false || stripos($htaccess_sample, 'RewriteBase /' . $folder_basename) !== false)) {
                if (@file_exists($full_path . '/index.php')) {
                    error_log('Sentinel Indexer: Omitiendo sub-sitio detectado por .htaccess en: ' . $full_path);
                    return true;
                }
            }
        }

        return false;
    }
}