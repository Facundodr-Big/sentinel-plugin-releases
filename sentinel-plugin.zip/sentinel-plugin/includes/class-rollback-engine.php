<?php
if (!defined('ABSPATH')) {
    exit; // Evita el acceso directo al archivo
}

class Sentinel_Rollback_Engine {

    private static $instance = null;
    private $recovery_dir;

    private function __construct() {
        $this->recovery_dir = WP_CONTENT_DIR . '/controlcenter/recovery/';
        if (!file_exists($this->recovery_dir)) {
            wp_mkdir_p($this->recovery_dir);
        }
    }

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function create_pre_restore_snapshot(array $files_list) {
        $manifest = [];
        foreach ($files_list as $file_path) {
            $full_file_path = ABSPATH . $file_path;
            if (file_exists($full_file_path)) {
                $backup_file_path = $this->recovery_dir . basename($file_path) . '-' . time() . '.bak';
                if (!copy($full_file_path, $backup_file_path)) {
                    return false;
                }
                $manifest[] = [
                    'original' => $file_path,
                    'backup'   => substr($backup_file_path, strlen(ABSPATH)),
                    'timestamp' => time()
                ];
            }
        }

        $manifest_file = $this->recovery_dir . 'manifest-' . time() . '.json';
        if (file_put_contents($manifest_file, json_encode($manifest)) === false) {
            return false;
        }

        return true;
    }

    public function restore_backup_snapshot() {
        $manifest_files = glob($this->recovery_dir . 'manifest-*.json');
        if (empty($manifest_files)) {
            return ['status' => 'error', 'files_restored' => []];
        }

        usort($manifest_files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });

        $latest_manifest_file = array_shift($manifest_files);
        $manifest_content = json_decode(file_get_contents($latest_manifest_file), true);

        if (empty($manifest_content)) {
            return ['status' => 'error', 'files_restored' => []];
        }

        $restored_files = [];
        foreach ($manifest_content as $entry) {
            $original_file_path = ABSPATH . $entry['original'];
            $backup_file_path = ABSPATH . $entry['backup'];

            if (file_exists($backup_file_path)) {
                if (copy($backup_file_path, $original_file_path)) {
                    unlink($backup_file_path);
                    $restored_files[] = $entry['original'];
                }
            }
        }

        unlink($latest_manifest_file);

        return ['status' => 'success', 'files_restored' => $restored_files];
    }
}