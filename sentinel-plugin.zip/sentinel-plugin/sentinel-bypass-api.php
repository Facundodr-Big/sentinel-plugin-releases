<?php
/**
 * Sentinel Bypass API (SHORTINIT Consolidada)
 * Permite realizar backups de DB y Archivos de manera ultraligera sin levantar plugins ni temas.
 */

header('Content-Type: application/json; charset=utf-8');

// 1. Cargar WordPress en modo SHORTINIT
define('SHORTINIT', true);

// Buscar wp-load.php de forma ascendente
$wp_load_path = dirname(dirname(dirname(__DIR__))) . '/wp-load.php';
if (!file_exists($wp_load_path)) {
    $wp_load_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}
if (!file_exists($wp_load_path)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => 'No se pudo encontrar wp-load.php'));
    exit;
}

require_once($wp_load_path);

// 2. Cargar dependencias core necesarias
if (defined('ABSPATH')) {
    require_once(ABSPATH . 'wp-includes/functions.php');
    require_once(ABSPATH . 'wp-includes/formatting.php');
    require_once(ABSPATH . 'wp-includes/option.php');
}

// 3. Autenticación
global $wpdb;
$agent_secret = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'controlcenter_agent_secret'");
if (!$agent_secret) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'Sentinel no configurado.'));
    exit;
}

// Decodificar JSON crudo si viene en el cuerpo
$input_raw = file_get_contents('php://input');
$json_params = json_decode($input_raw, true);
if (is_array($json_params)) {
    $_REQUEST = array_merge($_REQUEST, $json_params);
}

$agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? $_SERVER['HTTP_X_AGENT_ID'] : '';
$timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
$signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? $_SERVER['HTTP_X_SIGNATURE'] : '';

$auth_ok = false;

// Validar HMAC
if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
    $current_time = time();
    if (abs($current_time - $timestamp) <= 300) {
        $data_to_sign = $agent_id . $timestamp;
        $expected_signature = hash_hmac('sha256', $data_to_sign, $agent_secret);
        if (hash_equals($expected_signature, $signature)) {
            $auth_ok = true;
        }
    }
}

// Validar Token/API Key
if (!$auth_ok) {
    $client_key = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
        if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
            $client_key = trim($matches[1]);
        }
    } elseif (isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
        $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
    } elseif (isset($_REQUEST['sentinel_key'])) {
        $client_key = trim($_REQUEST['sentinel_key']);
    }

    if (!empty($client_key) && hash_equals($agent_secret, $client_key)) {
        $auth_ok = true;
    }
}

if (!$auth_ok) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'No autorizado.'));
    exit;
}

$action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : '';

// 4. Enrutar acciones
if (in_array($action, array('start', 'step', 'finish'))) {
    $backup_db_path = dirname(__FILE__) . '/includes/class-backup-db.php';
    if (!file_exists($backup_db_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-db.php no encontrada.'));
        exit;
    }
    require_once($backup_db_path);
    $backup_db = new Sentinel_Backup_DB();

    if ($action === 'start') {
        echo json_encode($backup_db->start_chunk_backup());
    } elseif ($action === 'step') {
        $table = isset($_REQUEST['table']) ? sanitize_text_field($_REQUEST['table']) : '';
        $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
        $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 1000;
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        $write_structure = isset($_REQUEST['write_structure']) ? (bool)$_REQUEST['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.'));
            exit;
        }
        echo json_encode($backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure));
    } elseif ($action === 'finish') {
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        if (empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetro "backup_name" requerido.'));
            exit;
        }
        echo json_encode($backup_db->finish_chunk_backup($backup_name));
    }
} elseif ($action === 'files_incremental') {
    $backup_files_path = dirname(__FILE__) . '/includes/class-backup-files.php';
    if (!file_exists($backup_files_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-files.php no encontrada.'));
        exit;
    }
    require_once($backup_files_path);

    $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
    $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 500;
    $type = isset($_REQUEST['type']) ? sanitize_text_field($_REQUEST['type']) : 'auto';
    $format = isset($_REQUEST['format']) ? sanitize_text_field($_REQUEST['format']) : 'zip';
    $excluded_files = array();
    if (isset($_REQUEST['excluded_files']) && is_array($_REQUEST['excluded_files'])) {
        $excluded_files = array_map('sanitize_text_field', $_REQUEST['excluded_files']);
    }

    $backup_files = new Sentinel_Backup_Files();
    echo json_encode($backup_files->run_backup($offset, $limit, $type, $excluded_files, $format));
} elseif ($action === 'status' || $action === 'site_info') {
    global $wpdb;
    
    $wp_version = '6.5';
    $version_file = ABSPATH . 'wp-includes/version.php';
    if (file_exists($version_file)) {
        include($version_file);
        if (isset($wp_version)) {
            $wp_version = $wp_version;
        }
    }
    
    $blogname = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'blogname'");
    $siteurl = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl'");
    
    $active_plugins_raw = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'");
    $active_plugins_arr = !empty($active_plugins_raw) ? @unserialize($active_plugins_raw) : array();
    if (!is_array($active_plugins_arr)) { $active_plugins_arr = array(); }
    
    $plugins_dir = WP_CONTENT_DIR . '/plugins';
    $plugins_list = array();
    $total_plugins = 0;
    
    if (is_dir($plugins_dir)) {
        $files = scandir($plugins_dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $full_p = $plugins_dir . '/' . $file;
            $main_php = '';
            if (is_dir($full_p)) {
                $subfiles = glob($full_p . '/*.php');
                if ($subfiles) {
                    foreach ($subfiles as $sf) {
                        $c = file_get_contents($sf, false, null, 0, 1024);
                        if (strpos($c, 'Plugin Name:') !== false) {
                            $main_php = $sf;
                            break;
                        }
                    }
                }
            } elseif (is_file($full_p) && strpos($file, '.php') !== false) {
                $main_php = $full_p;
            }
            
            if ($main_php && file_exists($main_php)) {
                $c = file_get_contents($main_php, false, null, 0, 2048);
                preg_match('/Plugin Name:\s*(.*)$/mi', $c, $m_name);
                preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);
                
                $p_name = !empty($m_name[1]) ? trim($m_name[1]) : basename($main_php);
                $p_ver = !empty($m_ver[1]) ? trim($m_ver[1]) : '1.0.0';
                
                $rel_path = str_replace($plugins_dir . '/', '', $main_php);
                $is_active = in_array($rel_path, $active_plugins_arr);
                
                $plugins_list[] = array(
                    'name' => $p_name,
                    'version' => $p_ver,
                    'active' => (bool)$is_active,
                    'file' => $rel_path
                );
                $total_plugins++;
            }
        }
    }
    
    $sentinel_ver = '2.7.66';
    $sentinel_main = dirname(__FILE__) . '/sentinel.php';
    if (file_exists($sentinel_main)) {
        $c = file_get_contents($sentinel_main, false, null, 0, 1024);
        preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);
        if (!empty($m_ver[1])) {
            $sentinel_ver = trim($m_ver[1]);
        }
    }
    
    $wpvivid_installed = is_dir(WP_CONTENT_DIR . '/plugins/wpvivid');
    $wpvivid_active = false;
    if ($wpvivid_installed) {
        foreach ($active_plugins_arr as $ap) {
            if (strpos($ap, 'wpvivid') !== false) {
                $wpvivid_active = true;
                break;
            }
        }
    }
    
    $db_size_bytes = 0;
    $db_data_size_bytes = 0;
    $db_index_size_bytes = 0;
    try {
        $db_status = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);
        if ($db_status) {
            foreach ($db_status as $row) {
                $data_len = isset($row['Data_length']) ? intval($row['Data_length']) : 0;
                $idx_len = isset($row['Index_length']) ? intval($row['Index_length']) : 0;
                $db_data_size_bytes += $data_len;
                $db_index_size_bytes += $idx_len;
                $db_size_bytes += ($data_len + $idx_len);
            }
        }
    } catch (Exception $e) {}

    echo json_encode(array(
        'status' => 'online',
        'site_name' => $blogname ? $blogname : 'Sitio WordPress',
        'site_url' => $siteurl,
        'wordpress' => $wp_version,
        'php' => PHP_VERSION,
        'mysql' => $wpdb->db_version(),
        'sentinel_version' => $sentinel_ver,
        'total_plugins' => $total_plugins,
        'pending_updates' => 0,
        'plugins' => $plugins_list,
        'themes' => array(),
        'wpvivid_installed' => $wpvivid_installed,
        'wpvivid_active' => $wpvivid_active,
        'db_size_bytes' => $db_size_bytes,
        'db_data_size_bytes' => $db_data_size_bytes,
        'db_index_size_bytes' => $db_index_size_bytes,
        'uploads_size_bytes' => 0,
        'shortinit_bypass' => true,
        'waf_bypassed' => true
    ));
    exit;

} elseif ($action === 'emergency_deactivate_plugins') {
    $active_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'active_plugins'");
    $active_plugins = maybe_unserialize($active_raw);
    if (!is_array($active_plugins)) {
        $active_plugins = array();
    }
    
    // Guardar copia de respaldo de los plugins activos
    $wpdb->query($wpdb->prepare(
        "REPLACE INTO $wpdb->options (option_name, option_value, autoload) VALUES ('_sentinel_backup_plugins', %s, 'no')",
        maybe_serialize($active_plugins)
    ));
    
    // Filtrar para mantener SOLO Sentinel activo
    $sentinel_active = array();
    foreach ($active_plugins as $p) {
        if (strpos($p, 'sentinel') !== false) {
            $sentinel_active[] = $p;
        }
    }
    if (empty($sentinel_active)) {
        $sentinel_active[] = 'sentinel-plugin/sentinel.php';
    }
    
    $wpdb->query($wpdb->prepare(
        "UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'active_plugins'",
        maybe_serialize($sentinel_active)
    ));
    
    echo json_encode(array(
        'success' => true,
        'message' => 'Modo Seguro activado: Todos los plugins de terceros fueron desactivados. Sentinel permanece activo.',
        'deactivated_count' => count($active_plugins) - count($sentinel_active),
        'saved_backup' => true
    ));
    exit;

} elseif ($action === 'emergency_restore_plugins') {
    $backup_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = '_sentinel_backup_plugins'");
    if (!$backup_raw) {
        echo json_encode(array('success' => false, 'message' => 'No se encontró un respaldo previo de plugins activos.'));
        exit;
    }
    
    $backup_plugins = maybe_unserialize($backup_raw);
    if (!is_array($backup_plugins)) {
        echo json_encode(array('success' => false, 'message' => 'El respaldo de plugins está corrupto o vacío.'));
        exit;
    }
    
    $wpdb->query($wpdb->prepare(
        "UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'active_plugins'",
        maybe_serialize($backup_plugins)
    ));
    
    echo json_encode(array(
        'success' => true,
        'message' => 'Plugins reactivados con éxito (' . count($backup_plugins) . ' plugins restaurados).',
        'restored_count' => count($backup_plugins)
    ));
    exit;

} elseif ($action === 'emergency_toggle_debug') {
    $wp_config_path = ABSPATH . 'wp-config.php';
    if (!file_exists($wp_config_path)) {
        $wp_config_path = dirname(ABSPATH) . '/wp-config.php';
    }
    if (!file_exists($wp_config_path) || !is_writable($wp_config_path)) {
        echo json_encode(array('success' => false, 'message' => 'El archivo wp-config.php no existe o no tiene permisos de escritura.'));
        exit;
    }
    
    $config_content = file_get_contents($wp_config_path);
    $is_currently_debug = (bool)preg_match("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\)/i", $config_content);
    $new_debug_state = !$is_currently_debug;
    
    if ($new_debug_state) {
        if (preg_match("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*[^)]+\s*\);/i", $config_content)) {
            $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*[^)]+\s*\);/i", "define('WP_DEBUG', true);", $config_content);
        } else {
            $config_content = preg_replace("/(<\?php)/i", "$1\ndefine('WP_DEBUG', true);", $config_content, 1);
        }
        
        if (preg_match("/define\s*\(\s*['\"]WP_DEBUG_LOG['\"]\s*,\s*[^)]+\s*\);/i", $config_content)) {
            $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG_LOG['\"]\s*,\s*[^)]+\s*\);/i", "define('WP_DEBUG_LOG', true);", $config_content);
        } else {
            $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\);/i", "define('WP_DEBUG', true);\ndefine('WP_DEBUG_LOG', true);", $config_content);
        }
    } else {
        $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*[^)]+\s*\);/i", "define('WP_DEBUG', false);", $config_content);
        $config_content = preg_replace("/define\s*\(\s*['\"]WP_DEBUG_LOG['\"]\s*,\s*[^)]+\s*\);/i", "define('WP_DEBUG_LOG', false);", $config_content);
    }
    
    file_put_contents($wp_config_path, $config_content);
    echo json_encode(array(
        'success' => true,
        'wp_debug' => $new_debug_state,
        'message' => $new_debug_state ? 'Modo Debug ACTIVADO (WP_DEBUG y WP_DEBUG_LOG habilitados).' : 'Modo Debug DESACTIVADO.'
    ));
    exit;

} elseif ($action === 'emergency_get_debug_log') {
    $log_paths = array(
        WP_CONTENT_DIR . '/debug.log',
        ABSPATH . 'error_log',
        WP_CONTENT_DIR . '/error_log'
    );
    $found_log = null;
    foreach ($log_paths as $lp) {
        if (file_exists($lp) && is_readable($lp)) {
            $found_log = $lp;
            break;
        }
    }
    
    if (!$found_log) {
        echo json_encode(array(
            'success' => true,
            'has_log' => false,
            'log_content' => 'No se encontró archivo debug.log ni error_log en wp-content/. Asegúrate de que el Modo Debug esté activado.',
            'lines' => array()
        ));
        exit;
    }
    
    $file_lines = @file($found_log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $last_lines = is_array($file_lines) ? array_slice($file_lines, -100) : array();
    
    echo json_encode(array(
        'success' => true,
        'has_log' => true,
        'log_path' => basename($found_log),
        'log_content' => implode("\n", $last_lines),
        'lines' => $last_lines,
        'total_lines' => is_array($file_lines) ? count($file_lines) : 0
    ));
    exit;

} else {
    echo json_encode(array('success' => false, 'message' => 'Acción no válida.'));
}

