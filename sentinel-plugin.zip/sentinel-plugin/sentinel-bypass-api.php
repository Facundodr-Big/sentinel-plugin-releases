<?php
/**
 * Sentinel Bypass API (SHORTINIT Consolidada)
 * Permite realizar backups de DB y Archivos de manera ultraligera sin levantar plugins ni temas.
 */

header('Content-Type: application/json; charset=utf-8');

// 1. Cargar WordPress en modo SHORTINIT
define('SHORTINIT', true);

// Buscar wp-load.php de forma ascendente
$wp_load_path = dirname(dirname(dirname(__DIR__))) . '/wp-load.php';
if (!file_exists($wp_load_path)) {
    $wp_load_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}
if (!file_exists($wp_load_path)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => 'No se pudo encontrar wp-load.php'));
    exit;
}

require_once($wp_load_path);

// 2. Cargar dependencias core necesarias
if (defined('ABSPATH')) {
    require_once(ABSPATH . 'wp-includes/functions.php');
    require_once(ABSPATH . 'wp-includes/formatting.php');
    require_once(ABSPATH . 'wp-includes/option.php');
}

// 3. Autenticación
global $wpdb;
$agent_secret = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'controlcenter_agent_secret'");
if (!$agent_secret) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'Sentinel no configurado.'));
    exit;
}

// Decodificar JSON crudo si viene en el cuerpo
$input_raw = file_get_contents('php://input');
$json_params = json_decode($input_raw, true);
if (is_array($json_params)) {
    $_REQUEST = array_merge($_REQUEST, $json_params);
}

$agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? $_SERVER['HTTP_X_AGENT_ID'] : '';
$timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
$signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? $_SERVER['HTTP_X_SIGNATURE'] : '';

$auth_ok = false;

// Validar HMAC
if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
    $current_time = time();
    if (abs($current_time - $timestamp) <= 300) {
        $data_to_sign = $agent_id . $timestamp;
        $expected_signature = hash_hmac('sha256', $data_to_sign, $agent_secret);
        if (hash_equals($expected_signature, $signature)) {
            $auth_ok = true;
        }
    }
}

// Validar Token/API Key
if (!$auth_ok) {
    $client_key = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
        if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
            $client_key = trim($matches[1]);
        }
    } elseif (isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
        $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
    } elseif (isset($_REQUEST['sentinel_key'])) {
        $client_key = trim($_REQUEST['sentinel_key']);
    }

    if (!empty($client_key) && hash_equals($agent_secret, $client_key)) {
        $auth_ok = true;
    }
}

if (!$auth_ok) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'No autorizado.'));
    exit;
}

$action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : '';

// 4. Enrutar acciones
if (in_array($action, array('start', 'step', 'finish'))) {
    $backup_db_path = dirname(__FILE__) . '/includes/class-backup-db.php';
    if (!file_exists($backup_db_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-db.php no encontrada.'));
        exit;
    }
    require_once($backup_db_path);
    $backup_db = new Sentinel_Backup_DB();

    if ($action === 'start') {
        echo json_encode($backup_db->start_chunk_backup());
    } elseif ($action === 'step') {
        $table = isset($_REQUEST['table']) ? sanitize_text_field($_REQUEST['table']) : '';
        $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
        $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 1000;
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        $write_structure = isset($_REQUEST['write_structure']) ? (bool)$_REQUEST['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.'));
            exit;
        }
        echo json_encode($backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure));
    } elseif ($action === 'finish') {
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        if (empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetro "backup_name" requerido.'));
            exit;
        }
        echo json_encode($backup_db->finish_chunk_backup($backup_name));
    }
} elseif ($action === 'files_incremental') {
    $backup_files_path = dirname(__FILE__) . '/includes/class-backup-files.php';
    if (!file_exists($backup_files_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-files.php no encontrada.'));
        exit;
    }
    require_once($backup_files_path);

    $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
    $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 500;
    $type = isset($_REQUEST['type']) ? sanitize_text_field($_REQUEST['type']) : 'auto';
    $format = isset($_REQUEST['format']) ? sanitize_text_field($_REQUEST['format']) : 'zip';
    $excluded_files = array();
    if (isset($_REQUEST['excluded_files']) && is_array($_REQUEST['excluded_files'])) {
        $excluded_files = array_map('sanitize_text_field', $_REQUEST['excluded_files']);
    }

    $backup_files = new Sentinel_Backup_Files();
    echo json_encode($backup_files->run_backup($offset, $limit, $type, $excluded_files, $format));
} elseif ($action === 'status' || $action === 'site_info') {
    global $wpdb;
    
    $wp_version = '6.5';
    $version_file = ABSPATH . 'wp-includes/version.php';
    if (file_exists($version_file)) {
        include($version_file);
        if (isset($wp_version)) {
            $wp_version = $wp_version;
        }
    }
    
    $blogname = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'blogname'");
    $siteurl = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl'");
    
    $active_plugins_raw = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'");
    $active_plugins_arr = !empty($active_plugins_raw) ? @unserialize($active_plugins_raw) : array();
    if (!is_array($active_plugins_arr)) { $active_plugins_arr = array(); }
    
    $plugins_dir = WP_CONTENT_DIR . '/plugins';
    $plugins_list = array();
    $total_plugins = 0;
    
    if (is_dir($plugins_dir)) {
        $files = scandir($plugins_dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $full_p = $plugins_dir . '/' . $file;
            $main_php = '';
            if (is_dir($full_p)) {
                $subfiles = glob($full_p . '/*.php');
                if ($subfiles) {
                    foreach ($subfiles as $sf) {
                        $c = file_get_contents($sf, false, null, 0, 1024);
                        if (strpos($c, 'Plugin Name:') !== false) {
                            $main_php = $sf;
                            break;
                        }
                    }
                }
            } elseif (is_file($full_p) && strpos($file, '.php') !== false) {
                $main_php = $full_p;
            }
            
            if ($main_php && file_exists($main_php)) {
                $c = file_get_contents($main_php, false, null, 0, 2048);
                preg_match('/Plugin Name:\s*(.*)$/mi', $c, $m_name);
                preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);
                
                $p_name = !empty($m_name[1]) ? trim($m_name[1]) : basename($main_php);
                $p_ver = !empty($m_ver[1]) ? trim($m_ver[1]) : '1.0.0';
                
                $rel_path = str_replace($plugins_dir . '/', '', $main_php);
                $is_active = in_array($rel_path, $active_plugins_arr);
                
                $plugins_list[] = array(
                    'name' => $p_name,
                    'version' => $p_ver,
                    'active' => (bool)$is_active,
                    'file' => $rel_path
                );
                $total_plugins++;
            }
        }
    }
    
    $sentinel_ver = '2.7.66';
    $sentinel_main = dirname(__FILE__) . '/sentinel.php';
    if (file_exists($sentinel_main)) {
        $c = file_get_contents($sentinel_main, false, null, 0, 1024);
        preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);
        if (!empty($m_ver[1])) {
            $sentinel_ver = trim($m_ver[1]);
        }
    }
    
    $wpvivid_installed = is_dir(WP_CONTENT_DIR . '/plugins/wpvivid');
    $wpvivid_active = false;
    if ($wpvivid_installed) {
        foreach ($active_plugins_arr as $ap) {
            if (strpos($ap, 'wpvivid') !== false) {
                $wpvivid_active = true;
                break;
            }
        }
    }
    
    $db_size_bytes = 0;
    $db_data_size_bytes = 0;
    $db_index_size_bytes = 0;
    try {
        $db_status = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);
        if ($db_status) {
            foreach ($db_status as $row) {
                $data_len = isset($row['Data_length']) ? intval($row['Data_length']) : 0;
                $idx_len = isset($row['Index_length']) ? intval($row['Index_length']) : 0;
                $db_data_size_bytes += $data_len;
                $db_index_size_bytes += $idx_len;
                $db_size_bytes += ($data_len + $idx_len);
            }
        }
    } catch (Exception $e) {}

    echo json_encode(array(
        'status' => 'online',
        'site_name' => $blogname ? $blogname : 'Sitio WordPress',
        'site_url' => $siteurl,
        'wordpress' => $wp_version,
        'php' => PHP_VERSION,
        'mysql' => $wpdb->db_version(),
        'sentinel_version' => $sentinel_ver,
        'total_plugins' => $total_plugins,
        'pending_updates' => 0,
        'plugins' => $plugins_list,
        'themes' => array(),
        'wpvivid_installed' => $wpvivid_installed,
        'wpvivid_active' => $wpvivid_active,
        'db_size_bytes' => $db_size_bytes,
        'db_data_size_bytes' => $db_data_size_bytes,
        'db_index_size_bytes' => $db_index_size_bytes,
        'uploads_size_bytes' => 0,
        'shortinit_bypass' => true,
        'waf_bypassed' => true
    ));
    exit;

} elseif ($action === 'emergency_deactivate_plugins') {
    // 1. Respaldar y vaciar active_plugins (dejando solo Sentinel activo)
    $active_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'active_plugins'");
    $active_plugins = maybe_unserialize($active_raw);
    if (!is_array($active_plugins)) {
        $active_plugins = array();
    }
    
    $wpdb->query($wpdb->prepare(
        "REPLACE INTO $wpdb->options (option_name, option_value, autoload) VALUES ('_sentinel_backup_plugins', %s, 'no')",
        maybe_serialize($active_plugins)
    ));
    
    $sentinel_active = array();
    foreach ($active_plugins as $p) {
        if (strpos($p, 'sentinel') !== false) {
            $sentinel_active[] = $p;
        }
    }
    if (empty($sentinel_active)) {
        $sentinel_active[] = 'sentinel-plugin/sentinel.php';
    }
    
    $wpdb->query($wpdb->prepare(
        "UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'active_plugins'",
        maybe_serialize($sentinel_active)
    ));

    // 2. Desactivar Drop-ins de caché huérfanos que causan Fatal Errors (object-cache.php, advanced-cache.php, db.php)
    $disabled_dropins = array();
    $dropins = array('object-cache.php', 'advanced-cache.php', 'db.php');
    foreach ($dropins as $d) {
        $path = WP_CONTENT_DIR . '/' . $d;
        if (file_exists($path)) {
            $target = WP_CONTENT_DIR . '/' . $d . '.disabled_sentinel';
            if (@rename($path, $target)) {
                $disabled_dropins[] = $d;
            }
        }
    }
    if (!empty($disabled_dropins)) {
        $wpdb->query($wpdb->prepare(
            "REPLACE INTO $wpdb->options (option_name, option_value, autoload) VALUES ('_sentinel_disabled_dropins', %s, 'no')",
            maybe_serialize($disabled_dropins)
        ));
    }

    // 3. Desactivar mu-plugins no-sentinel si existen
    $mu_dir = WP_CONTENT_DIR . '/mu-plugins';
    $disabled_mu = false;
    if (is_dir($mu_dir)) {
        $files = @scandir($mu_dir);
        $has_third_party = false;
        if (is_array($files)) {
            foreach ($files as $f) {
                if ($f !== '.' && $f !== '..' && strpos($f, 'sentinel') === false) {
                    $has_third_party = true;
                    break;
                }
            }
        }
        if ($has_third_party) {
            $target_mu = WP_CONTENT_DIR . '/mu-plugins.disabled_sentinel';
            if (@rename($mu_dir, $target_mu)) {
                $disabled_mu = true;
                $wpdb->query("REPLACE INTO $wpdb->options (option_name, option_value, autoload) VALUES ('_sentinel_disabled_mu', '1', 'no')");
            }
        }
    }

    // 4. Limpiar transients corruptos
    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'");

    echo json_encode(array(
        'success' => true,
        'message' => 'Modo Seguro Activado: Plugins desactivados, drop-ins de caché aislados y transients purgados.',
        'deactivated_count' => count($active_plugins) - count($sentinel_active),
        'disabled_dropins' => $disabled_dropins,
        'disabled_mu' => $disabled_mu,
        'saved_backup' => true
    ));
    exit;

} elseif ($action === 'emergency_restore_plugins') {
    // 1. Restaurar active_plugins
    $backup_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = '_sentinel_backup_plugins'");
    $backup_plugins = $backup_raw ? maybe_unserialize($backup_raw) : array();
    
    if (is_array($backup_plugins) && !empty($backup_plugins)) {
        $wpdb->query($wpdb->prepare(
            "UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'active_plugins'",
            maybe_serialize($backup_plugins)
        ));
    }
    
    // 2. Restaurar drop-ins
    $dropins_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = '_sentinel_disabled_dropins'");
    if ($dropins_raw) {
        $disabled_dropins = maybe_unserialize($dropins_raw);
        if (is_array($disabled_dropins)) {
            foreach ($disabled_dropins as $d) {
                $orig = WP_CONTENT_DIR . '/' . $d;
                $renamed = WP_CONTENT_DIR . '/' . $d . '.disabled_sentinel';
                if (file_exists($renamed)) {
                    @rename($renamed, $orig);
                }
            }
        }
        $wpdb->query("DELETE FROM $wpdb->options WHERE option_name = '_sentinel_disabled_dropins'");
    }

    // 3. Restaurar mu-plugins
    $mu_target = WP_CONTENT_DIR . '/mu-plugins.disabled_sentinel';
    if (is_dir($mu_target)) {
        @rename($mu_target, WP_CONTENT_DIR . '/mu-plugins');
        $wpdb->query("DELETE FROM $wpdb->options WHERE option_name = '_sentinel_disabled_mu'");
    }

    echo json_encode(array(
        'success' => true,
        'message' => 'Plugins, drop-ins y extensiones reactivados con éxito (' . count($backup_plugins) . ' plugins restaurados).',
        'restored_count' => count($backup_plugins)
    ));
    exit;

} elseif ($action === 'emergency_switch_theme') {
    $current_template = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'template'");
    $current_stylesheet = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'stylesheet'");

    $wpdb->query($wpdb->prepare(
        "REPLACE INTO $wpdb->options (option_name, option_value, autoload) VALUES ('_sentinel_backup_theme', %s, 'no')",
        maybe_serialize(array('template' => $current_template, 'stylesheet' => $current_stylesheet))
    ));

    $themes_dir = WP_CONTENT_DIR . '/themes';
    $safe_themes = array('twentytwentyfour', 'twentytwentythree', 'twentytwentytwo', 'twentytwentyone', 'twentytwenty', 'twentynineteen', 'twentyseventeen', 'astra', 'generatepress', 'hello-elementor');
    $found_safe_theme = null;

    foreach ($safe_themes as $st) {
        if (is_dir($themes_dir . '/' . $st)) {
            $found_safe_theme = $st;
            break;
        }
    }

    if (!$found_safe_theme && is_dir($themes_dir)) {
        $dirs = @scandir($themes_dir);
        if (is_array($dirs)) {
            foreach ($dirs as $d) {
                if ($d !== '.' && $d !== '..' && $d !== $current_template && is_dir($themes_dir . '/' . $d)) {
                    $found_safe_theme = $d;
                    break;
                }
            }
        }
    }

    if ($found_safe_theme) {
        $wpdb->query($wpdb->prepare("UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'template'", $found_safe_theme));
        $wpdb->query($wpdb->prepare("UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'stylesheet'", $found_safe_theme));

        echo json_encode(array(
            'success' => true,
            'message' => "Tema conmutado con éxito a tema seguro: {$found_safe_theme}. Tema anterior ({$current_stylesheet}) respaldado.",
            'previous_theme' => $current_stylesheet,
            'active_theme' => $found_safe_theme
        ));
    } else {
        echo json_encode(array(
            'success' => false,
            'message' => 'No se encontró un tema alternativo por defecto en wp-content/themes/.'
        ));
    }
    exit;

} elseif ($action === 'emergency_restore_theme') {
    $theme_raw = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = '_sentinel_backup_theme'");
    if (!$theme_raw) {
        echo json_encode(array('success' => false, 'message' => 'No se encontró un respaldo previo del tema activo.'));
        exit;
    }
    $theme_data = maybe_unserialize($theme_raw);
    if (is_array($theme_data) && !empty($theme_data['template'])) {
        $wpdb->query($wpdb->prepare("UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'template'", $theme_data['template']));
        $wpdb->query($wpdb->prepare("UPDATE $wpdb->options SET option_value = %s WHERE option_name = 'stylesheet'", $theme_data['stylesheet']));

        echo json_encode(array(
            'success' => true,
            'message' => "Tema original restaurado con éxito ({$theme_data['stylesheet']})."
        ));
    } else {
        echo json_encode(array('success' => false, 'message' => 'Datos de respaldo de tema inválidos.'));
    }
    exit;

} elseif ($action === 'emergency_toggle_debug') {
    $wp_config_path = ABSPATH . 'wp-config.php';
    if (!file_exists($wp_config_path)) {
        $wp_config_path = dirname(ABSPATH) . '/wp-config.php';
    }
    if (!file_exists($wp_config_path) || !is_writable($wp_config_path)) {
        echo json_encode(array('success' => false, 'message' => 'El archivo wp-config.php no existe o no tiene permisos de escritura.'));
        exit;
    }
    
    $config_content = file_get_contents($wp_config_path);
    $is_currently_debug = (bool)preg_match("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\)/i", $config_content);
    $new_debug_state = !$is_currently_debug;
    
    // Limpiar todas las constantes previas de debug para evitar duplicaciones o definiciones tardías
    $debug_constants = array('WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY', 'WP_DISABLE_FATAL_ERROR_HANDLER', 'SCRIPT_DEBUG');
    foreach ($debug_constants as $const) {
        $config_content = preg_replace("/define\s*\(\s*['\"]" . $const . "['\"]\s*,\s*[^)]+\s*\);\s*(\r\n|\n|\r)?/i", "", $config_content);
    }
    $config_content = preg_replace("/@?ini_set\s*\(\s*['\"]display_errors['\"]\s*,\s*[^)]+\s*\);\s*(\r\n|\n|\r)?/i", "", $config_content);

    if ($new_debug_state) {
        $debug_block = "/* Sentinel Emergency Debug Mode */\n" .
            "define('WP_DEBUG', true);\n" .
            "define('WP_DEBUG_LOG', true);\n" .
            "define('WP_DEBUG_DISPLAY', true);\n" .
            "define('WP_DISABLE_FATAL_ERROR_HANDLER', true);\n" .
            "@ini_set('display_errors', '1');\n";
    } else {
        $debug_block = "/* Sentinel Normal Mode */\n" .
            "define('WP_DEBUG', false);\n" .
            "define('WP_DEBUG_LOG', false);\n" .
            "define('WP_DEBUG_DISPLAY', false);\n";
    }

    // Inyectar el bloque SIEMPRE antes de require_once wp-settings.php o stop editing
    if (preg_match("/(\/\*\s*That's all, stop editing!|require_once\s+ABSPATH\s*\.\s*['\"]wp-settings\.php['\"])/i", $config_content)) {
        $config_content = preg_replace("/(\/\*\s*That's all, stop editing!|require_once\s+ABSPATH\s*\.\s*['\"]wp-settings\.php['\"])/i", $debug_block . "\n$1", $config_content, 1);
    } else {
        $config_content = preg_replace("/(<\?php)/i", "$1\n" . $debug_block, $config_content, 1);
    }
    
    file_put_contents($wp_config_path, $config_content);
    echo json_encode(array(
        'success' => true,
        'wp_debug' => $new_debug_state,
        'message' => $new_debug_state 
            ? 'Modo Debug Total ACTIVADO: Errores visibles en pantalla y registrados en debug.log (Fatal Error Handler deshabilitado).' 
            : 'Modo Debug DESACTIVADO.'
    ));
    exit;

} elseif ($action === 'emergency_diagnose') {
    $log_paths = array(
        WP_CONTENT_DIR . '/debug.log',
        ABSPATH . 'error_log',
        WP_CONTENT_DIR . '/error_log',
        dirname(ABSPATH) . '/error_log'
    );
    $found_errors = array();
    $found_log_file = null;

    foreach ($log_paths as $lp) {
        if (file_exists($lp) && is_readable($lp)) {
            $found_log_file = basename($lp);
            $file_lines = @file($lp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (is_array($file_lines) && !empty($file_lines)) {
                $last_50 = array_slice($file_lines, -50);
                foreach (array_reverse($last_50) as $line) {
                    if (stripos($line, 'PHP Fatal error') !== false || stripos($line, 'PHP Parse error') !== false || stripos($line, 'Uncaught Error') !== false || stripos($line, 'Uncaught Exception') !== false) {
                        $found_errors[] = $line;
                        if (count($found_errors) >= 5) break;
                    }
                }
            }
            if (!empty($found_errors)) break;
        }
    }

    $culprit = null;
    $parsed_error = null;
    if (!empty($found_errors)) {
        $primary = $found_errors[0];
        $parsed_error = $primary;
        if (preg_match('/wp-content\/plugins\/([^\/]+)/i', $primary, $m)) {
            $culprit = array('type' => 'plugin', 'slug' => $m[1], 'description' => "Plugin: {$m[1]}");
        } elseif (preg_match('/wp-content\/themes\/([^\/]+)/i', $primary, $m)) {
            $culprit = array('type' => 'theme', 'slug' => $m[1], 'description' => "Tema: {$m[1]}");
        } elseif (preg_match('/wp-includes\//i', $primary)) {
            $culprit = array('type' => 'core', 'slug' => 'wordpress-core', 'description' => "WordPress Core (posible incompatibilidad de PHP)");
        }
    }

    $active_dropins = array();
    foreach (array('object-cache.php', 'advanced-cache.php', 'db.php') as $d) {
        if (file_exists(WP_CONTENT_DIR . '/' . $d)) {
            $active_dropins[] = $d;
        }
    }

    $current_template = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'template'");
    $current_stylesheet = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'stylesheet'");

    echo json_encode(array(
        'success' => true,
        'culprit' => $culprit,
        'last_fatal_error' => $parsed_error,
        'fatal_errors_found' => $found_errors,
        'log_file' => $found_log_file,
        'active_dropins' => $active_dropins,
        'active_theme' => $current_stylesheet,
        'has_mu_plugins' => is_dir(WP_CONTENT_DIR . '/mu-plugins')
    ));
    exit;

} elseif ($action === 'emergency_get_debug_log') {
    $log_paths = array(
        WP_CONTENT_DIR . '/debug.log',
        ABSPATH . 'error_log',
        WP_CONTENT_DIR . '/error_log',
        dirname(ABSPATH) . '/error_log'
    );
    $found_log = null;
    foreach ($log_paths as $lp) {
        if (file_exists($lp) && is_readable($lp)) {
            $found_log = $lp;
            break;
        }
    }
    
    if (!$found_log) {
        echo json_encode(array(
            'success' => true,
            'has_log' => false,
            'log_content' => 'No se encontró archivo debug.log ni error_log en wp-content/. Asegúrate de que el Modo Debug esté activado.',
            'lines' => array()
        ));
        exit;
    }
    
    $file_lines = @file($found_log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $last_lines = is_array($file_lines) ? array_slice($file_lines, -100) : array();
    
    echo json_encode(array(
        'success' => true,
        'has_log' => true,
        'log_path' => basename($found_log),
        'log_content' => implode("\n", $last_lines),
        'lines' => $last_lines,
        'total_lines' => is_array($file_lines) ? count($file_lines) : 0
    ));
    exit;

} else {
    echo json_encode(array('success' => false, 'message' => 'Acción no válida.'));
}

