<?php
/**
 * Sentinel Bypass API (SHORTINIT Consolidada + Standalone Emergency Engine)
 * Permite realizar backups de DB y Archivos de manera ultraligera y rescatar WordPress ante caídas críticas.
 */

header('Content-Type: application/json; charset=utf-8');

// Decodificar JSON crudo si viene en el cuerpo
$input_raw = file_get_contents('php://input');
$json_params = json_decode($input_raw, true);
if (is_array($json_params)) {
    $_REQUEST = array_merge($_REQUEST, $json_params);
}

$action = isset($_REQUEST['action']) ? trim($_REQUEST['action']) : '';

// =========================================================================
// MODO DE EMERGENCIA / RESCATE AUTÓNOMO (STANDALONE - SIN WP-LOAD.PHP)
// =========================================================================
if (strpos($action, 'emergency_') === 0) {
    // 1. Localizar wp-config.php de forma ascendente
    $wp_config_path = null;
    $curr = dirname(__FILE__);
    for ($i = 0; $i < 6; $i++) {
        if (file_exists($curr . '/wp-config.php')) {
            $wp_config_path = $curr . '/wp-config.php';
            break;
        }
        $curr = dirname($curr);
    }
    if (!$wp_config_path && isset($_SERVER['DOCUMENT_ROOT']) && file_exists($_SERVER['DOCUMENT_ROOT'] . '/wp-config.php')) {
        $wp_config_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-config.php';
    }

    if (!$wp_config_path || !file_exists($wp_config_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'No se pudo encontrar wp-config.php en el servidor.'));
        exit;
    }

    $wp_root_dir = dirname($wp_config_path);
    if (!defined('ABSPATH')) {
        define('ABSPATH', rtrim($wp_root_dir, '/\\') . '/');
    }
    if (!defined('WP_CONTENT_DIR')) {
        define('WP_CONTENT_DIR', ABSPATH . 'wp-content');
    }

    // 2. Analizar credenciales de Base de Datos desde wp-config.php (sin ejecutarlo)
    $config_content = file_get_contents($wp_config_path);
    $db_name = ''; $db_user = ''; $db_password = ''; $db_host = 'localhost'; $table_prefix = 'wp_';

    preg_match("/define\(\s*['"]DB_NAME['"]\s*,\s*['"](.*?)['"]\s*\)/i", $config_content, $m);
    if (!empty($m[1])) $db_name = $m[1];

    preg_match("/define\(\s*['"]DB_USER['"]\s*,\s*['"](.*?)['"]\s*\)/i", $config_content, $m);
    if (!empty($m[1])) $db_user = $m[1];

    preg_match("/define\(\s*['"]DB_PASSWORD['"]\s*,\s*['"](.*?)['"]\s*\)/i", $config_content, $m);
    if (!empty($m[1])) $db_password = $m[1];

    preg_match("/define\(\s*['"]DB_HOST['"]\s*,\s*['"](.*?)['"]\s*\)/i", $config_content, $m);
    if (!empty($m[1])) $db_host = $m[1];

    preg_match('/\\$table_prefix\\s*=\\s*[\'"](.*?)[\'"]\\s*;/i', $config_content, $m);
    if (!empty($m[1])) $table_prefix = $m[1];

    $host = $db_host; $port = 3306; $socket = null;
    if (strpos($db_host, ':') !== false) {
        $parts = explode(':', $db_host, 2);
        $host = $parts[0];
        if (is_numeric($parts[1])) {
            $port = intval($parts[1]);
        } else {
            $socket = $parts[1];
        }
    }

    // 3. Conexión directa a MySQL
    $mysqli = @new mysqli($host, $db_user, $db_password, $db_name, $port, $socket);
    if ($mysqli->connect_error && $host === 'localhost') {
        $mysqli = @new mysqli('127.0.0.1', $db_user, $db_password, $db_name, $port, $socket);
    }

    if ($mysqli->connect_error) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Error de conexión MySQL directa: ' . $mysqli->connect_error));
        exit;
    }
    $mysqli->set_charset('utf8mb4');

    // 4. Obtener clave de agente para autenticación
    $prefix_escaped = $mysqli->real_escape_string($table_prefix);
    $res = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'controlcenter_agent_secret' LIMIT 1");
    $agent_secret = '';
    if ($res && $row = $res->fetch_assoc()) {
        $agent_secret = $row['option_value'];
    }

    if (!$agent_secret) {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(array('success' => false, 'message' => 'Sentinel no configurado en la base de datos.'));
        exit;
    }

    // 5. Validar autenticación (HMAC o API Key / Bearer)
    $agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? $_SERVER['HTTP_X_AGENT_ID'] : '';
    $timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
    $signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? $_SERVER['HTTP_X_SIGNATURE'] : '';
    $auth_ok = false;

    if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
        if (abs(time() - $timestamp) <= 300) {
            $expected_sig = hash_hmac('sha256', $agent_id . $timestamp, $agent_secret);
            if (hash_equals($expected_sig, $signature)) {
                $auth_ok = true;
            }
        }
    }

    if (!$auth_ok) {
        $client_key = '';
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            if (preg_match('/Bearer\s+(.*)$/i', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
                $client_key = trim($matches[1]);
            }
        } elseif (isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
            $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
        } elseif (isset($_REQUEST['sentinel_key'])) {
            $client_key = trim($_REQUEST['sentinel_key']);
        }

        if (!empty($client_key) && hash_equals($agent_secret, $client_key)) {
            $auth_ok = true;
        }
    }

    if (!$auth_ok) {
        header('HTTP/1.1 401 Unauthorized');
        echo json_encode(array('success' => false, 'message' => 'No autorizado.'));
        exit;
    }

    // 6. Ejecución de Acciones de Emergencia en Modo Autónomo
    if ($action === 'emergency_deactivate_plugins') {
        // A) Respaldar active_plugins y dejar solo Sentinel
        $res = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'active_plugins' LIMIT 1");
        $active_plugins = array();
        if ($res && $row = $res->fetch_assoc()) {
            $unserialized = @unserialize($row['option_value']);
            if (is_array($unserialized)) {
                $active_plugins = $unserialized;
            }
        }

        $stmt = $mysqli->prepare("REPLACE INTO `{$prefix_escaped}options` (option_name, option_value, autoload) VALUES ('_sentinel_backup_plugins', ?, 'no')");
        if ($stmt) {
            $backup_serialized = serialize($active_plugins);
            $stmt->bind_param('s', $backup_serialized);
            $stmt->execute();
            $stmt->close();
        }

        $sentinel_active = array();
        foreach ($active_plugins as $p) {
            if (strpos($p, 'sentinel') !== false) {
                $sentinel_active[] = $p;
            }
        }
        if (empty($sentinel_active)) {
            $sentinel_active[] = 'sentinel-plugin/sentinel.php';
        }

        $stmt_upd = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'active_plugins'");
        if ($stmt_upd) {
            $new_active_serialized = serialize($sentinel_active);
            $stmt_upd->bind_param('s', $new_active_serialized);
            $stmt_upd->execute();
            $stmt_upd->close();
        }

        // B) Desactivar Drop-ins de caché huérfanos
        $disabled_dropins = array();
        $dropins = array('object-cache.php', 'advanced-cache.php', 'db.php');
        foreach ($dropins as $d) {
            $path = WP_CONTENT_DIR . '/' . $d;
            if (file_exists($path)) {
                $target = WP_CONTENT_DIR . '/' . $d . '.disabled_sentinel';
                if (@rename($path, $target)) {
                    $disabled_dropins[] = $d;
                }
            }
        }
        if (!empty($disabled_dropins)) {
            $stmt_drop = $mysqli->prepare("REPLACE INTO `{$prefix_escaped}options` (option_name, option_value, autoload) VALUES ('_sentinel_disabled_dropins', ?, 'no')");
            if ($stmt_drop) {
                $drop_ser = serialize($disabled_dropins);
                $stmt_drop->bind_param('s', $drop_ser);
                $stmt_drop->execute();
                $stmt_drop->close();
            }
        }

        // C) Desactivar mu-plugins conflictivos renombrando la carpeta
        $mu_dir = WP_CONTENT_DIR . '/mu-plugins';
        $disabled_mu = false;
        if (is_dir($mu_dir)) {
            $files = @scandir($mu_dir);
            $has_third_party = false;
            if (is_array($files)) {
                foreach ($files as $f) {
                    if ($f !== '.' && $f !== '..' && strpos($f, 'sentinel') === false) {
                        $has_third_party = true;
                        break;
                    }
                }
            }
            if ($has_third_party) {
                $target_mu = WP_CONTENT_DIR . '/mu-plugins.disabled_sentinel';
                if (@rename($mu_dir, $target_mu)) {
                    $disabled_mu = true;
                    $mysqli->query("REPLACE INTO `{$prefix_escaped}options` (option_name, option_value, autoload) VALUES ('_sentinel_disabled_mu', '1', 'no')");
                }
            }
        }

        // D) Limpiar transients corruptos
        $mysqli->query("DELETE FROM `{$prefix_escaped}options` WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'");

        echo json_encode(array(
            'success' => true,
            'message' => 'Modo Seguro Activado: Plugins desactivados, mu-plugins y drop-ins aislados, y transients purgados. WordPress desbloqueado con éxito.',
            'deactivated_count' => count($active_plugins) - count($sentinel_active),
            'disabled_dropins' => $disabled_dropins,
            'disabled_mu' => $disabled_mu,
            'saved_backup' => true
        ));
        exit;

    } elseif ($action === 'emergency_restore_plugins') {
        // A) Restaurar active_plugins
        $res = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = '_sentinel_backup_plugins' LIMIT 1");
        $backup_plugins = array();
        if ($res && $row = $res->fetch_assoc()) {
            $unserialized = @unserialize($row['option_value']);
            if (is_array($unserialized)) {
                $backup_plugins = $unserialized;
            }
        }

        if (!empty($backup_plugins)) {
            $stmt = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'active_plugins'");
            if ($stmt) {
                $b_ser = serialize($backup_plugins);
                $stmt->bind_param('s', $b_ser);
                $stmt->execute();
                $stmt->close();
            }
        }

        // B) Restaurar drop-ins
        $res_drop = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = '_sentinel_disabled_dropins' LIMIT 1");
        if ($res_drop && $row_drop = $res_drop->fetch_assoc()) {
            $disabled_dropins = @unserialize($row_drop['option_value']);
            if (is_array($disabled_dropins)) {
                foreach ($disabled_dropins as $d) {
                    $orig = WP_CONTENT_DIR . '/' . $d;
                    $renamed = WP_CONTENT_DIR . '/' . $d . '.disabled_sentinel';
                    if (file_exists($renamed)) {
                        @rename($renamed, $orig);
                    }
                }
            }
            $mysqli->query("DELETE FROM `{$prefix_escaped}options` WHERE option_name = '_sentinel_disabled_dropins'");
        }

        // C) Restaurar mu-plugins
        $mu_target = WP_CONTENT_DIR . '/mu-plugins.disabled_sentinel';
        if (is_dir($mu_target)) {
            @rename($mu_target, WP_CONTENT_DIR . '/mu-plugins');
            $mysqli->query("DELETE FROM `{$prefix_escaped}options` WHERE option_name = '_sentinel_disabled_mu'");
        }

        echo json_encode(array(
            'success' => true,
            'message' => 'Plugins, mu-plugins y drop-ins reactivados con éxito (' . count($backup_plugins) . ' plugins restaurados).',
            'restored_count' => count($backup_plugins)
        ));
        exit;

    } elseif ($action === 'emergency_switch_theme') {
        $res_temp = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'template' LIMIT 1");
        $curr_template = ($res_temp && $row = $res_temp->fetch_assoc()) ? $row['option_value'] : '';

        $res_style = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'stylesheet' LIMIT 1");
        $curr_stylesheet = ($res_style && $row = $res_style->fetch_assoc()) ? $row['option_value'] : '';

        $theme_backup = serialize(array('template' => $curr_template, 'stylesheet' => $curr_stylesheet));
        $stmt_tb = $mysqli->prepare("REPLACE INTO `{$prefix_escaped}options` (option_name, option_value, autoload) VALUES ('_sentinel_backup_theme', ?, 'no')");
        if ($stmt_tb) {
            $stmt_tb->bind_param('s', $theme_backup);
            $stmt_tb->execute();
            $stmt_tb->close();
        }

        $themes_dir = WP_CONTENT_DIR . '/themes';
        $safe_themes = array('twentytwentyfour', 'twentytwentythree', 'twentytwentytwo', 'twentytwentyone', 'twentytwenty', 'twentynineteen', 'twentyseventeen', 'astra', 'generatepress', 'hello-elementor');
        $found_safe_theme = null;

        foreach ($safe_themes as $st) {
            if (is_dir($themes_dir . '/' . $st)) {
                $found_safe_theme = $st;
                break;
            }
        }

        if (!$found_safe_theme && is_dir($themes_dir)) {
            $dirs = @scandir($themes_dir);
            if (is_array($dirs)) {
                foreach ($dirs as $d) {
                    if ($d !== '.' && $d !== '..' && $d !== $curr_template && is_dir($themes_dir . '/' . $d)) {
                        $found_safe_theme = $d;
                        break;
                    }
                }
            }
        }

        if ($found_safe_theme) {
            $stmt_u1 = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'template'");
            if ($stmt_u1) {
                $stmt_u1->bind_param('s', $found_safe_theme);
                $stmt_u1->execute();
                $stmt_u1->close();
            }
            $stmt_u2 = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'stylesheet'");
            if ($stmt_u2) {
                $stmt_u2->bind_param('s', $found_safe_theme);
                $stmt_u2->execute();
                $stmt_u2->close();
            }

            echo json_encode(array(
                'success' => true,
                'message' => "Tema conmutado con éxito a tema seguro: {$found_safe_theme}. Tema anterior ({$curr_stylesheet}) respaldado.",
                'previous_theme' => $curr_stylesheet,
                'active_theme' => $found_safe_theme
            ));
        } else {
            echo json_encode(array(
                'success' => false,
                'message' => 'No se encontró un tema alternativo en wp-content/themes/.'
            ));
        }
        exit;

    } elseif ($action === 'emergency_restore_theme') {
        $res_tb = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = '_sentinel_backup_theme' LIMIT 1");
        if (!$res_tb || !($row = $res_tb->fetch_assoc())) {
            echo json_encode(array('success' => false, 'message' => 'No se encontró un respaldo previo del tema activo.'));
            exit;
        }
        $theme_data = @unserialize($row['option_value']);
        if (is_array($theme_data) && !empty($theme_data['template'])) {
            $stmt_u1 = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'template'");
            if ($stmt_u1) {
                $stmt_u1->bind_param('s', $theme_data['template']);
                $stmt_u1->execute();
                $stmt_u1->close();
            }
            $stmt_u2 = $mysqli->prepare("UPDATE `{$prefix_escaped}options` SET option_value = ? WHERE option_name = 'stylesheet'");
            if ($stmt_u2) {
                $stmt_u2->bind_param('s', $theme_data['stylesheet']);
                $stmt_u2->execute();
                $stmt_u2->close();
            }

            echo json_encode(array(
                'success' => true,
                'message' => "Tema original restaurado con éxito ({$theme_data['stylesheet']})."
            ));
        } else {
            echo json_encode(array('success' => false, 'message' => 'Datos de respaldo de tema inválidos.'));
        }
        exit;

    } elseif ($action === 'emergency_toggle_debug') {
        if (!is_writable($wp_config_path)) {
            echo json_encode(array('success' => false, 'message' => 'El archivo wp-config.php no tiene permisos de escritura.'));
            exit;
        }

        $is_currently_debug = (bool)preg_match("/define\s*\(\s*['\"]WP_DEBUG['\"]\s*,\s*true\s*\)/i", $config_content);
        $new_debug_state = !$is_currently_debug;

        $debug_constants = array('WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY', 'WP_DISABLE_FATAL_ERROR_HANDLER', 'SCRIPT_DEBUG');
        foreach ($debug_constants as $const) {
            $config_content = preg_replace("/define\s*\(\s*['\"]" . $const . "['\"]\s*,\s*[^)]+\s*\);\s*(\r\n|\n|\r)?/i", "", $config_content);
        }
        $config_content = preg_replace("/@?ini_set\s*\(\s*['\"]display_errors['\"]\s*,\s*[^)]+\s*\);\s*(\r\n|\n|\r)?/i", "", $config_content);

        if ($new_debug_state) {
            $debug_block = "/* Sentinel Emergency Debug Mode */\n" .
                "define('WP_DEBUG', true);\n" .
                "define('WP_DEBUG_LOG', true);\n" .
                "define('WP_DEBUG_DISPLAY', true);\n" .
                "define('WP_DISABLE_FATAL_ERROR_HANDLER', true);\n" .
                "@ini_set('display_errors', '1');\n";
        } else {
            $debug_block = "/* Sentinel Normal Mode */\n" .
                "define('WP_DEBUG', false);\n" .
                "define('WP_DEBUG_LOG', false);\n" .
                "define('WP_DEBUG_DISPLAY', false);\n";
        }

        if (preg_match("/(\/\*\s*That's all, stop editing!|require_once\s+ABSPATH\s*\.\s*['\"]wp-settings\.php['\"])/i", $config_content)) {
            $config_content = preg_replace("/(\/\*\s*That's all, stop editing!|require_once\s+ABSPATH\s*\.\s*['\"]wp-settings\.php['\"])/i", "\n" . $debug_block . "$1", $config_content, 1);
        } else {
            $config_content = preg_replace("/(<\?php)/i", "$1\n" . $debug_block, $config_content, 1);
        }

        file_put_contents($wp_config_path, $config_content);
        echo json_encode(array(
            'success' => true,
            'wp_debug' => $new_debug_state,
            'message' => $new_debug_state
                ? 'Modo Debug Total ACTIVADO: Errores visibles en pantalla y registrados en debug.log (Fatal Error Handler deshabilitado).'
                : 'Modo Debug DESACTIVADO.'
        ));
        exit;

    } elseif ($action === 'emergency_diagnose') {
        $log_paths = array(
            WP_CONTENT_DIR . '/debug.log',
            ABSPATH . 'error_log',
            WP_CONTENT_DIR . '/error_log',
            dirname(ABSPATH) . '/error_log'
        );
        $found_errors = array();
        $found_log_file = null;

        foreach ($log_paths as $lp) {
            if (file_exists($lp) && is_readable($lp)) {
                $found_log_file = basename($lp);
                $file_lines = @file($lp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if (is_array($file_lines) && !empty($file_lines)) {
                    $last_50 = array_slice($file_lines, -50);
                    foreach (array_reverse($last_50) as $line) {
                        if (stripos($line, 'PHP Fatal error') !== false || stripos($line, 'PHP Parse error') !== false || stripos($line, 'Uncaught Error') !== false || stripos($line, 'Uncaught Exception') !== false) {
                            $found_errors[] = $line;
                            if (count($found_errors) >= 5) break;
                        }
                    }
                }
                if (!empty($found_errors)) break;
            }
        }

        $culprit = null;
        $parsed_error = null;
        if (!empty($found_errors)) {
            $primary = $found_errors[0];
            $parsed_error = $primary;
            if (preg_match('/wp-content/plugins/([^/]+)/i', $primary, $m)) {
                $culprit = array('type' => 'plugin', 'slug' => $m[1], 'description' => "Plugin: {$m[1]}");
            } elseif (preg_match('/wp-content/mu-plugins/([^/]+)/i', $primary, $m)) {
                $culprit = array('type' => 'mu-plugin', 'slug' => $m[1], 'description' => "MU-Plugin: {$m[1]}");
            } elseif (preg_match('/wp-content/themes/([^/]+)/i', $primary, $m)) {
                $culprit = array('type' => 'theme', 'slug' => $m[1], 'description' => "Tema: {$m[1]}");
            } elseif (preg_match('/wp-includes//i', $primary)) {
                $culprit = array('type' => 'core', 'slug' => 'wordpress-core', 'description' => "WordPress Core (posible incompatibilidad de PHP)");
            }
        }

        $active_dropins = array();
        foreach (array('object-cache.php', 'advanced-cache.php', 'db.php') as $d) {
            if (file_exists(WP_CONTENT_DIR . '/' . $d)) {
                $active_dropins[] = $d;
            }
        }

        $res_temp = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'template' LIMIT 1");
        $curr_template = ($res_temp && $row = $res_temp->fetch_assoc()) ? $row['option_value'] : '';

        $res_style = $mysqli->query("SELECT option_value FROM `{$prefix_escaped}options` WHERE option_name = 'stylesheet' LIMIT 1");
        $curr_stylesheet = ($res_style && $row = $res_style->fetch_assoc()) ? $row['option_value'] : '';

        echo json_encode(array(
            'success' => true,
            'culprit' => $culprit,
            'last_fatal_error' => $parsed_error,
            'fatal_errors_found' => $found_errors,
            'log_file' => $found_log_file,
            'active_dropins' => $active_dropins,
            'active_theme' => $curr_stylesheet,
            'has_mu_plugins' => is_dir(WP_CONTENT_DIR . '/mu-plugins')
        ));
        exit;

    } elseif ($action === 'emergency_get_debug_log') {
        $log_paths = array(
            WP_CONTENT_DIR . '/debug.log',
            ABSPATH . 'error_log',
            WP_CONTENT_DIR . '/error_log',
            dirname(ABSPATH) . '/error_log'
        );
        $found_log = null;
        foreach ($log_paths as $lp) {
            if (file_exists($lp) && is_readable($lp)) {
                $found_log = $lp;
                break;
            }
        }

        if (!$found_log) {
            echo json_encode(array(
                'success' => true,
                'has_log' => false,
                'log_content' => 'No se encontró archivo debug.log ni error_log en wp-content/. Asegúrate de que el Modo Debug esté activado.',
                'lines' => array()
            ));
            exit;
        }

        $file_lines = @file($found_log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $last_lines = is_array($file_lines) ? array_slice($file_lines, -100) : array();

        echo json_encode(array(
            'success' => true,
            'has_log' => true,
            'log_path' => basename($found_log),
            'log_content' => implode("\n", $last_lines),
            'lines' => $last_lines,
            'total_lines' => is_array($file_lines) ? count($file_lines) : 0
        ));
        exit;
    }
}

// =========================================================================
// ACCIONES ESTÁNDAR DE BACKUP Y TELEMETRÍA (MODO SHORTINIT CON WP-LOAD.PHP)
// =========================================================================

// 1. Cargar WordPress en modo SHORTINIT
define('SHORTINIT', true);

// Buscar wp-load.php de forma ascendente
$wp_load_path = dirname(dirname(dirname(__DIR__))) . '/wp-load.php';
if (!file_exists($wp_load_path)) {
    $wp_load_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}
if (!file_exists($wp_load_path)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => 'No se pudo encontrar wp-load.php'));
    exit;
}

require_once($wp_load_path);

// 2. Cargar dependencias core necesarias
if (defined('ABSPATH')) {
    require_once(ABSPATH . 'wp-includes/functions.php');
    require_once(ABSPATH . 'wp-includes/formatting.php');
    require_once(ABSPATH . 'wp-includes/option.php');
}

// 3. Autenticación
global $wpdb;
$agent_secret = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'controlcenter_agent_secret'");
if (!$agent_secret) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'Sentinel no configurado.'));
    exit;
}

$agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? $_SERVER['HTTP_X_AGENT_ID'] : '';
$timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
$signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? $_SERVER['HTTP_X_SIGNATURE'] : '';

$auth_ok = false;

// Validar HMAC
if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
    $current_time = time();
    if (abs($current_time - $timestamp) <= 300) {
        $data_to_sign = $agent_id . $timestamp;
        $expected_signature = hash_hmac('sha256', $data_to_sign, $agent_secret);
        if (hash_equals($expected_signature, $signature)) {
            $auth_ok = true;
        }
    }
}

// Validar Token/API Key
if (!$auth_ok) {
    $client_key = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
        if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
            $client_key = trim($matches[1]);
        }
    } elseif (isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
        $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
    } elseif (isset($_REQUEST['sentinel_key'])) {
        $client_key = trim($_REQUEST['sentinel_key']);
    }

    if (!empty($client_key) && hash_equals($agent_secret, $client_key)) {
        $auth_ok = true;
    }
}

if (!$auth_ok) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'No autorizado.'));
    exit;
}

$action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : '';

// 4. Enrutar acciones
if (in_array($action, array('start', 'step', 'finish'))) {
    $backup_db_path = dirname(__FILE__) . '/includes/class-backup-db.php';
    if (!file_exists($backup_db_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-db.php no encontrada.'));
        exit;
    }
    require_once($backup_db_path);
    $backup_db = new Sentinel_Backup_DB();

    if ($action === 'start') {
        echo json_encode($backup_db->start_chunk_backup());
    } elseif ($action === 'step') {
        $table = isset($_REQUEST['table']) ? sanitize_text_field($_REQUEST['table']) : '';
        $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
        $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 1000;
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        $write_structure = isset($_REQUEST['write_structure']) ? (bool)$_REQUEST['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.'));
            exit;
        }
        echo json_encode($backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure));
    } elseif ($action === 'finish') {
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        if (empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetro "backup_name" requerido.'));
            exit;
        }
        echo json_encode($backup_db->finish_chunk_backup($backup_name));
    }
} elseif ($action === 'files_incremental') {
    $backup_files_path = dirname(__FILE__) . '/includes/class-backup-files.php';
    if (!file_exists($backup_files_path)) {
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('success' => false, 'message' => 'Clase class-backup-files.php no encontrada.'));
        exit;
    }
    require_once($backup_files_path);

    $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
    $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 500;
    $type = isset($_REQUEST['type']) ? sanitize_text_field($_REQUEST['type']) : 'auto';
    $format = isset($_REQUEST['format']) ? sanitize_text_field($_REQUEST['format']) : 'zip';
    $excluded_files = array();
    if (isset($_REQUEST['excluded_files']) && is_array($_REQUEST['excluded_files'])) {
        $excluded_files = array_map('sanitize_text_field', $_REQUEST['excluded_files']);
    }

    $backup_files = new Sentinel_Backup_Files();
    echo json_encode($backup_files->run_backup($offset, $limit, $type, $excluded_files, $format));
} elseif ($action === 'status' || $action === 'site_info') {
    global $wpdb;

    $wp_version = '6.5';
    $version_file = ABSPATH . 'wp-includes/version.php';
    if (file_exists($version_file)) {
        include($version_file);
        if (isset($wp_version)) {
            $wp_version = $wp_version;
        }
    }

    $blogname = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'blogname'");
    $siteurl = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl'");

    $active_plugins_raw = $wpdb->get_var("SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'");
    $active_plugins_arr = !empty($active_plugins_raw) ? @unserialize($active_plugins_raw) : array();
    if (!is_array($active_plugins_arr)) { $active_plugins_arr = array(); }

    $plugins_dir = WP_CONTENT_DIR . '/plugins';
    $plugins_list = array();
    $total_plugins = 0;

    if (is_dir($plugins_dir)) {
        $files = scandir($plugins_dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $full_p = $plugins_dir . '/' . $file;
            $main_php = '';
            if (is_dir($full_p)) {
                $subfiles = glob($full_p . '/*.php');
                if ($subfiles) {
                    foreach ($subfiles as $sf) {
                        $c = file_get_contents($sf, false, null, 0, 1024);
                        if (strpos($c, 'Plugin Name:') !== false) {
                            $main_php = $sf;
                            break;
                        }
                    }
                }
            } elseif (is_file($full_p) && strpos($file, '.php') !== false) {
                $main_php = $full_p;
            }

            if ($main_php && file_exists($main_php)) {
                $c = file_get_contents($main_php, false, null, 0, 2048);
                preg_match('/Plugin Name:\s*(.*)$/mi', $c, $m_name);
                preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);

                $p_name = !empty($m_name[1]) ? trim($m_name[1]) : basename($main_php);
                $p_ver = !empty($m_ver[1]) ? trim($m_ver[1]) : '1.0.0';

                $rel_path = str_replace($plugins_dir . '/', '', $main_php);
                $is_active = in_array($rel_path, $active_plugins_arr);

                $plugins_list[] = array(
                    'name' => $p_name,
                    'version' => $p_ver,
                    'active' => (bool)$is_active,
                    'file' => $rel_path
                );
                $total_plugins++;
            }
        }
    }

    $sentinel_ver = '2.7.66';
    $sentinel_main = dirname(__FILE__) . '/sentinel.php';
    if (file_exists($sentinel_main)) {
        $c = file_get_contents($sentinel_main, false, null, 0, 1024);
        preg_match('/Version:\s*(.*)$/mi', $c, $m_ver);
        if (!empty($m_ver[1])) {
            $sentinel_ver = trim($m_ver[1]);
        }
    }

    $wpvivid_installed = is_dir(WP_CONTENT_DIR . '/plugins/wpvivid');
    $wpvivid_active = false;
    if ($wpvivid_installed) {
        foreach ($active_plugins_arr as $ap) {
            if (strpos($ap, 'wpvivid') !== false) {
                $wpvivid_active = true;
                break;
            }
        }
    }

    $db_size_bytes = 0;
    $db_data_size_bytes = 0;
    $db_index_size_bytes = 0;
    try {
        $db_status = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);
        if ($db_status) {
            foreach ($db_status as $row) {
                $data_len = isset($row['Data_length']) ? intval($row['Data_length']) : 0;
                $idx_len = isset($row['Index_length']) ? intval($row['Index_length']) : 0;
                $db_data_size_bytes += $data_len;
                $db_index_size_bytes += $idx_len;
                $db_size_bytes += ($data_len + $idx_len);
            }
        }
    } catch (Exception $e) {}

    echo json_encode(array(
        'status' => 'online',
        'site_name' => $blogname ? $blogname : 'Sitio WordPress',
        'site_url' => $siteurl,
        'wordpress' => $wp_version,
        'php' => PHP_VERSION,
        'mysql' => $wpdb->db_version(),
        'sentinel_version' => $sentinel_ver,
        'total_plugins' => $total_plugins,
        'pending_updates' => 0,
        'plugins' => $plugins_list,
        'themes' => array(),
        'wpvivid_installed' => $wpvivid_installed,
        'wpvivid_active' => $wpvivid_active,
        'db_size_bytes' => $db_size_bytes,
        'db_data_size_bytes' => $db_data_size_bytes,
        'db_index_size_bytes' => $db_index_size_bytes,
        'uploads_size_bytes' => 0,
        'shortinit_bypass' => true,
        'waf_bypassed' => true
    ));
    exit;

} elseif ($action === 'download_backup') {
    $raw_file = isset($_GET['file']) ? trim($_GET['file']) : (isset($_POST['file']) ? trim($_POST['file']) : '');
    if (empty($raw_file)) {
        http_response_code(400);
        echo json_encode(array('success' => false, 'message' => 'Especifica un archivo.'));
        exit;
    }

    if (!preg_match('/^[a-zA-Z0-9_\\-\\.]+\\.(zip|tar|gz|sql|tmp|jpa|jps|wpress)$/i', $raw_file)) {
        http_response_code(400);
        echo json_encode(array('success' => false, 'message' => 'Nombre de archivo no válido.'));
        exit;
    }
    $file = $raw_file;

    $file_path = '';
    $uploads = wp_upload_dir();
    $search_dirs = array(
        trailingslashit(WP_CONTENT_DIR) . 'ai1wm-backups/',
        trailingslashit(WP_CONTENT_DIR) . 'wpvividbackups/',
        trailingslashit($uploads['basedir']) . 'sentinel-backups/',
        trailingslashit($uploads['basedir']) . 'sentinel-backups/db/',
        trailingslashit($uploads['basedir']) . 'sentinel-backups/files/',
        trailingslashit(WP_PLUGIN_DIR) . 'akeebabackupwp/app/backups/'
    );

    foreach ($search_dirs as $dir) {
        if (!is_dir($dir)) continue;
        if (file_exists($dir . $file) && is_file($dir . $file)) {
            $file_path = $dir . $file;
            break;
        }
        $entries = @scandir($dir);
        if ($entries) {
            foreach ($entries as $e) {
                if ($e !== '.' && $e !== '..' && is_dir($dir . $e)) {
                    if (file_exists($dir . $e . '/' . $file) && is_file($dir . $e . '/' . $file)) {
                        $file_path = $dir . $e . '/' . $file;
                        break 2;
                    }
                }
            }
        }
    }

    if (empty($file_path) || !file_exists($file_path) || !is_readable($file_path)) {
        http_response_code(404);
        echo json_encode(array('success' => false, 'message' => 'El archivo no existe en el servidor.'));
        exit;
    }

    while (ob_get_level() > 0) {
        @ob_end_clean();
    }

    @set_time_limit(0);
    if (function_exists('apache_setenv')) {
        @apache_setenv('no-gzip', 1);
    }
    @ini_set('zlib.output_compression', 0);

    $file_size = filesize($file_path);
    $start = 0;
    $end = $file_size - 1;

    if (isset($_SERVER['HTTP_RANGE'])) {
        if (preg_match('/bytes=\s*(\\d+)-(\\d*)/i', $_SERVER['HTTP_RANGE'], $matches)) {
            $start = floatval($matches[1]);
            if (!empty($matches[2])) {
                $end = floatval($matches[2]);
            }
        }
    }

    $is_range = ($start > 0 || $end < ($file_size - 1));
    http_response_code($is_range ? 206 : 200);

    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Expires: 0');
    header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Accept-Ranges: bytes');
    header('X-Sentinel-File-Hash: ');

    if ($is_range) {
        header("Content-Range: bytes $start-$end/$file_size");
    }

    $content_length = $end - $start + 1;
    header('Content-Length: ' . $content_length);

    $fp = fopen($file_path, 'rb');
    if (!$fp) {
        http_response_code(500);
        exit;
    }

    fseek($fp, $start);
    $chunk_size = 64 * 1024;
    $bytes_sent = 0;

    while (!feof($fp) && $bytes_sent < $content_length && (connection_status() == 0)) {
        $to_read = min($chunk_size, $content_length - $bytes_sent);
        $buf = fread($fp, $to_read);
        echo $buf;
        flush();
        $bytes_sent += strlen($buf);
    }

    fclose($fp);
    exit;

} else {
    echo json_encode(array('success' => false, 'message' => 'Acción no válida.'));
}
