<?php
/**
 * Plugin Name: Sentinel
 * Description: Agente WordPress pasivo inteligente para persistencia local y mantenimiento.
 * Version: 2.7.48-beta
 * Author: Sentinel
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

// Versión y Rutas
define('SENTINEL_VERSION', '2.7.48');
define('SENTINEL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SENTINEL_PLUGIN_URL', plugin_dir_url(__FILE__));

// Carga de clases requeridas
require_once SENTINEL_PLUGIN_DIR . 'includes/class-github-updater.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-sqlite-db.php';
if (function_exists('opcache_invalidate')) {
    @opcache_invalidate(SENTINEL_PLUGIN_DIR . 'includes/class-api-handler.php', true);
}
require_once SENTINEL_PLUGIN_DIR . 'includes/class-api-handler.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-collector.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-indexer.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-journal.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-db-analyzer.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-classification-engine.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-snapshot-engine.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-delta-engine.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-file-classification.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-malware-scanner.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-component-discovery.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-fingerprint-generator.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-overlay-detector.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-recovery-workspace.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-file-recovery.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-database-recovery.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-rollback-engine.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-backup-db.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-backup-files.php';
require_once SENTINEL_PLUGIN_DIR . 'includes/class-updater.php';


// Generar UUID v4 si no existe
if (!get_option('controlcenter_agent_uuid')) {
    // Generación manual simple de UUID v4 compatible con PHP sin depender de librerías externas
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10
    $uuid = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    update_option('controlcenter_agent_uuid', $uuid);
}

// Generar clave secreta hexadecimal de 128 caracteres si no existe
if (!get_option('controlcenter_agent_secret')) {
    update_option('controlcenter_agent_secret', bin2hex(random_bytes(64)));
}

class Sentinel {

    private static $instance = null;

    /**
     * Obtener instancia Singleton
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Registrar gancho de activación
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Inicializa los submódulos de la aplicación
        add_action('plugins_loaded', array($this, 'init_components'));

        // Registrar ganchos AJAX para el Panel de Control
        add_action('wp_ajax_sentinel_scan_ajax', array($this, 'ajax_trigger_scan'));
        add_action('wp_ajax_sentinel_db_ajax', array($this, 'ajax_trigger_db_analyze'));
        add_action('wp_ajax_sentinel_clean_ajax', array($this, 'ajax_clean_workspace'));

        // Verificar la versión del plugin y limpiar la caché de transitorios si es necesario
        $saved_version = get_option('sentinel_installed_version');
        if ($saved_version !== SENTINEL_VERSION) {
            delete_site_transient('update_plugins');
            delete_transient('sentinel_github_update_info');
            update_option('sentinel_installed_version', SENTINEL_VERSION);
        }
    }

    /**
     * Disparadores AJAX
     */
    public function ajax_trigger_scan() {
        check_admin_referer('sentinel_ajax_action', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'No tienes permisos suficientes.'));
        }
        
        try {
            // Comprobar si la extensión PDO SQLite está cargada
            if (!extension_loaded('pdo_sqlite')) {
                throw new Exception('La extensión PDO SQLite no está cargada en el servidor PHP.');
            }

            // Asegurar que el directorio de índices existe en ejecución
            $indexes_dir = WP_CONTENT_DIR . '/controlcenter/indexes';
            if (!file_exists($indexes_dir)) {
                wp_mkdir_p($indexes_dir);
                @chmod($indexes_dir, 0755);
            }
            
            $files_db = $indexes_dir . '/files.db';
            if (!is_writable($indexes_dir) || (file_exists($files_db) && !is_writable($files_db))) {
                throw new Exception('No hay permisos de escritura en la carpeta de índices o el archivo files.db.');
            }

            $db = Sentinel_SQLite_DB::get_instance();
            $db_conn = $db->get_files_connection();
            if (!$db_conn) {
                throw new Exception('No se puede abrir o escribir en la base de datos files.db.');
            }

            $status = Sentinel_Indexer::get_instance()->build_index(500);
            
            // Obtener el conteo real de archivos indexados actual (excluyendo los eliminados)
            $res = $db->query_files("SELECT COUNT(*) as cnt FROM files WHERE status != 'DELETED'");
            $count = $res ? intval($res[0]['cnt']) : 0;
            
            wp_send_json_success(array(
                'status'  => $status,
                'count'   => $count,
                'message' => 'Indexación ejecutada. Estado: ' . $status . '. Total indexado: ' . $count . ' archivo(s).'
            ));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    public function ajax_trigger_db_analyze() {
        check_admin_referer('sentinel_ajax_action', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }
        $result = Sentinel_DB_Analyzer::get_instance()->analyze_database();
        Sentinel_Classification_Engine::get_instance()->classify_all_tables();
        wp_send_json_success($result);
    }

    public function ajax_clean_workspace() {
        check_admin_referer('sentinel_ajax_action', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error();
        }
        $result = Sentinel_Recovery_Workspace::get_instance()->clean_workspace();
        wp_send_json_success($result);
    }

    /**
     * Activación del plugin - Crea directorios y base de datos
     */
    public function activate() {
        $controlcenter_dir = WP_CONTENT_DIR . '/controlcenter';
        if (!file_exists($controlcenter_dir)) {
            wp_mkdir_p($controlcenter_dir);
        }

        $directories = array(
            'data',
            'indexes',
            'journals',
            'snapshots',
            'cache',
            'recovery',
            'logs',
            'temp'
        );

        foreach ($directories as $dir) {
            $full_path = $controlcenter_dir . '/' . $dir;
            if (!file_exists($full_path)) {
                wp_mkdir_p($full_path);
            }
            
            // Crear index.html para seguridad en cada carpeta
            if (!file_exists($full_path . '/index.html')) {
                file_put_contents($full_path . '/index.html', '');
            }
        }

        // Escribir archivo de configuración autónomo para recovery.php
        $agent_uuid = get_option('controlcenter_agent_uuid');
        $agent_secret = get_option('controlcenter_agent_secret');
        if ($agent_uuid && $agent_secret) {
            $config_content = "<?php\nreturn array(\n    'agent_uuid' => " . var_export($agent_uuid, true) . ",\n    'agent_secret' => " . var_export($agent_secret, true) . "\n);\n";
            file_put_contents($controlcenter_dir . '/data/config.php', $config_content);
        }

        // Copiar el archivo recovery.php al directorio autónomo y a la raíz de WordPress para evadir Mod_Security
        $source_recovery = SENTINEL_PLUGIN_DIR . 'recovery/recovery.php';
        $dest_recovery = $controlcenter_dir . '/recovery/recovery.php';
        $dest_recovery_root = ABSPATH . 'sentinel-recovery.php';
        if (file_exists($source_recovery)) {
            copy($source_recovery, $dest_recovery);
            copy($source_recovery, $dest_recovery_root);
        }

        // Instalar el MU-Plugin para interceptación de recuperación en index.php
        $mu_plugins_dir = WP_CONTENT_DIR . '/mu-plugins';
        if (!file_exists($mu_plugins_dir)) {
            wp_mkdir_p($mu_plugins_dir);
        }
        $source_mu = SENTINEL_PLUGIN_DIR . 'includes/recovery/sentinel-recovery-mu.php';
        $dest_mu = $mu_plugins_dir . '/sentinel-recovery-mu.php';
        if (file_exists($source_mu)) {
            copy($source_mu, $dest_mu);
        }

        // Bloquear el acceso HTTP directo en la raíz de controlcenter
        if (!file_exists($controlcenter_dir . '/.htaccess')) {
            $htaccess_rules = "Order deny,allow\nDeny from all\n\n<Files ~ \"^recovery\\.php$\">\n    Allow from all\n</Files>";
            file_put_contents($controlcenter_dir . '/.htaccess', $htaccess_rules);
        }
        
        if (!file_exists($controlcenter_dir . '/index.html')) {
            file_put_contents($controlcenter_dir . '/index.html', '');
        }

        // Inicializar archivos SQLite si no existen
        $files_db = $controlcenter_dir . '/indexes/files.db';
        $events_db = $controlcenter_dir . '/journals/events.db';

        if (!file_exists($files_db)) {
            if (!file_exists(dirname($files_db))) {
                wp_mkdir_p(dirname($files_db));
            }
            touch($files_db);
        }

        if (!file_exists($events_db)) {
            if (!file_exists(dirname($events_db))) {
                wp_mkdir_p(dirname($events_db));
            }
            touch($events_db);
        }
        
        // Inicializar esquemas SQLite
        try {
            if (extension_loaded('pdo_sqlite')) {
                // files.db schema
                $pdo_files = new PDO('sqlite:' . $files_db);
                $pdo_files->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo_files->exec("CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE,
                    size INTEGER,
                    mtime INTEGER,
                    hash TEXT,
                    status TEXT,
                    last_scan INTEGER
                )");
                $pdo_files->exec("CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type TEXT,
                    payload TEXT,
                    status TEXT,
                    created_at INTEGER,
                    started_at INTEGER,
                    finished_at INTEGER
                )");
                
                // events.db schema
                $pdo_events = new PDO('sqlite:' . $events_db);
                $pdo_events->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo_events->exec("CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT,
                    timestamp INTEGER,
                    payload TEXT
                )");
            }
        } catch (Exception $e) {
            error_log("Error inicializando bases de datos SQLite de Sentinel: " . $e->getMessage());
        }
    }

    /**
     * Inicializa los submódulos de la aplicación
     */
    public function init_components() {
        if (class_exists('Sentinel_SQLite_DB')) {
            Sentinel_SQLite_DB::get_instance();
        }
        if (class_exists('Sentinel_API_Handler')) {
            Sentinel_API_Handler::get_instance();
        }
        if (class_exists('Sentinel_Collector')) {
            Sentinel_Collector::get_instance();
        }
        if (class_exists('Sentinel_Indexer')) {
            Sentinel_Indexer::get_instance();
        }
        if (class_exists('Sentinel_Journal')) {
            Sentinel_Journal::get_instance();
        }
        if (class_exists('Sentinel_DB_Analyzer')) {
            Sentinel_DB_Analyzer::get_instance();
        }
        if (class_exists('Sentinel_Classification_Engine')) {
            Sentinel_Classification_Engine::get_instance();
        }
        if (class_exists('Sentinel_Snapshot_Engine')) {
            Sentinel_Snapshot_Engine::get_instance();
        }
        if (class_exists('Sentinel_Delta_Engine')) {
            Sentinel_Delta_Engine::get_instance();
        }
        if (class_exists('Sentinel_File_Classification')) {
            Sentinel_File_Classification::get_instance();
        }
        if (class_exists('Sentinel_Malware_Scanner')) {
            Sentinel_Malware_Scanner::get_instance();
        }
        if (class_exists('Sentinel_Component_Discovery')) {
            Sentinel_Component_Discovery::get_instance();
        }
        if (class_exists('Sentinel_Fingerprint_Generator')) {
            Sentinel_Fingerprint_Generator::get_instance();
        }
        if (class_exists('Sentinel_Overlay_Detector')) {
            Sentinel_Overlay_Detector::get_instance();
        }
        if (class_exists('Sentinel_Recovery_Workspace')) {
            Sentinel_Recovery_Workspace::get_instance();
        }
        if (class_exists('Sentinel_File_Recovery')) {
            Sentinel_File_Recovery::get_instance();
        }
        if (class_exists('Sentinel_Database_Recovery')) {
            Sentinel_Database_Recovery::get_instance();
        }
        if (class_exists('Sentinel_Rollback_Engine')) {
            Sentinel_Rollback_Engine::get_instance();
        }
    }

    /**
     * Renderiza la página del plugin en el panel de administración
     */
    public function render_admin_page() {
        if (isset($_POST['sentinel_import_credentials']) && isset($_POST['import_uuid']) && isset($_POST['import_secret'])) {
            check_admin_referer('sentinel_import_creds', 'sentinel_import_creds_nonce');
            if (!current_user_can('manage_options')) {
                wp_die('No tienes permisos suficientes.');
            }
            
            $import_uuid = sanitize_text_field($_POST['import_uuid']);
            $import_secret = sanitize_text_field($_POST['import_secret']);
            
            $valid_uuid = preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $import_uuid);
            $valid_secret = preg_match('/^[a-f0-9]{128}$/i', $import_secret);
            
            if ($valid_uuid && $valid_secret) {
                update_option('controlcenter_agent_uuid', $import_uuid);
                update_option('controlcenter_agent_secret', $import_secret);
                
                $controlcenter_dir = WP_CONTENT_DIR . '/controlcenter';
                if (!file_exists($controlcenter_dir . '/data')) {
                    wp_mkdir_p($controlcenter_dir . '/data');
                }
                $config_content = "<?php\nreturn array(\n    'agent_uuid' => " . var_export($import_uuid, true) . ",\n    'agent_secret' => " . var_export($import_secret, true) . "\n);\n";
                file_put_contents($controlcenter_dir . '/data/config.php', $config_content);
                
                echo '<div class="notice notice-success is-dismissible"><p>Credenciales de migración establecidas correctamente y archivo config.php regenerado.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Error: UUID o Secret Key inválidos. El UUID debe ser v4 y el Secret Key debe ser hexadecimal de 128 caracteres.</p></div>';
            }
        }

        $agent_uuid = get_option('controlcenter_agent_uuid');
        $agent_secret = get_option('controlcenter_agent_secret');
        $endpoint_url = get_rest_url(null, '/controlcenter/v1');
        if (!$endpoint_url) {
            $endpoint_url = site_url('/wp-json/controlcenter/v1');
        }

        ?>
        <div class="wrap sentinel-wrap" style="max-width: 1100px; margin: 30px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;">
            <h2 class="wp-header-end" style="display:none;"></h2>
            
            <style>
                .sentinel-header-main {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 25px;
                    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
                    padding: 25px 35px;
                    border-radius: 12px;
                    color: #ffffff;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
                }
                .sentinel-logo-section {
                    display: flex;
                    align-items: center;
                    gap: 15px;
                }
                .sentinel-logo-section h1 {
                    color: #ffffff;
                    font-size: 28px;
                    font-weight: 800;
                    margin: 0;
                    letter-spacing: -0.5px;
                    line-height: 1.2;
                }
                .sentinel-badge-status {
                    background: #10b981;
                    color: #ffffff;
                    padding: 5px 12px;
                    border-radius: 20px;
                    font-size: 11px;
                    font-weight: 700;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                }
                .sentinel-grid {
                    display: grid;
                    grid-template-columns: 2fr 1fr;
                    gap: 25px;
                }
                @media (max-width: 782px) {
                    .sentinel-grid {
                        grid-template-columns: 1fr;
                    }
                }
                .sentinel-card-dashboard {
                    background: #ffffff;
                    border: 1px solid #e2e8f0;
                    border-radius: 12px;
                    padding: 25px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
                    margin-bottom: 25px;
                }
                .sentinel-card-title {
                    font-size: 18px;
                    font-weight: 700;
                    color: #0f172a;
                    margin-top: 0;
                    margin-bottom: 20px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    border-bottom: 1px solid #f1f5f9;
                    padding-bottom: 12px;
                }
                .sentinel-credential-row {
                    margin-bottom: 18px;
                }
                .sentinel-meta-label {
                    font-size: 12px;
                    font-weight: 700;
                    color: #64748b;
                    text-transform: uppercase;
                    margin-bottom: 6px;
                }
                .sentinel-copy-box {
                    background: #f8fafc;
                    border: 1px solid #cbd5e1;
                    border-radius: 8px;
                    padding: 10px 14px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    font-family: 'Courier New', Courier, monospace;
                    font-size: 13px;
                    color: #334155;
                    word-break: break-all;
                }
                .sentinel-copy-btn {
                    background: #3b82f6;
                    color: #ffffff;
                    border: none;
                    padding: 6px 12px;
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 700;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    margin-left: 10px;
                    white-space: nowrap;
                }
                .sentinel-copy-btn:hover {
                    background: #2563eb;
                }
                .sentinel-stat-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 15px;
                    margin-bottom: 20px;
                }
                .sentinel-stat-box {
                    background: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    padding: 15px;
                    text-align: center;
                }
                .sentinel-stat-number {
                    font-size: 24px;
                    font-weight: 800;
                    color: #0f172a;
                }
                .sentinel-stat-desc {
                    font-size: 12px;
                    color: #64748b;
                    margin-top: 4px;
                }
                .sentinel-action-bar {
                    display: flex;
                    gap: 10px;
                    margin-top: 15px;
                }
                .sentinel-btn-primary {
                    background: #0f172a;
                    color: #ffffff;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    font-size: 13px;
                }
                .sentinel-btn-primary:hover {
                    background: #1e293b;
                }
                .sentinel-btn-secondary {
                    background: #ffffff;
                    color: #0f172a;
                    border: 1px solid #cbd5e1;
                    padding: 10px 20px;
                    border-radius: 8px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    font-size: 13px;
                }
                .sentinel-btn-secondary:hover {
                    background: #f8fafc;
                }
                .sentinel-table-view {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 13px;
                }
                .sentinel-table-view th {
                    text-align: left;
                    padding: 10px;
                    background: #f1f5f9;
                    color: #475569;
                    font-weight: 700;
                }
                .sentinel-table-view td {
                    padding: 10px;
                    border-bottom: 1px solid #f1f5f9;
                    color: #334155;
                }
                .sentinel-table-view td code {
                    word-break: break-all;
                    white-space: pre-wrap;
                }
                .sentinel-badge-cat {
                    padding: 3px 8px;
                    border-radius: 4px;
                    font-size: 10px;
                    font-weight: 700;
                }
                .cat-a { background: #fee2e2; color: #991b1b; }
                .cat-b { background: #ffedd5; color: #9a3412; }
                .cat-c { background: #e0f2fe; color: #075985; }
                .cat-d { background: #dcfce7; color: #166534; }
                .cat-e { background: #f3e8ff; color: #6b21a8; }
                .cat-f { background: #f1f5f9; color: #334155; }
            </style>

            <div class="sentinel-header-main">
                <div class="sentinel-logo-section">
                    <span class="dashicons dashicons-shield-alt" style="font-size: 36px; width: 36px; height: 36px; color: #38bdf8;"></span>
                    <div>
                        <h1>Sentinel Agent</h1>
                        <span style="font-size: 12px; color: #94a3b8;">v<?php echo esc_html(SENTINEL_VERSION); ?> — Motor Pasivo de Deduplicación y Recuperación</span>
                    </div>
                </div>
                <div>
                    <span class="sentinel-badge-status">En Línea</span>
                </div>
            </div>

            <div class="sentinel-grid">
                <div class="sentinel-main-col">
                    <!-- Sección de Métricas -->
                    <div class="sentinel-card-dashboard">
                        <h3 class="sentinel-card-title">
                            <span class="dashicons dashicons-dashboard" style="color: #64748b;"></span>
                            Estado del Inventario de Archivos y Base de Datos
                        </h3>
                        <div class="sentinel-stat-grid">
                            <div class="sentinel-stat-box">
                                <div class="sentinel-stat-number" id="stats-total-files">
                                    <?php 
                                    $db = Sentinel_SQLite_DB::get_instance();
                                    $res = $db->query_files("SELECT COUNT(*) as cnt FROM files WHERE status != 'DELETED'");
                                    echo $res ? esc_html($res[0]['cnt']) : '0';
                                    ?>
                                </div>
                                <div class="sentinel-stat-desc">Archivos Indexados</div>
                            </div>
                            <div class="sentinel-stat-box">
                                <div class="sentinel-stat-number" id="stats-total-tables">
                                    <?php 
                                    global $wpdb;
                                    $tables = $wpdb->get_col("SHOW TABLES");
                                    echo esc_html(count($tables));
                                    ?>
                                </div>
                                <div class="sentinel-stat-desc">Tablas Catalogadas</div>
                            </div>
                            <div class="sentinel-stat-box">
                                <div class="sentinel-stat-number" id="stats-workspace-size">
                                    <?php 
                                    $workspace_dir = Sentinel_Recovery_Workspace::WORKSPACE_DIR;
                                    if (file_exists($workspace_dir)) {
                                        $size = 0;
                                        $iterator = new RecursiveIteratorIterator(
                                            new RecursiveDirectoryIterator($workspace_dir, RecursiveDirectoryIterator::SKIP_DOTS)
                                        );
                                        foreach ($iterator as $file) {
                                            $size += $file->getSize();
                                        }
                                        echo esc_html(round($size / (1024 * 1024), 2)) . ' MB';
                                    } else {
                                        echo '0.00 MB';
                                    }
                                    ?>
                                </div>
                                <div class="sentinel-stat-desc">Workspace Temporal</div>
                            </div>
                        </div>

                        <div class="sentinel-action-bar">
                            <button class="sentinel-btn-primary" onclick="triggerIndexScan(this)">Indexar Cambios por Lotes</button>
                            <button class="sentinel-btn-secondary" onclick="triggerDBAnalysis(this)">Re-analizar Estructuras</button>
                            <button class="sentinel-btn-secondary" style="border-color: #f87171; color: #ef4444;" onclick="cleanWorkspace(this)">Vaciar Workspace</button>
                        </div>
                    </div>

                    <!-- Últimos Archivos Indexados -->
                    <div class="sentinel-card-dashboard">
                        <h3 class="sentinel-card-title">
                            <span class="dashicons dashicons-index-card" style="color: #64748b;"></span>
                            Últimas Clasificaciones de Archivos
                        </h3>
                        <table class="sentinel-table-view">
                            <thead>
                                <tr>
                                    <th>Ruta Relativa</th>
                                    <th>Categoría</th>
                                    <th>Última Indexación</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $latest_files = $db->query_files("SELECT path, classification, last_seen FROM files ORDER BY last_seen DESC LIMIT 5");
                                if (!empty($latest_files)) {
                                    foreach ($latest_files as $file) {
                                        $cat_class = 'cat-f';
                                        $cat_name = 'F (Otros)';
                                        switch ($file['classification']) {
                                            case 'A': $cat_class = 'cat-a'; $cat_name = 'A (Core)'; break;
                                            case 'B': $cat_class = 'cat-b'; $cat_name = 'B (Plugins)'; break;
                                            case 'C': $cat_class = 'cat-c'; $cat_name = 'C (Temas)'; break;
                                            case 'D': $cat_class = 'cat-d'; $cat_name = 'D (Media)'; break;
                                            case 'E': $cat_class = 'cat-e'; $cat_name = 'E (Derivados)'; break;
                                        }
                                        ?>
                                        <tr>
                                            <td><code><?php echo esc_html($file['path']); ?></code></td>
                                            <td><span class="sentinel-badge-cat <?php echo $cat_class; ?>"><?php echo esc_html($cat_name); ?></span></td>
                                            <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $file['last_seen'])); ?></td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo '<tr><td colspan="3" style="text-align: center; color: #94a3b8;">No hay archivos indexados aún.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Barra Lateral de Conectores -->
                <div class="sentinel-side-col">
                    <div class="sentinel-card-dashboard" style="border-top: 4px solid #3b82f6;">
                        <h3 class="sentinel-card-title">
                            <span class="dashicons dashicons-admin-network" style="color: #3b82f6;"></span>
                            Credenciales de Conexión
                        </h3>
                        <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin-bottom: 20px;">
                            El agente funciona de modo estrictamente **PULL**. Copia esta firma y endpoint en tu Control Center para autorizar las solicitudes HMAC.
                        </p>

                        <div class="sentinel-credential-row">
                            <div class="sentinel-meta-label">UUID del Agente</div>
                            <div class="sentinel-copy-box">
                                <span id="cc-uuid"><?php echo esc_html($agent_uuid); ?></span>
                                <button class="sentinel-copy-btn" onclick="copyText('cc-uuid', this)">Copiar</button>
                            </div>
                        </div>

                        <div class="sentinel-credential-row">
                            <div class="sentinel-meta-label">Endpoint de Comunicación</div>
                            <div class="sentinel-copy-box">
                                <span id="cc-endpoint"><?php echo esc_url($endpoint_url); ?></span>
                                <button class="sentinel-copy-btn" onclick="copyText('cc-endpoint', this)">Copiar</button>
                            </div>
                        </div>

                        <div class="sentinel-credential-row">
                            <div class="sentinel-meta-label">Clave HMAC (Secreto)</div>
                            <div class="sentinel-copy-box">
                                <span id="cc-secret" style="-webkit-text-security: disc;"><?php echo esc_html($agent_secret); ?></span>
                                <button class="sentinel-copy-btn" onclick="toggleSecret(this)">Ver</button>
                                <button class="sentinel-copy-btn" onclick="copyTextDirectly('<?php echo esc_js($agent_secret); ?>', this)">Copiar</button>
                            </div>
                        </div>
                    </div>

                    <!-- Formulario de Importación de Credenciales -->
                    <div class="sentinel-card-dashboard" style="border-top: 4px solid #a29bfe; margin-top: 25px;">
                        <h3 class="sentinel-card-title">
                            <span class="dashicons dashicons-admin-links" style="color: #a29bfe;"></span>
                            Importar Credenciales de Migración
                        </h3>
                        <p style="font-size: 13px; color: #64748b; line-height: 1.5; margin-bottom: 20px;">
                            Establece manualmente el UUID y la Secret Key generadas por otro Control Center para migrar o sincronizar este sitio.
                        </p>
                        <form method="post" action="">
                            <?php wp_nonce_field('sentinel_import_creds', 'sentinel_import_creds_nonce'); ?>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 6px;">Nuevo UUID v4</label>
                                <input type="text" name="import_uuid" required placeholder="ej. 12345678-1234-4123-a123-1234567890ab" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-family: monospace; font-size: 13px;" />
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 6px;">Nueva Secret Key (Hex 128 chars)</label>
                                <input type="text" name="import_secret" required placeholder="Clave hexadecimal de 128 caracteres" style="width: 100%; padding: 8px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-family: monospace; font-size: 13px;" />
                            </div>
                            
                            <div style="margin-top: 20px;">
                                <input type="submit" name="sentinel_import_credentials" class="button button-primary sentinel-btn-primary" value="Establecer Credenciales de Migración" style="width: 100%; height: auto; padding: 10px 15px; border-radius: 8px; font-weight: 600; line-height: 1.2;" />
                            </div>
                        </form>
                    </div>

                    <!-- Diagnóstico de Sistema -->
                    <div class="sentinel-card-dashboard" style="border-top: 4px solid #10b981; margin-top: 25px;">
                        <h3 class="sentinel-card-title">
                            <span class="dashicons dashicons-performance" style="color: #10b981;"></span>
                            Diagnóstico del Sistema
                        </h3>
                        <?php
                        // 1. Estado de PDO SQLite
                        $pdo_sqlite_loaded = extension_loaded('pdo_sqlite');
                        
                        // 2. Ruta files.db
                        $indexes_dir = WP_CONTENT_DIR . '/controlcenter/indexes';
                        $files_db_path = $indexes_dir . '/files.db';
                        
                        // 3. Permisos
                        $dir_writable = is_writable($indexes_dir);
                        $db_file_writable = file_exists($files_db_path) ? is_writable($files_db_path) : $dir_writable;
                        
                        // 4. Conexión a files.db
                        $db_instance = Sentinel_SQLite_DB::get_instance();
                        $db_conn = $db_instance->get_files_connection();
                        $can_connect = ($db_conn !== null);
                        
                        // 5. Tamaño files.db
                        $db_size_kb = 0;
                        if (file_exists($files_db_path)) {
                            $db_size_kb = round(filesize($files_db_path) / 1024, 2);
                        }
                        
                        // 6. Columnas de 'files'
                        $files_columns = [];
                        $table_exists = false;
                        if ($can_connect) {
                            try {
                                $res_table = $db_conn->query("SELECT name FROM sqlite_master WHERE type='table' AND name='files';")->fetchAll();
                                if (!empty($res_table)) {
                                    $table_exists = true;
                                    $files_columns = $db_conn->query("PRAGMA table_info(files);")->fetchAll(PDO::FETCH_ASSOC);
                                }
                            } catch (Exception $e) {
                                // Ignorar
                            }
                        }
                        
                        // 7. scan_queue y scan_state count
                        $scan_queue_count = 0;
                        $scan_state_count = 0;
                        if ($can_connect) {
                            try {
                                $res_q = $db_conn->query("SELECT COUNT(*) as cnt FROM scan_queue;")->fetch(PDO::FETCH_ASSOC);
                                if ($res_q) { $scan_queue_count = intval($res_q['cnt']); }
                                
                                $res_s = $db_conn->query("SELECT COUNT(*) as cnt FROM scan_state;")->fetch(PDO::FETCH_ASSOC);
                                if ($res_s) { $scan_state_count = intval($res_s['cnt']); }
                            } catch (Exception $e) {
                                // Ignorar
                            }
                        }
                        ?>
                        
                        <div class="sentinel-diagnostic-section" style="font-size: 13px; color: #334155; line-height: 1.6;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Extensión PDO SQLite</span>
                                <span style="font-weight: 700; color: <?php echo $pdo_sqlite_loaded ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $pdo_sqlite_loaded ? 'Cargada' : 'No cargada'; ?>
                                </span>
                            </div>
                            
                            <div style="margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <div style="font-weight: 600; color: #475569; margin-bottom: 4px;">Ruta de Base de Datos</div>
                                <code style="word-break: break-all; display: block; background: #f8fafc; padding: 6px; border-radius: 4px; font-size: 11px; color: #64748b; border: 1px solid #e2e8f0;"><?php echo esc_html($files_db_path); ?></code>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Escritura Carpeta</span>
                                <span style="font-weight: 700; color: <?php echo $dir_writable ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $dir_writable ? 'Escritura OK' : 'Sin permisos'; ?>
                                </span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Escritura Archivo DB</span>
                                <span style="font-weight: 700; color: <?php echo $db_file_writable ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $db_file_writable ? 'Escritura OK' : 'Sin permisos / No existe'; ?>
                                </span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Conexión a files.db</span>
                                <span style="font-weight: 700; color: <?php echo $can_connect ? '#10b981' : '#ef4444'; ?>;">
                                    <?php echo $can_connect ? 'Conectado' : 'Fallo de conexión'; ?>
                                </span>
                            </div>
                            
                            <?php if (!$can_connect && !empty($db_instance->last_error)): ?>
                            <div style="margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; background: #fee2e2; padding: 6px; border-radius: 4px; border: 1px solid #fca5a5;">
                                <div style="font-weight: 600; color: #991b1b; margin-bottom: 2px;">Detalle de Error PDO:</div>
                                <code style="word-break: break-all; display: block; font-size: 11px; color: #b91c1c;"><?php echo esc_html($db_instance->last_error); ?></code>
                            </div>
                            <?php endif; ?>
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Tamaño files.db</span>
                                <span style="font-weight: 700; color: #0f172a;"><?php echo $db_size_kb; ?> KB</span>
                            </div>
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 15px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px;">
                                <span style="font-weight: 600; color: #475569;">Filas scan_queue / scan_state</span>
                                <span style="font-weight: 700; color: #0f172a;"><?php echo $scan_queue_count; ?> / <?php echo $scan_state_count; ?></span>
                            </div>

                            <div style="margin-top: 15px;">
                                <div style="font-weight: 600; color: #475569; margin-bottom: 6px;">Columnas de la tabla 'files':</div>
                                <?php if ($table_exists && !empty($files_columns)): ?>
                                    <div style="max-height: 150px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 6px;">
                                        <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left;">
                                            <thead>
                                                <tr style="background: #f1f5f9; border-bottom: 1px solid #cbd5e1;">
                                                    <th style="padding: 4px 8px; color: #475569;">Columna</th>
                                                    <th style="padding: 4px 8px; color: #475569;">Tipo</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($files_columns as $col): ?>
                                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                                        <td style="padding: 4px 8px; font-family: monospace; color: #0f172a;"><?php echo esc_html($col['name']); ?></td>
                                                        <td style="padding: 4px 8px; color: #64748b;"><?php echo esc_html($col['type']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <div style="background: #fee2e2; color: #991b1b; padding: 8px; border-radius: 6px; font-size: 12px; border: 1px solid #fca5a5;">
                                        La tabla 'files' no existe o la base de datos está vacía.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            const sentinelNonce = "<?php echo esc_js(wp_create_nonce('sentinel_ajax_action')); ?>";

            function copyText(elementId, btn) {
                const text = document.getElementById(elementId).innerText;
                navigator.clipboard.writeText(text);
                const originalText = btn.innerText;
                btn.innerText = "¡Listo!";
                btn.style.background = "#10b981";
                setTimeout(() => {
                    btn.innerText = originalText;
                    btn.style.background = "#3b82f6";
                }, 2000);
            }

            function copyTextDirectly(text, btn) {
                navigator.clipboard.writeText(text);
                const originalText = btn.innerText;
                btn.innerText = "¡Listo!";
                btn.style.background = "#10b981";
                setTimeout(() => {
                    btn.innerText = originalText;
                    btn.style.background = "#3b82f6";
                }, 2000);
            }

            function toggleSecret(btn) {
                const span = document.getElementById('cc-secret');
                if (span.style.webkitTextSecurity === 'disc') {
                    span.style.webkitTextSecurity = 'none';
                    btn.innerText = "Ocultar";
                } else {
                    span.style.webkitTextSecurity = 'disc';
                    btn.innerText = "Ver";
                }
            }

            function triggerIndexScan(btn, isContinuation = false) {
                btn.disabled = true;
                if (!isContinuation) {
                    btn.innerText = "Iniciando escaneo...";
                }
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: { 
                        action: 'sentinel_scan_ajax',
                        nonce: sentinelNonce
                    },
                    success: function(response) {
                        if (response.success) {
                            var status = response.data.status;
                            var count = response.data.count;
                            if (status === 'PENDING') {
                                btn.innerText = "Escaneando... (" + count + " archivos)";
                                triggerIndexScan(btn, true);
                            } else {
                                btn.disabled = false;
                                btn.innerText = "Indexar Cambios por Lotes";
                                alert("Indexación completada. Total indexado: " + count + " archivos.");
                                location.reload();
                            }
                        } else {
                            btn.disabled = false;
                            btn.innerText = "Indexar Cambios por Lotes";
                            alert("Error al indexar: " + (response.data.message || "Error desconocido."));
                        }
                    },
                    error: function(xhr, status, error) {
                        btn.disabled = false;
                        btn.innerText = "Indexar Cambios por Lotes";
                        alert("Error de red o servidor: " + error);
                    }
                });
            }

            function triggerDBAnalysis(btn) {
                btn.disabled = true;
                btn.innerText = "Analizando...";
                
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: { 
                        action: 'sentinel_db_ajax',
                        nonce: sentinelNonce
                    },
                    success: function(response) {
                        btn.disabled = false;
                        btn.innerText = "Re-analizar Estructuras";
                        location.reload();
                    }
                });
            }

            function cleanWorkspace(btn) {
                if (confirm("¿Estás seguro de que deseas vaciar el workspace temporal de restauración?")) {
                    btn.disabled = true;
                    btn.innerText = "Vaciando...";
                    jQuery.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: { 
                            action: 'sentinel_clean_ajax',
                            nonce: sentinelNonce
                        },
                        success: function(response) {
                            btn.disabled = false;
                            btn.innerText = "Vaciar Workspace";
                            location.reload();
                        }
                    });
                }
            }
        </script>
        <?php
    }
}

// Iniciar Sentinel
Sentinel::get_instance();

// Agregar página del plugin en el panel de administración
add_action('admin_menu', function() {
    add_menu_page(
        'Sentinel',
        'Sentinel',
        'manage_options',
        'sentinel-settings',
        array(Sentinel::get_instance(), 'render_admin_page'),
        'dashicons-shield-alt',
        60
    );
});