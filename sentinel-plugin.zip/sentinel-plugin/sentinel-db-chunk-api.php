<?php
/**
 * Sentinel DB Chunk API (Bypass SHORTINIT)
 * Permite realizar backups de base de datos de manera ultraligera sin levantar plugins ni temas.
 */

header('Content-Type: application/json; charset=utf-8');

// 1. Cargar WordPress en modo SHORTINIT
define('SHORTINIT', true);

// Buscar wp-load.php de forma ascendente
$wp_load_path = dirname(dirname(dirname(__DIR__))) . '/wp-load.php';
if (!file_exists($wp_load_path)) {
    $wp_load_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php';
}
if (!file_exists($wp_load_path)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => 'No se pudo encontrar wp-load.php'));
    exit;
}

require_once($wp_load_path);

// 2. Cargar dependencias core necesarias
if (defined('ABSPATH')) {
    require_once(ABSPATH . 'wp-includes/functions.php');
    require_once(ABSPATH . 'wp-includes/formatting.php');
}

// 3. Autenticación
global $wpdb;
$agent_secret = $wpdb->get_var("SELECT option_value FROM $wpdb->options WHERE option_name = 'controlcenter_agent_secret'");
if (!$agent_secret) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'Sentinel no configurado.'));
    exit;
}

// Decodificar JSON crudo si viene en el cuerpo
$input_raw = file_get_contents('php://input');
$json_params = json_decode($input_raw, true);
if (is_array($json_params)) {
    $_REQUEST = array_merge($_REQUEST, $json_params);
}

$agent_id = isset($_SERVER['HTTP_X_AGENT_ID']) ? $_SERVER['HTTP_X_AGENT_ID'] : '';
$timestamp = isset($_SERVER['HTTP_X_TIMESTAMP']) ? intval($_SERVER['HTTP_X_TIMESTAMP']) : 0;
$signature = isset($_SERVER['HTTP_X_SIGNATURE']) ? $_SERVER['HTTP_X_SIGNATURE'] : '';

$auth_ok = false;

// Validar HMAC
if (!empty($agent_id) && !empty($timestamp) && !empty($signature)) {
    $current_time = time();
    if (abs($current_time - $timestamp) <= 300) {
        $data_to_sign = $agent_id . $timestamp;
        $expected_signature = hash_hmac('sha256', $data_to_sign, $agent_secret);
        if (hash_equals($expected_signature, $signature)) {
            $auth_ok = true;
        }
    }
}

// Validar Token/API Key
if (!$auth_ok) {
    $client_key = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'];
        if (preg_match('/Bearer\s+(.*)$/i', $auth, $matches)) {
            $client_key = trim($matches[1]);
        }
    } elseif (isset($_SERVER['HTTP_X_SENTINEL_API_KEY'])) {
        $client_key = trim($_SERVER['HTTP_X_SENTINEL_API_KEY']);
    } elseif (isset($_REQUEST['sentinel_key'])) {
        $client_key = trim($_REQUEST['sentinel_key']);
    }

    if (!empty($client_key) && hash_equals($agent_secret, $client_key)) {
        $auth_ok = true;
    }
}

if (!$auth_ok) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(array('success' => false, 'message' => 'No autorizado.'));
    exit;
}

// 4. Cargar clase de backup e iniciar
$backup_db_path = dirname(__FILE__) . '/includes/class-backup-db.php';
if (!file_exists($backup_db_path)) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(array('success' => false, 'message' => 'Clase class-backup-db.php no encontrada.'));
    exit;
}
require_once($backup_db_path);

$action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : '';
$backup_db = new Sentinel_Backup_DB();

switch ($action) {
    case 'start':
        $res = $backup_db->start_chunk_backup();
        echo json_encode($res);
        break;

    case 'step':
        $table = isset($_REQUEST['table']) ? sanitize_text_field($_REQUEST['table']) : '';
        $offset = isset($_REQUEST['offset']) ? intval($_REQUEST['offset']) : 0;
        $limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : 1000;
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        $write_structure = isset($_REQUEST['write_structure']) ? (bool)$_REQUEST['write_structure'] : false;

        if (empty($table) || empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetros "table" y "backup_name" requeridos.'));
            break;
        }

        $res = $backup_db->backup_table_chunk($table, $offset, $limit, $backup_name, $write_structure);
        echo json_encode($res);
        break;

    case 'finish':
        $backup_name = isset($_REQUEST['backup_name']) ? sanitize_file_name($_REQUEST['backup_name']) : '';
        if (empty($backup_name)) {
            echo json_encode(array('success' => false, 'message' => 'Parámetro "backup_name" requerido.'));
            break;
        }
        $res = $backup_db->finish_chunk_backup($backup_name);
        echo json_encode($res);
        break;

    default:
        echo json_encode(array('success' => false, 'message' => 'Acción no válida.'));
        break;
}
