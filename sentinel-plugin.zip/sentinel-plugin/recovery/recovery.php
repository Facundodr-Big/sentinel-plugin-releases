<?php
// recovery.php - Script independiente de recuperación de WordPress sin carga de core.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Buscar archivo de configuración en posibles rutas relativas
function get_recovery_config_path() {
    $paths = array(
        __DIR__ . '/../data/config.php',                      // Ruta tradicional (en wp-content/controlcenter/recovery/)
        __DIR__ . '/wp-content/controlcenter/data/config.php' // Ruta si se ejecuta desde el root de WordPress (/sentinel-recovery.php)
    );
    foreach ($paths as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }
    return __DIR__ . '/../data/config.php'; // Fallback
}

define('RECOVERY_CONFIG_PATH', get_recovery_config_path());
define('RECOVERY_ACTION_DEACTIVATE_PLUGINS', 'deactivate_plugins');
define('RECOVERY_ACTION_REPAIR_PERMISSIONS', 'repair_permissions');
define('RECOVERY_ACTION_GET_STATUS', 'get_status');

// Cargar configuración de credenciales del agente
function load_recovery_config() {
    $config_path = RECOVERY_CONFIG_PATH;
    if (!file_exists($config_path)) {
        return null;
    }
    $config = include $config_path;
    if (is_array($config) && isset($config['agent_uuid']) && isset($config['agent_secret'])) {
        return $config;
    }
    return null;
}

// Validar firma HMAC-SHA256
function validate_authentication() {
    $config = load_recovery_config();
    if (!$config) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Recovery configuration not found.'));
        exit;
    }

    // Cabeceras (compatibles con Apache/Nginx/IIS)
    $headers = array_change_key_case(getallheaders(), CASE_LOWER);
    $agent_id = $headers['x-agent-id'] ?? '';
    $timestamp = $headers['x-timestamp'] ?? '';
    $signature = $headers['x-signature'] ?? '';

    if (empty($agent_id) || empty($timestamp) || empty($signature)) {
        http_response_code(401);
        echo json_encode(array('success' => false, 'message' => 'Missing authorization headers.'));
        exit;
    }

    if ($agent_id !== $config['agent_uuid']) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Unauthorized agent.'));
        exit;
    }

    if (!is_numeric($timestamp) || abs(time() - (int)$timestamp) > 300) {
        http_response_code(401);
        echo json_encode(array('success' => false, 'message' => 'Expired timestamp.'));
        exit;
    }

    $raw_body = file_get_contents('php://input');
    $expected_signature = hash_hmac('sha256', $raw_body . $timestamp, $config['agent_secret']);
    
    if (!hash_equals($signature, $expected_signature)) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Invalid signature.'));
        exit;
    }
}

if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

// Buscar el archivo wp-config.php de forma iterativa hacia arriba
function find_wp_config() {
    $current_dir = __DIR__;
    for ($i = 0; $i < 10; $i++) {
        if (file_exists($current_dir . '/wp-config.php')) {
            return $current_dir . '/wp-config.php';
        }
        $parent = dirname($current_dir);
        if ($parent === $current_dir) {
            break;
        }
        $current_dir = $parent;
    }
    return null;
}

// Analizar wp-config.php mediante expresiones regulares para extraer credenciales sin cargarlo en memoria ejecutable
function parse_wp_config_credentials($wp_config_path) {
    $content = file_get_contents($wp_config_path);
    if ($content === false) {
        return null;
    }

    $db_name = '';
    $db_user = '';
    $db_password = '';
    $db_host = 'localhost';
    $table_prefix = 'wp_';

    preg_match("/define\(\s*['\"]DB_NAME['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_name = $matches[1];

    preg_match("/define\(\s*['\"]DB_USER['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_user = $matches[1];

    preg_match("/define\(\s*['\"]DB_PASSWORD['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_password = $matches[1];

    preg_match("/define\(\s*['\"]DB_HOST['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_host = $matches[1];

    preg_match("/\\\$table_prefix\s*=\s*['\"](.*?)['\"]\s*;/i", $content, $matches);
    if (!empty($matches[1])) $table_prefix = $matches[1];

    return array(
        'name' => $db_name,
        'user' => $db_user,
        'password' => $db_password,
        'host' => $db_host,
        'prefix' => $table_prefix
    );
}

// Desactivar todos los plugins editando directamente la base de datos
function deactivate_plugins() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }

    $creds = parse_wp_config_credentials($wp_config);
    if (!$creds || empty($creds['name'])) {
        return array('success' => false, 'message' => 'Failed to parse database credentials from wp-config.php.');
    }

    try {
        $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
        $pdo = new PDO($dsn, $creds['user'], $creds['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Desactivar plugins limpiando la lista serializada de active_plugins
        $empty_plugins = serialize(array());
        $stmt = $pdo->prepare("UPDATE " . $creds['prefix'] . "options SET option_value = :empty WHERE option_name = 'active_plugins'");
        $stmt->execute(array('empty' => $empty_plugins));

        return array('success' => true, 'message' => 'All active plugins have been deactivated successfully.');
    } catch (PDOException $e) {
        return array('success' => false, 'message' => 'Database connection failed: ' . $e->getMessage());
    }
}

// Reparar recursivamente los permisos de archivos y carpetas
function repair_permissions() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }
    
    $wp_root = dirname($wp_config);

    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($wp_root, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $path = $item->getPathname();
            // Evitar modificar permisos en controlcenter/data o recovery para no romper acceso a sqlite
            if (strpos($path, 'controlcenter') !== false) {
                continue;
            }
            if ($item->isDir()) {
                @chmod($path, 0755);
            } else {
                @chmod($path, 0644);
            }
        }
        return array('success' => true, 'message' => 'File and folder permissions repaired successfully.');
    } catch (Exception $e) {
        return array('success' => false, 'message' => 'Failed to repair permissions: ' . $e->getMessage());
    }
}

// Obtener estado de salud del sistema
function get_status() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }

    $creds = parse_wp_config_credentials($wp_config);
    if (!$creds) {
        return array('success' => false, 'message' => 'wp-config.php parsing error.');
    }

    $db_ok = false;
    try {
        $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
        $pdo = new PDO($dsn, $creds['user'], $creds['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db_ok = true;
    } catch (PDOException $e) {
        // DB error
    }

    $index_ok = file_exists(dirname($wp_config) . '/index.php');

    return array(
        'success' => $db_ok && $index_ok,
        'database_connected' => $db_ok,
        'index_file_exists' => $index_ok,
        'message' => ($db_ok && $index_ok) ? 'WordPress environment is responding.' : 'WordPress environment is broken.'
    );
}

// Helper para restaurar un archivo de backup individual
function restore_single_backup($backup_name) {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }
    $wp_root = dirname($wp_config);
    $backup_dir = $wp_root . '/wp-content/uploads/sentinel-backups/';
    $backup_path = $backup_dir . basename($backup_name);
    
    if (!file_exists($backup_path)) {
        return array('success' => false, 'message' => 'Backup file not found at: ' . $backup_path);
    }
    
    $extension = pathinfo($backup_path, PATHINFO_EXTENSION);
    
    if ($extension === 'zip') {
        if (!class_exists('ZipArchive')) {
            return array('success' => false, 'message' => 'ZipArchive class not available.');
        }
        $zip = new ZipArchive();
        if ($zip->open($backup_path) === true) {
            $extract_to = $wp_root . '/wp-content/plugins';
            if (strpos(basename($backup_name), 'rollback_theme_') === 0) {
                $extract_to = $wp_root . '/wp-content/themes';
            }
            $zip->extractTo($extract_to);
            $zip->close();
            
            // Reparar permisos de forma proactiva inmediatamente después de la extracción
            repair_permissions();
            
            // Si es un rollback de plugin, intentar restaurar la BD asociada si existe
            if (strpos(basename($backup_name), 'rollback_') === 0 && strpos(basename($backup_name), 'rollback_theme_') === false) {
                $plugin_slug = str_replace(array('rollback_', '.zip'), '', basename($backup_name));
                $associated_sql = 'rollback_db_' . $plugin_slug . '.sql';
                $associated_sql_path = $backup_dir . $associated_sql;
                if (file_exists($associated_sql_path)) {
                    $db_res = restore_single_backup($associated_sql);
                    if (!$db_res['success']) {
                        return array('success' => false, 'message' => 'Zip extraído pero falló la restauración de BD asociada: ' . $db_res['message']);
                    }
                    return array('success' => true, 'message' => 'Zip extraído y BD asociada restaurada con éxito.');
                }
            }
            
            return array('success' => true, 'message' => 'Zip backup extracted successfully.');
        }
        return array('success' => false, 'message' => 'Failed to open zip file.');
    } elseif ($extension === 'sql') {
        $creds = parse_wp_config_credentials($wp_config);
        if (!$creds || empty($creds['name'])) {
            return array('success' => false, 'message' => 'Failed to parse database credentials from wp-config.php.');
        }
        
        try {
            $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
            $pdo = new PDO($dsn, $creds['user'], $creds['password']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $sql = file_get_contents($backup_path);
            if ($sql === false) {
                return array('success' => false, 'message' => 'Failed to read SQL backup file.');
            }
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");
            
            $queries = preg_split("/;[ \t]*\n/", $sql);
            foreach ($queries as $query) {
                $query = trim($query);
                if (!empty($query)) {
                    $pdo->exec($query);
                }
            }
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");
            return array('success' => true, 'message' => 'Database sql file imported successfully.');
        } catch (PDOException $e) {
            return array('success' => false, 'message' => 'Database execution failed: ' . $e->getMessage());
        }
    }
    
    return array('success' => false, 'message' => 'Unsupported backup file type.');
}

// Restaurar backup localmente (archivos zip o base de datos sql o combinado)
function restore_local_backup($backup_name) {
    if (empty($backup_name)) {
        return array('success' => false, 'message' => 'Backup name is empty.');
    }
    
    if (is_array($backup_name)) {
        $results = array();
        $overall_success = true;
        foreach ($backup_name as $single_name) {
            $res = restore_single_backup($single_name);
            $results[$single_name] = $res;
            if (!$res['success']) {
                $overall_success = false;
            }
        }
        return array(
            'success' => $overall_success, 
            'results' => $results, 
            'message' => $overall_success ? 'Todos los respaldos especificados fueron restaurados.' : 'Algunos respaldos fallaron al restaurar.'
        );
    }
    
    return restore_single_backup($backup_name);
}

// Helper para desencriptación RC4 en puro PHP
function sentinel_rc4_decrypt($key, $str) {
    $s = array();
    for ($i = 0; $i < 256; $i++) {
        $s[$i] = $i;
    }
    $j = 0;
    for ($i = 0; $i < 256; $i++) {
        $j = ($j + $s[$i] + ord($key[$i % strlen($key)])) % 256;
        $x = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $x;
    }
    $i = 0;
    $j = 0;
    $res = '';
    for ($y = 0; $y < strlen($str); $y++) {
        $i = ($i + 1) % 256;
        $j = ($j + $s[$i]) % 256;
        $x = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $x;
        $res .= $str[$y] ^ chr($s[($s[$i] + $s[$j]) % 256]);
    }
    return $res;
}

// Manejar peticiones de recuperacion
function handle_recovery_request() {
    validate_authentication();

    $raw_body = file_get_contents('php://input');
    $request = json_decode($raw_body, true);

    if (!is_array($request)) {
        $request = array();
        parse_str($raw_body, $request);
    }

    // Si los datos están cifrados en RC4, descifrarlos usando agent_secret
    if (isset($request['data'])) {
        $config = load_recovery_config();
        if ($config && isset($config['agent_secret'])) {
            $decrypted_raw = sentinel_rc4_decrypt($config['agent_secret'], hex2bin($request['data']));
            $decrypted_request = json_decode($decrypted_raw, true);
            if (is_array($decrypted_request)) {
                $request = $decrypted_request;
            }
        }
    }

    if (!is_array($request) || !isset($request['action'])) {
        http_response_code(400);
        echo json_encode(array('success' => false, 'message' => 'Invalid request action.'));
        exit;
    }

    $action = $request['action'];
    $response = [];

    switch ($action) {
        case RECOVERY_ACTION_DEACTIVATE_PLUGINS:
            $response = deactivate_plugins();
            break;
        case RECOVERY_ACTION_REPAIR_PERMISSIONS:
            $response = repair_permissions();
            break;
        case RECOVERY_ACTION_GET_STATUS:
            $response = get_status();
            break;
        case 'restore_local_backup':
            $backup_name = $request['backup_name'] ?? '';
            $response = restore_local_backup($backup_name);
            break;
        default:
            http_response_code(400);
            $response = array('success' => false, 'message' => 'Action not supported.');
            break;
    }

    if (isset($response['success']) && !$response['success']) {
        http_response_code(500);
    } else {
        http_response_code(200);
    }
    echo json_encode($response);
}

function render_gui_page($is_authed, $error_msg = '', $success_msg = '') {
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sentinel Recovery - Panel de Emergencia</title>
        <style>
            body {
                background-color: #0d0f12;
                color: #e2e8f0;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }
            .container {
                width: 100%;
                max-width: 480px;
                padding: 2rem;
                box-sizing: border-box;
            }
            .header {
                text-align: center;
                margin-bottom: 2rem;
            }
            .header h1 {
                font-size: 1.5rem;
                font-weight: 600;
                margin: 0 0 0.5rem 0;
                color: #ffffff;
                letter-spacing: -0.025em;
            }
            .header p {
                font-size: 0.875rem;
                color: #94a3b8;
                margin: 0;
            }
            .form-group {
                margin-bottom: 1.5rem;
            }
            label {
                display: block;
                font-size: 0.875rem;
                font-weight: 500;
                margin-bottom: 0.5rem;
                color: #94a3b8;
            }
            input[type="password"] {
                width: 100%;
                padding: 0.75rem 1rem;
                background-color: #161920;
                border: 1px solid #232834;
                border-radius: 6px;
                color: #ffffff;
                font-size: 1rem;
                box-sizing: border-box;
                outline: none;
                transition: border-color 0.2s;
            }
            input[type="password"]:focus {
                border-color: #3b82f6;
            }
            .btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 100%;
                padding: 0.75rem 1.25rem;
                font-size: 0.875rem;
                font-weight: 600;
                border-radius: 6px;
                border: none;
                cursor: pointer;
                transition: background-color 0.2s, transform 0.1s;
                text-decoration: none;
                box-sizing: border-box;
            }
            .btn:active {
                transform: scale(0.98);
            }
            .btn-primary {
                background-color: #3b82f6;
                color: #ffffff;
            }
            .btn-primary:hover {
                background-color: #2563eb;
            }
            .btn-danger {
                background-color: #dc2626;
                color: #ffffff;
            }
            .btn-danger:hover {
                background-color: #b91c1c;
            }
            .btn-secondary {
                background-color: #1f2937;
                color: #94a3b8;
                border: 1px solid #374151;
                margin-top: 1rem;
            }
            .btn-secondary:hover {
                background-color: #374151;
                color: #ffffff;
            }
            .console-box {
                background-color: #13161c;
                padding: 1.5rem;
                border-radius: 8px;
                border: 1px solid #1f2530;
                margin-bottom: 1.5rem;
            }
            .console-item {
                padding: 1rem 0;
                border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            }
            .console-item:last-child {
                border-bottom: none;
            }
            .alert {
                padding: 1rem;
                border-radius: 6px;
                font-size: 0.875rem;
                margin-bottom: 1.5rem;
                text-align: center;
            }
            .alert-success {
                background-color: rgba(16, 185, 129, 0.1);
                color: #34d399;
                border: 1px solid rgba(16, 185, 129, 0.2);
            }
            .alert-error {
                background-color: rgba(239, 68, 68, 0.1);
                color: #f87171;
                border: 1px solid rgba(239, 68, 68, 0.2);
            }
            .actions-grid {
                display: grid;
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            .footer {
                text-align: center;
                margin-top: 2rem;
                font-size: 0.75rem;
                color: #4b5563;
            }
            .footer a {
                color: #64748b;
                text-decoration: none;
            }
            .footer a:hover {
                color: #94a3b8;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Sentinel Recovery</h1>
                <p>Consola Autónoma de Rescate</p>
            </div>

            <?php if (!empty($error_msg)): ?>
                <div class="alert alert-error" id="msg-error"><?php echo htmlspecialchars($error_msg); ?></div>
            <?php endif; ?>

            <?php if (!empty($success_msg)): ?>
                <div class="alert alert-success" id="msg-success"><?php echo htmlspecialchars($success_msg); ?></div>
            <?php endif; ?>

            <div id="js-alert" class="alert" style="display:none;"></div>

            <?php if (!$is_authed): ?>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="login">
                    <div class="form-group">
                        <label for="agent_secret">Clave Secreta del Agente</label>
                        <input type="password" id="agent_secret" name="agent_secret" required placeholder="••••••••••••••••">
                    </div>
                    <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
                </form>
            <?php else: ?>
                <div class="console-box">
                    <div class="console-item" style="padding-top:0;">
                        <span style="font-size:0.875rem; color:#94a3b8;">Estado del Entorno:</span>
                        <div style="font-weight:600; margin-top:0.25rem; font-size:1.1rem;" id="env-status">Cargando...</div>
                    </div>
                    
                    <div class="console-item" style="border-bottom:none; padding-bottom:0;">
                        <span style="font-size:0.875rem; color:#94a3b8;">Herramientas disponibles:</span>
                        <div class="actions-grid" style="margin-top:1rem;">
                            <button onclick="runAction('deactivate_plugins')" class="btn btn-danger">Desactivar todos los plugins</button>
                            <button onclick="runAction('repair_permissions')" class="btn btn-primary">Reparar permisos de archivos</button>
                        </div>
                    </div>
                </div>
                <a href="?action=logout" class="btn btn-secondary">Cerrar Sesión</a>
            <?php endif; ?>

            <div class="footer">
                Sentinel Security System &bull; <a href="/">Volver al Sitio</a>
            </div>
        </div>

        <?php if ($is_authed): ?>
        <script>
            function showStatus(text, type) {
                var el = document.getElementById('js-alert');
                el.style.display = 'block';
                el.className = 'alert alert-' + type;
                el.innerText = text;
                // Ocultar mensajes php anteriores
                var errEl = document.getElementById('msg-error');
                if (errEl) errEl.style.display = 'none';
                var succEl = document.getElementById('msg-success');
                if (succEl) succEl.style.display = 'none';
            }

            function runAction(actionName) {
                if (actionName === 'deactivate_plugins' && !confirm('¿Estás seguro de que deseas desactivar TODOS los plugins de WordPress?')) {
                    return;
                }
                
                showStatus('Procesando acción...', 'success');
                
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        try {
                            var res = JSON.parse(xhr.responseText);
                            if (res.success) {
                                showStatus(res.message, 'success');
                            } else {
                                showStatus('Error: ' + res.message, 'error');
                            }
                            checkStatus();
                        } catch (e) {
                            showStatus('Error al procesar la respuesta del servidor.', 'error');
                        }
                    }
                };
                xhr.send('action=' + actionName);
            }

            function checkStatus() {
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4) {
                        try {
                            var res = JSON.parse(xhr.responseText);
                            var el = document.getElementById('env-status');
                            if (res.success) {
                                el.innerHTML = '<span style="color:#10b981;">● Online</span>';
                            } else {
                                el.innerHTML = '<span style="color:#ef4444;">● Problemas Detectados</span>';
                            }
                        } catch (e) {}
                    }
                };
                xhr.send('action=get_status');
            }
            
            // Check status on load
            checkStatus();
        </script>
        <?php endif; ?>
    </body>
    </html>
    <?php
}

function render_config_error_page() {
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sentinel Recovery - Error de Configuración</title>
        <style>
            body {
                background-color: #0d0f12;
                color: #e2e8f0;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }
            .container {
                width: 100%;
                max-width: 480px;
                padding: 2rem;
                box-sizing: border-box;
                text-align: center;
            }
            h1 {
                font-size: 1.5rem;
                font-weight: 600;
                color: #ef4444;
                margin-bottom: 1rem;
            }
            p {
                font-size: 0.875rem;
                color: #94a3b8;
                line-height: 1.5;
                margin-bottom: 2rem;
            }
            .path-box {
                background-color: #13161c;
                border: 1px solid #1f2530;
                padding: 0.75rem 1rem;
                font-family: monospace;
                font-size: 0.875rem;
                border-radius: 6px;
                color: #f87171;
                word-break: break-all;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Error de Configuración</h1>
            <p>No se pudo cargar el archivo de configuración del agente de Sentinel necesario para validar el acceso autónomo.</p>
            <div class="path-box">Ruta esperada: <?php echo htmlspecialchars(RECOVERY_CONFIG_PATH); ?></div>
        </div>
    </body>
    </html>
    <?php
}

function run_recovery_router() {
    $headers = array_change_key_case(getallheaders(), CASE_LOWER);
    $has_hmac = isset($headers['x-signature']) && isset($headers['x-timestamp']) && isset($headers['x-agent-id']);

    if ($has_hmac || ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action']))) {
        header('Content-Type: application/json; charset=utf-8');
        handle_recovery_request();
        exit;
    }

    $config = load_recovery_config();
    if (!$config) {
        header('Content-Type: text/html; charset=utf-8');
        render_config_error_page();
        exit;
    }

    $error_msg = '';
    $success_msg = '';

    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $secret = $_POST['agent_secret'] ?? '';
        if (hash_equals($config['agent_secret'], $secret)) {
            $_SESSION['sentinel_recovery_authed'] = true;
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        } else {
            $error_msg = 'Clave secreta del agente incorrecta.';
        }
    }

    if (isset($_GET['action']) && $_GET['action'] === 'logout') {
        $_SESSION['sentinel_recovery_authed'] = false;
        unset($_SESSION['sentinel_recovery_authed']);
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }

    $is_authed = $_SESSION['sentinel_recovery_authed'] ?? false;
    if ($is_authed && isset($_POST['action'])) {
        $action = $_POST['action'];
        $result = null;
        if ($action === 'deactivate_plugins') {
            $result = deactivate_plugins();
        } elseif ($action === 'repair_permissions') {
            $result = repair_permissions();
        } elseif ($action === 'get_status') {
            $result = get_status();
        }

        if ($result) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($result);
            exit;
        }
    }

    header('Content-Type: text/html; charset=utf-8');
    render_gui_page($is_authed, $error_msg, $success_msg);
    exit;
}

run_recovery_router();