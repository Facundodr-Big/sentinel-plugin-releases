<?php
// recovery.php - Script independiente de recuperación de WordPress sin carga de core.

header('Content-Type: application/json; charset=utf-8');

// Buscar archivo de configuración en posibles rutas relativas
function get_recovery_config_path() {
    $paths = array(
        __DIR__ . '/../data/config.php',                      // Ruta tradicional (en wp-content/controlcenter/recovery/)
        __DIR__ . '/wp-content/controlcenter/data/config.php' // Ruta si se ejecuta desde el root de WordPress (/sentinel-recovery.php)
    );
    foreach ($paths as $path) {
        if (file_exists($path)) {
            return $path;
        }
    }
    return __DIR__ . '/../data/config.php'; // Fallback
}

define('RECOVERY_CONFIG_PATH', get_recovery_config_path());
define('RECOVERY_ACTION_DEACTIVATE_PLUGINS', 'deactivate_plugins');
define('RECOVERY_ACTION_REPAIR_PERMISSIONS', 'repair_permissions');
define('RECOVERY_ACTION_GET_STATUS', 'get_status');

// Cargar configuración de credenciales del agente
function load_recovery_config() {
    $config_path = RECOVERY_CONFIG_PATH;
    if (!file_exists($config_path)) {
        return null;
    }
    $config = include $config_path;
    if (is_array($config) && isset($config['agent_uuid']) && isset($config['agent_secret'])) {
        return $config;
    }
    return null;
}

// Validar firma HMAC-SHA256
function validate_authentication() {
    $config = load_recovery_config();
    if (!$config) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Recovery configuration not found.'));
        exit;
    }

    // Cabeceras (compatibles con Apache/Nginx/IIS)
    $headers = array_change_key_case(getallheaders(), CASE_LOWER);
    $agent_id = $headers['x-agent-id'] ?? '';
    $timestamp = $headers['x-timestamp'] ?? '';
    $signature = $headers['x-signature'] ?? '';

    if (empty($agent_id) || empty($timestamp) || empty($signature)) {
        http_response_code(401);
        echo json_encode(array('success' => false, 'message' => 'Missing authorization headers.'));
        exit;
    }

    if ($agent_id !== $config['agent_uuid']) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Unauthorized agent.'));
        exit;
    }

    if (!is_numeric($timestamp) || abs(time() - (int)$timestamp) > 300) {
        http_response_code(401);
        echo json_encode(array('success' => false, 'message' => 'Expired timestamp.'));
        exit;
    }

    $raw_body = file_get_contents('php://input');
    $expected_signature = hash_hmac('sha256', $raw_body . $timestamp, $config['agent_secret']);
    
    if (!hash_equals($signature, $expected_signature)) {
        http_response_code(403);
        echo json_encode(array('success' => false, 'message' => 'Invalid signature.'));
        exit;
    }
}

if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

// Buscar el archivo wp-config.php de forma iterativa hacia arriba
function find_wp_config() {
    $current_dir = __DIR__;
    for ($i = 0; $i < 10; $i++) {
        if (file_exists($current_dir . '/wp-config.php')) {
            return $current_dir . '/wp-config.php';
        }
        $parent = dirname($current_dir);
        if ($parent === $current_dir) {
            break;
        }
        $current_dir = $parent;
    }
    return null;
}

// Analizar wp-config.php mediante expresiones regulares para extraer credenciales sin cargarlo en memoria ejecutable
function parse_wp_config_credentials($wp_config_path) {
    $content = file_get_contents($wp_config_path);
    if ($content === false) {
        return null;
    }

    $db_name = '';
    $db_user = '';
    $db_password = '';
    $db_host = 'localhost';
    $table_prefix = 'wp_';

    preg_match("/define\(\s*['\"]DB_NAME['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_name = $matches[1];

    preg_match("/define\(\s*['\"]DB_USER['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_user = $matches[1];

    preg_match("/define\(\s*['\"]DB_PASSWORD['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_password = $matches[1];

    preg_match("/define\(\s*['\"]DB_HOST['\"]\s*,\s*['\"](.*?)['\"]\s*\)/i", $content, $matches);
    if (!empty($matches[1])) $db_host = $matches[1];

    preg_match("/\\\$table_prefix\s*=\s*['\"](.*?)['\"]\s*;/i", $content, $matches);
    if (!empty($matches[1])) $table_prefix = $matches[1];

    return array(
        'name' => $db_name,
        'user' => $db_user,
        'password' => $db_password,
        'host' => $db_host,
        'prefix' => $table_prefix
    );
}

// Desactivar todos los plugins editando directamente la base de datos
function deactivate_plugins() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }

    $creds = parse_wp_config_credentials($wp_config);
    if (!$creds || empty($creds['name'])) {
        return array('success' => false, 'message' => 'Failed to parse database credentials from wp-config.php.');
    }

    try {
        $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
        $pdo = new PDO($dsn, $creds['user'], $creds['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Desactivar plugins limpiando la lista serializada de active_plugins
        $empty_plugins = serialize(array());
        $stmt = $pdo->prepare("UPDATE " . $creds['prefix'] . "options SET option_value = :empty WHERE option_name = 'active_plugins'");
        $stmt->execute(array('empty' => $empty_plugins));

        return array('success' => true, 'message' => 'All active plugins have been deactivated successfully.');
    } catch (PDOException $e) {
        return array('success' => false, 'message' => 'Database connection failed: ' . $e->getMessage());
    }
}

// Reparar recursivamente los permisos de archivos y carpetas
function repair_permissions() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }
    
    $wp_root = dirname($wp_config);

    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($wp_root, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $path = $item->getPathname();
            // Evitar modificar permisos en controlcenter/data o recovery para no romper acceso a sqlite
            if (strpos($path, 'controlcenter') !== false) {
                continue;
            }
            if ($item->isDir()) {
                @chmod($path, 0755);
            } else {
                @chmod($path, 0644);
            }
        }
        return array('success' => true, 'message' => 'File and folder permissions repaired successfully.');
    } catch (Exception $e) {
        return array('success' => false, 'message' => 'Failed to repair permissions: ' . $e->getMessage());
    }
}

// Obtener estado de salud del sistema
function get_status() {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }

    $creds = parse_wp_config_credentials($wp_config);
    if (!$creds) {
        return array('success' => false, 'message' => 'wp-config.php parsing error.');
    }

    $db_ok = false;
    try {
        $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
        $pdo = new PDO($dsn, $creds['user'], $creds['password']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db_ok = true;
    } catch (PDOException $e) {
        // DB error
    }

    $index_ok = file_exists(dirname($wp_config) . '/index.php');

    return array(
        'success' => $db_ok && $index_ok,
        'database_connected' => $db_ok,
        'index_file_exists' => $index_ok,
        'message' => ($db_ok && $index_ok) ? 'WordPress environment is responding.' : 'WordPress environment is broken.'
    );
}

// Helper para restaurar un archivo de backup individual
function restore_single_backup($backup_name) {
    $wp_config = find_wp_config();
    if (!$wp_config) {
        return array('success' => false, 'message' => 'wp-config.php not found.');
    }
    $wp_root = dirname($wp_config);
    $backup_dir = $wp_root . '/wp-content/uploads/sentinel-backups/';
    $backup_path = $backup_dir . basename($backup_name);
    
    if (!file_exists($backup_path)) {
        return array('success' => false, 'message' => 'Backup file not found at: ' . $backup_path);
    }
    
    $extension = pathinfo($backup_path, PATHINFO_EXTENSION);
    
    if ($extension === 'zip') {
        if (!class_exists('ZipArchive')) {
            return array('success' => false, 'message' => 'ZipArchive class not available.');
        }
        $zip = new ZipArchive();
        if ($zip->open($backup_path) === true) {
            $extract_to = $wp_root . '/wp-content/plugins';
            if (strpos(basename($backup_name), 'rollback_theme_') === 0) {
                $extract_to = $wp_root . '/wp-content/themes';
            }
            $zip->extractTo($extract_to);
            $zip->close();
            
            // Reparar permisos de forma proactiva inmediatamente después de la extracción
            repair_permissions();
            
            // Si es un rollback de plugin, intentar restaurar la BD asociada si existe
            if (strpos(basename($backup_name), 'rollback_') === 0 && strpos(basename($backup_name), 'rollback_theme_') === false) {
                $plugin_slug = str_replace(array('rollback_', '.zip'), '', basename($backup_name));
                $associated_sql = 'rollback_db_' . $plugin_slug . '.sql';
                $associated_sql_path = $backup_dir . $associated_sql;
                if (file_exists($associated_sql_path)) {
                    $db_res = restore_single_backup($associated_sql);
                    if (!$db_res['success']) {
                        return array('success' => false, 'message' => 'Zip extraído pero falló la restauración de BD asociada: ' . $db_res['message']);
                    }
                    return array('success' => true, 'message' => 'Zip extraído y BD asociada restaurada con éxito.');
                }
            }
            
            return array('success' => true, 'message' => 'Zip backup extracted successfully.');
        }
        return array('success' => false, 'message' => 'Failed to open zip file.');
    } elseif ($extension === 'sql') {
        $creds = parse_wp_config_credentials($wp_config);
        if (!$creds || empty($creds['name'])) {
            return array('success' => false, 'message' => 'Failed to parse database credentials from wp-config.php.');
        }
        
        try {
            $dsn = "mysql:host=" . $creds['host'] . ";dbname=" . $creds['name'] . ";charset=utf8";
            $pdo = new PDO($dsn, $creds['user'], $creds['password']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $sql = file_get_contents($backup_path);
            if ($sql === false) {
                return array('success' => false, 'message' => 'Failed to read SQL backup file.');
            }
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");
            
            $queries = preg_split("/;[ \t]*\n/", $sql);
            foreach ($queries as $query) {
                $query = trim($query);
                if (!empty($query)) {
                    $pdo->exec($query);
                }
            }
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");
            return array('success' => true, 'message' => 'Database sql file imported successfully.');
        } catch (PDOException $e) {
            return array('success' => false, 'message' => 'Database execution failed: ' . $e->getMessage());
        }
    }
    
    return array('success' => false, 'message' => 'Unsupported backup file type.');
}

// Restaurar backup localmente (archivos zip o base de datos sql o combinado)
function restore_local_backup($backup_name) {
    if (empty($backup_name)) {
        return array('success' => false, 'message' => 'Backup name is empty.');
    }
    
    if (is_array($backup_name)) {
        $results = array();
        $overall_success = true;
        foreach ($backup_name as $single_name) {
            $res = restore_single_backup($single_name);
            $results[$single_name] = $res;
            if (!$res['success']) {
                $overall_success = false;
            }
        }
        return array(
            'success' => $overall_success, 
            'results' => $results, 
            'message' => $overall_success ? 'Todos los respaldos especificados fueron restaurados.' : 'Algunos respaldos fallaron al restaurar.'
        );
    }
    
    return restore_single_backup($backup_name);
}

// Helper para desencriptación RC4 en puro PHP
function sentinel_rc4_decrypt($key, $str) {
    $s = array();
    for ($i = 0; $i < 256; $i++) {
        $s[$i] = $i;
    }
    $j = 0;
    for ($i = 0; $i < 256; $i++) {
        $j = ($j + $s[$i] + ord($key[$i % strlen($key)])) % 256;
        $x = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $x;
    }
    $i = 0;
    $j = 0;
    $res = '';
    for ($y = 0; $y < strlen($str); $y++) {
        $i = ($i + 1) % 256;
        $j = ($j + $s[$i]) % 256;
        $x = $s[$i];
        $s[$i] = $s[$j];
        $s[$j] = $x;
        $res .= $str[$y] ^ chr($s[($s[$i] + $s[$j]) % 256]);
    }
    return $res;
}

// Manejar peticiones de recuperacion
function handle_recovery_request() {
    validate_authentication();

    $raw_body = file_get_contents('php://input');
    $request = json_decode($raw_body, true);

    if (!is_array($request)) {
        $request = array();
        parse_str($raw_body, $request);
    }

    // Si los datos están cifrados en RC4, descifrarlos usando agent_secret
    if (isset($request['data'])) {
        $config = load_recovery_config();
        if ($config && isset($config['agent_secret'])) {
            $decrypted_raw = sentinel_rc4_decrypt($config['agent_secret'], hex2bin($request['data']));
            $decrypted_request = json_decode($decrypted_raw, true);
            if (is_array($decrypted_request)) {
                $request = $decrypted_request;
            }
        }
    }

    if (!is_array($request) || !isset($request['action'])) {
        http_response_code(400);
        echo json_encode(array('success' => false, 'message' => 'Invalid request action.'));
        exit;
    }

    $action = $request['action'];
    $response = [];

    switch ($action) {
        case RECOVERY_ACTION_DEACTIVATE_PLUGINS:
            $response = deactivate_plugins();
            break;
        case RECOVERY_ACTION_REPAIR_PERMISSIONS:
            $response = repair_permissions();
            break;
        case RECOVERY_ACTION_GET_STATUS:
            $response = get_status();
            break;
        case 'restore_local_backup':
            $backup_name = $request['backup_name'] ?? '';
            $response = restore_local_backup($backup_name);
            break;
        default:
            http_response_code(400);
            $response = array('success' => false, 'message' => 'Action not supported.');
            break;
    }

    if (isset($response['success']) && !$response['success']) {
        http_response_code(500);
    } else {
        http_response_code(200);
    }
    echo json_encode($response);
}

handle_recovery_request();